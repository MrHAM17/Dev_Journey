import 'package:the_4_21_vertex___real_estate_app/core/app_export.dart';import 'package:the_4_21_vertex___real_estate_app/presentation/my_home_page/models/my_home_model.dart';/// A controller class for the MyHomePage.
///
/// This class manages the state of the MyHomePage, including the
/// current myHomeModelObj
class MyHomeController extends GetxController {MyHomeController(this.myHomeModelObj);

Rx<MyHomeModel> myHomeModelObj;

 }
