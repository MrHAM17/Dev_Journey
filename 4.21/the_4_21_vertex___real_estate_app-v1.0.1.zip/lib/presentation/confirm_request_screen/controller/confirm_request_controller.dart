import 'package:the_4_21_vertex___real_estate_app/core/app_export.dart';import 'package:the_4_21_vertex___real_estate_app/presentation/confirm_request_screen/models/confirm_request_model.dart';/// A controller class for the ConfirmRequestScreen.
///
/// This class manages the state of the ConfirmRequestScreen, including the
/// current confirmRequestModelObj
class ConfirmRequestController extends GetxController {Rx<ConfirmRequestModel> confirmRequestModelObj = ConfirmRequestModel().obs;

 }
