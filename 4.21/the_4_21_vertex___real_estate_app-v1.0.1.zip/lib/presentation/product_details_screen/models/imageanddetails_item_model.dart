import '../../../core/app_export.dart';/// This class is used in the [imageanddetails_item_widget] screen.
class ImageanddetailsItemModel {ImageanddetailsItemModel({this.id}) { id = id  ?? Rx(""); }

Rx<String>? id;

 }
