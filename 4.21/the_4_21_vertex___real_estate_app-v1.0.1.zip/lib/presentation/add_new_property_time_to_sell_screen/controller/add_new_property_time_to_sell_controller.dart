import 'package:the_4_21_vertex___real_estate_app/core/app_export.dart';import 'package:the_4_21_vertex___real_estate_app/presentation/add_new_property_time_to_sell_screen/models/add_new_property_time_to_sell_model.dart';/// A controller class for the AddNewPropertyTimeToSellScreen.
///
/// This class manages the state of the AddNewPropertyTimeToSellScreen, including the
/// current addNewPropertyTimeToSellModelObj
class AddNewPropertyTimeToSellController extends GetxController {Rx<AddNewPropertyTimeToSellModel> addNewPropertyTimeToSellModelObj = AddNewPropertyTimeToSellModel().obs;

 }
