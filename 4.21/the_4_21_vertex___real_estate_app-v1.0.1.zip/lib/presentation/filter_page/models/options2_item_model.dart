import '../../../core/app_export.dart';/// This class is used in the [options2_item_widget] screen.
class Options2ItemModel {Rx<String>? freeWiFi = Rx("Free WiFi");

Rx<bool>? isSelected = Rx(false);

 }
