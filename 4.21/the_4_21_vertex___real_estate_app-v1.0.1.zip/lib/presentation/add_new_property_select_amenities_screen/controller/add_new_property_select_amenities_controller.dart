import 'package:the_4_21_vertex___real_estate_app/core/app_export.dart';import 'package:the_4_21_vertex___real_estate_app/presentation/add_new_property_select_amenities_screen/models/add_new_property_select_amenities_model.dart';/// A controller class for the AddNewPropertySelectAmenitiesScreen.
///
/// This class manages the state of the AddNewPropertySelectAmenitiesScreen, including the
/// current addNewPropertySelectAmenitiesModelObj
class AddNewPropertySelectAmenitiesController extends GetxController {Rx<AddNewPropertySelectAmenitiesModel> addNewPropertySelectAmenitiesModelObj = AddNewPropertySelectAmenitiesModel().obs;

 }
