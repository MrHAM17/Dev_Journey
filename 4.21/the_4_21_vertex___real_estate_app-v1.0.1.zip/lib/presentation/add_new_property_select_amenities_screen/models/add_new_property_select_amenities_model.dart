import 'options_item_model.dart';import '../../../core/app_export.dart';/// This class defines the variables used in the [add_new_property_select_amenities_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class AddNewPropertySelectAmenitiesModel {Rx<List<OptionsItemModel>> optionsItemList = Rx(List.generate(8,(index) =>OptionsItemModel()));

 }
