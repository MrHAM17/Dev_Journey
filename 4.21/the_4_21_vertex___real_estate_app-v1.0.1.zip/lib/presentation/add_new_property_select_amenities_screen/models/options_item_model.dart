import '../../../core/app_export.dart';/// This class is used in the [options_item_widget] screen.
class OptionsItemModel {Rx<String>? freeWiFi = Rx("Free WiFi");

Rx<bool>? isSelected = Rx(false);

 }
