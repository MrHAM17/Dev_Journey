import 'package:the_4_21_vertex___real_estate_app/core/app_export.dart';import 'package:the_4_21_vertex___real_estate_app/presentation/confirm_request_bottom_sheet_bottomsheet/models/confirm_request_bottom_sheet_model.dart';/// A controller class for the ConfirmRequestBottomSheetBottomsheet.
///
/// This class manages the state of the ConfirmRequestBottomSheetBottomsheet, including the
/// current confirmRequestBottomSheetModelObj
class ConfirmRequestBottomSheetController extends GetxController {Rx<ConfirmRequestBottomSheetModel> confirmRequestBottomSheetModelObj = ConfirmRequestBottomSheetModel().obs;

 }
