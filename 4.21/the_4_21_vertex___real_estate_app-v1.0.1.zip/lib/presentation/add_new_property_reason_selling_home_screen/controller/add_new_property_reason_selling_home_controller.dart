import 'package:the_4_21_vertex___real_estate_app/core/app_export.dart';import 'package:the_4_21_vertex___real_estate_app/presentation/add_new_property_reason_selling_home_screen/models/add_new_property_reason_selling_home_model.dart';/// A controller class for the AddNewPropertyReasonSellingHomeScreen.
///
/// This class manages the state of the AddNewPropertyReasonSellingHomeScreen, including the
/// current addNewPropertyReasonSellingHomeModelObj
class AddNewPropertyReasonSellingHomeController extends GetxController {Rx<AddNewPropertyReasonSellingHomeModel> addNewPropertyReasonSellingHomeModelObj = AddNewPropertyReasonSellingHomeModel().obs;

Rx<bool> other = false.obs;

 }
