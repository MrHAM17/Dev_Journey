import '../../../core/app_export.dart';import 'addnewpropertyreasonsellinghom_item_model.dart';/// This class defines the variables used in the [add_new_property_reason_selling_home_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class AddNewPropertyReasonSellingHomeModel {Rx<List<AddnewpropertyreasonsellinghomItemModel>> addnewpropertyreasonsellinghomItemList = Rx([AddnewpropertyreasonsellinghomItemModel(upgradingMyHome: "Upgrading my home".obs),AddnewpropertyreasonsellinghomItemModel(upgradingMyHome: "Selling secondary home".obs),AddnewpropertyreasonsellinghomItemModel(upgradingMyHome: "Relocating".obs),AddnewpropertyreasonsellinghomItemModel(upgradingMyHome: "Downsizing my home".obs),AddnewpropertyreasonsellinghomItemModel(upgradingMyHome: "Retiring".obs)]);

 }
