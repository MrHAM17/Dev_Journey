import '../../../core/app_export.dart';/// This class is used in the [addnewpropertyreasonsellinghom_item_widget] screen.
class AddnewpropertyreasonsellinghomItemModel {AddnewpropertyreasonsellinghomItemModel({this.upgradingMyHome, this.id, }) { upgradingMyHome = upgradingMyHome  ?? Rx("Upgrading my home");id = id  ?? Rx(""); }

Rx<String>? upgradingMyHome;

Rx<String>? id;

 }
