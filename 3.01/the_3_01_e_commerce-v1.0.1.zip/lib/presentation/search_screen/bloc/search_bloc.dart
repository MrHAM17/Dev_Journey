import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:the_3_01_e_commerce/presentation/search_screen/models/search_model.dart';part 'search_event.dart';part 'search_state.dart';/// A bloc that manages the state of a Search according to the event that is dispatched to it.
class SearchBloc extends Bloc<SearchEvent, SearchState> {SearchBloc(SearchState initialState) : super(initialState) { on<SearchInitialEvent>(_onInitialize); }

_onInitialize(SearchInitialEvent event, Emitter<SearchState> emit, ) async  { emit(state.copyWith(searchController: TextEditingController())); } 
 }
