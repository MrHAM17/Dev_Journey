import '../../../core/app_export.dart';/// This class is used in the [reviewproduct_item_widget] screen.
class ReviewproductItemModel {ReviewproductItemModel({this.jamesLawson, this.jamesLawson1, this.description, this.month, this.id, }) { jamesLawson = jamesLawson  ?? ImageConstant.imgProfilePicture;jamesLawson1 = jamesLawson1  ?? "James Lawson";description = description  ?? "air max are always very comfortable fit, clean and just perfect in every way. just the box was too small and scrunched the sneakers up a little bit, not sure if the box was always this small but the 90s are and will always be one of my favorites.";month = month  ?? "December 10, 2016";id = id  ?? ""; }

String? jamesLawson;

String? jamesLawson1;

String? description;

String? month;

String? id;

 }
