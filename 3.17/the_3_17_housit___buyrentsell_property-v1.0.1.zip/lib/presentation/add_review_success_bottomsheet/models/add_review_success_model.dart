// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [add_review_success_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class AddReviewSuccessModel extends Equatable {AddReviewSuccessModel() {  }

AddReviewSuccessModel copyWith() { return AddReviewSuccessModel(
); } 
@override List<Object?> get props => [];
 }
