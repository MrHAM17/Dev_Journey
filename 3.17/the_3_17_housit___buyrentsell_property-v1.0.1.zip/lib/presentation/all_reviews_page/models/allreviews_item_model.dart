import '../../../core/app_export.dart';/// This class is used in the [allreviews_item_widget] screen.
class AllreviewsItemModel {AllreviewsItemModel({this.fairviewApartment, this.fairviewApartment1, this.image, this.text, this.semarangIndonesia, this.geraldo, this.geraldo1, this.description, this.time, this.id, }) { fairviewApartment = fairviewApartment  ?? ImageConstant.imgShape36x74;fairviewApartment1 = fairviewApartment1  ?? "Fairview Apartment";image = image  ?? ImageConstant.imgSignalYellow7009x9;text = text  ?? "4.9";semarangIndonesia = semarangIndonesia  ?? "Semarang, Indonesia";geraldo = geraldo  ?? ImageConstant.imgShape23;geraldo1 = geraldo1  ?? "Geraldo";description = description  ?? "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ";time = time  ?? "10 mins ago";id = id  ?? ""; }

String? fairviewApartment;

String? fairviewApartment1;

String? image;

String? text;

String? semarangIndonesia;

String? geraldo;

String? geraldo1;

String? description;

String? time;

String? id;

 }
