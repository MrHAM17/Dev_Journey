import '../../../core/app_export.dart';/// This class is used in the [locationlist_item_widget] screen.
class LocationlistItemModel {LocationlistItemModel({this.id}) { id = id  ?? ""; }

String? id;

 }
