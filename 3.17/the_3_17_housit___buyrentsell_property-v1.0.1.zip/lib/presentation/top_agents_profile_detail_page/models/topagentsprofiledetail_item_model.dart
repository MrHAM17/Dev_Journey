import '../../../core/app_export.dart';/// This class is used in the [topagentsprofiledetail_item_widget] screen.
class TopagentsprofiledetailItemModel {TopagentsprofiledetailItemModel({this.brookvaleVilla, this.price, this.month, this.brookvaleVilla1, this.image, this.text, this.jakartaIndonesia, this.id, }) { brookvaleVilla = brookvaleVilla  ?? ImageConstant.imgShape17;price = price  ?? " 320";month = month  ?? "/month";brookvaleVilla1 = brookvaleVilla1  ?? "Brookvale Villa";image = image  ?? ImageConstant.imgSignalOrange3009x9;text = text  ?? "5";jakartaIndonesia = jakartaIndonesia  ?? "Jakarta, Indonesia";id = id  ?? ""; }

String? brookvaleVilla;

String? price;

String? month;

String? brookvaleVilla1;

String? image;

String? text;

String? jakartaIndonesia;

String? id;

 }
