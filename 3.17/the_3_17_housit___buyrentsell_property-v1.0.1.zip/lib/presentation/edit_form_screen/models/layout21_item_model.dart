import '../../../core/app_export.dart';/// This class is used in the [layout21_item_widget] screen.
class Layout21ItemModel {Layout21ItemModel({this.bedroom, this.text, this.id, }) { bedroom = bedroom  ?? "Bedroom";text = text  ?? "2";id = id  ?? ""; }

String? bedroom;

String? text;

String? id;

 }
