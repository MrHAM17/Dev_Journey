import '../../../core/app_export.dart';/// This class is used in the [preferableselected_item_widget] screen.
class PreferableselectedItemModel {PreferableselectedItemModel({this.apartment, this.checkmark, this.apartment1, this.id, }) { apartment = apartment  ?? ImageConstant.imgShape49;checkmark = checkmark  ?? ImageConstant.imgCheckmarkWhiteA700;apartment1 = apartment1  ?? "Apartment";id = id  ?? ""; }

String? apartment;

String? checkmark;

String? apartment1;

String? id;

 }
