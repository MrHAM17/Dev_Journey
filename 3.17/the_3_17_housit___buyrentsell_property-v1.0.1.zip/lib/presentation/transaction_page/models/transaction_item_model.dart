import '../../../core/app_export.dart';/// This class is used in the [transaction_item_widget] screen.
class TransactionItemModel {TransactionItemModel({this.wingsTower, this.wingsTower1, this.date, this.id, }) { wingsTower = wingsTower  ?? ImageConstant.imgShape17;wingsTower1 = wingsTower1  ?? "Wings Tower";date = date  ?? "November 21,2021";id = id  ?? ""; }

String? wingsTower;

String? wingsTower1;

String? date;

String? id;

 }
