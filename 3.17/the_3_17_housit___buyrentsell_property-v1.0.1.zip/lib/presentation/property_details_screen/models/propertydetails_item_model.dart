import '../../../core/app_export.dart';/// This class is used in the [propertydetails_item_widget] screen.
class PropertydetailsItemModel {PropertydetailsItemModel({this.wingsTower, this.price, this.month, this.wingsTower1, this.text, this.jakartaIndonesia, this.skyDandelions, this.price1, this.month1, this.skyDandelions1, this.text1, this.jakartaIndonesia1, this.id, }) { wingsTower = wingsTower  ?? ImageConstant.imgShape2;price = price  ?? " 220";month = month  ?? "/month";wingsTower1 = wingsTower1  ?? "Wings Tower";text = text  ?? "4.2";jakartaIndonesia = jakartaIndonesia  ?? "Jakarta, Indonesia";skyDandelions = skyDandelions  ?? ImageConstant.imgShape1;price1 = price1  ?? " 190";month1 = month1  ?? "/month";skyDandelions1 = skyDandelions1  ?? "Sky Dandelions ";text1 = text1  ?? "4.9";jakartaIndonesia1 = jakartaIndonesia1  ?? "Jakarta, Indonesia";id = id  ?? ""; }

String? wingsTower;

String? price;

String? month;

String? wingsTower1;

String? text;

String? jakartaIndonesia;

String? skyDandelions;

String? price1;

String? month1;

String? skyDandelions1;

String? text1;

String? jakartaIndonesia1;

String? id;

 }
