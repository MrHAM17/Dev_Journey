// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [select_location_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class SelectLocationModel extends Equatable {SelectLocationModel() {  }

SelectLocationModel copyWith() { return SelectLocationModel(
); } 
@override List<Object?> get props => [];
 }
