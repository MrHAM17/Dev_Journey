import '../../../core/app_export.dart';/// This class is used in the [promotionbanner_item_widget] screen.
class PromotionbannerItemModel {PromotionbannerItemModel({this.halloweenSale, this.offer, this.id, }) { halloweenSale = halloweenSale  ?? "Halloween \nSale!";offer = offer  ?? "All discount up to 60%";id = id  ?? ""; }

String? halloweenSale;

String? offer;

String? id;

 }
