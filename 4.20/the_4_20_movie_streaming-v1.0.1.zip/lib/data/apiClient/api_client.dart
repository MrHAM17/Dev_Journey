import 'package:the_4_20_movie_streaming/core/app_export.dart';

class ApiClient extends GetConnect {}
