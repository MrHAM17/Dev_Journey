import '../../../core/app_export.dart';

/// This class is used in the [frameseventynine_item_widget] screen.
class FrameseventynineItemModel {
  Rx<String>? tags = Rx("Mark Love");

  Rx<bool>? isSelected = Rx(false);
}
