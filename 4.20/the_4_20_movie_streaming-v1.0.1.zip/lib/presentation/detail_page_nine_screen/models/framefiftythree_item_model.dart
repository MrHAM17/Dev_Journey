import '../../../core/app_export.dart';

/// This class is used in the [framefiftythree_item_widget] screen.
class FramefiftythreeItemModel {
  Rx<String>? tags = Rx("Action");

  Rx<bool>? isSelected = Rx(false);
}
