import '../explore_six_screen/widgets/exploresix_item_widget.dart';
import 'controller/explore_six_controller.dart';
import 'models/exploresix_item_model.dart';
import 'package:flutter/material.dart';
import 'package:the_4_20_movie_streaming/core/app_export.dart';
import 'package:the_4_20_movie_streaming/widgets/app_bar/appbar_leading_image.dart';
import 'package:the_4_20_movie_streaming/widgets/app_bar/appbar_title_searchview.dart';
import 'package:the_4_20_movie_streaming/widgets/app_bar/custom_app_bar.dart';

class ExploreSixScreen extends GetWidget<ExploreSixController> {
  const ExploreSixScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(vertical: 28.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text("lbl_explore_movies".tr,
                              style: theme.textTheme.headlineSmall)),
                      SizedBox(height: 8.v),
                      Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text("msg_find_something_you".tr,
                              style: CustomTextStyles
                                  .bodyMediumOnPrimaryContainer)),
                      SizedBox(height: 26.v),
                      _buildAction(),
                      SizedBox(height: 17.v),
                      _buildExploreSix()
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        height: 48.v,
        leadingWidth: 40.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 16.h, top: 8.v, bottom: 8.v),
            onTap: () {
              onTapArrowLeft();
            }),
        title: AppbarTitleSearchview(
            margin: EdgeInsets.only(left: 12.h),
            hintText: "lbl_search_movie".tr,
            controller: controller.searchController));
  }

  /// Section Widget
  Widget _buildAction() {
    return Align(
        alignment: Alignment.center,
        child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.h),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text("lbl_action".tr, style: theme.textTheme.titleSmall),
              Spacer(),
              Text("lbl_more".tr, style: CustomTextStyles.bodySmallWhiteA700_1),
              CustomImageView(
                  imagePath: ImageConstant.imgIconPrimary,
                  height: 18.adaptSize,
                  width: 18.adaptSize,
                  margin: EdgeInsets.only(left: 5.h))
            ])));
  }

  /// Section Widget
  Widget _buildExploreSix() {
    return Expanded(
        child: Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Obx(() => GridView.builder(
                shrinkWrap: true,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    mainAxisExtent: 223.v,
                    crossAxisCount: 3,
                    mainAxisSpacing: 16.h,
                    crossAxisSpacing: 16.h),
                physics: BouncingScrollPhysics(),
                itemCount: controller
                    .exploreSixModelObj.value.exploresixItemList.value.length,
                itemBuilder: (context, index) {
                  ExploresixItemModel model = controller
                      .exploreSixModelObj.value.exploresixItemList.value[index];
                  return ExploresixItemWidget(model, onTapMovieCard: () {
                    onTapMovieCard();
                  });
                }))));
  }

  /// Navigates to the detailPageSevenScreen when the action is triggered.
  onTapMovieCard() {
    Get.toNamed(AppRoutes.detailPageSevenScreen);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }
}
