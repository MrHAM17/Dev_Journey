package com.streetstyleecommerceapp.app.modules.product.`data`.model

import kotlin.String

data class ImageSliderTwelveModel(
  /**
   * TODO Replace with dynamic value
   */
  var imageImage: String? = ""

)
