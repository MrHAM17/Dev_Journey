import '../../../core/app_export.dart';

class ProfileModel {
  String suzaneJobs = "";

  String email = "";
}
