import '../../../core/app_export.dart';
import 'cards_item_model.dart';

class CardsModel {
  List<CardsItemModel> cardsItemList = [
    CardsItemModel(
        jonathanAnderson: "Jonathan Anderson",
        text: "1222 3443 9881 1222",
        balance: "Balance",
        price: " 31,250"),
    CardsItemModel(
        jonathanAnderson: "Jonathan Anderson",
        text: "1222 3443 9881 1222",
        balance: "Balance",
        price: " 31,250")
  ];
}
