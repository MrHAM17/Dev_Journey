import '../../../core/app_export.dart';
import 'electricbill_item_model.dart';

class ElectricBillModel {
  List<ElectricbillItemModel> electricbillItemList = [
    ElectricbillItemModel(
        jonathanAnderson: "Jonathan Anderson",
        text: "1222 3443 9881 1222",
        balance: "Balance",
        price: " 31,250")
  ];
}
