import '../../../core/app_export.dart';

class BilPaymentSuccessModel {}
