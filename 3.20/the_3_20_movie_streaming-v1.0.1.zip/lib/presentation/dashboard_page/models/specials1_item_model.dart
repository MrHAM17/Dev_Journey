import '../../../core/app_export.dart';

/// This class is used in the [specials1_item_widget] screen.
class Specials1ItemModel {
  Specials1ItemModel({
    this.image,
    this.title,
    this.id,
  }) {
    image = image ?? ImageConstant.imgThumbnailImage3;
    title = title ?? "Jumanji The Next Level";
    id = id ?? "";
  }

  String? image;

  String? title;

  String? id;
}
