import 'package:the_3_20_movie_streaming/core/app_export.dart';

class ApiClient {}
