// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [your_likes_tab_container_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class YourLikesTabContainerModel extends Equatable {YourLikesTabContainerModel() {  }

YourLikesTabContainerModel copyWith() { return YourLikesTabContainerModel(
); } 
@override List<Object?> get props => [];
 }
