import '../../../core/app_export.dart';/// This class is used in the [frame2_item_widget] screen.
class Frame2ItemModel {Frame2ItemModel({this.theJordanHarb, this.billSullivan, this.id, }) { theJordanHarb = theJordanHarb  ?? ImageConstant.imgImage31;billSullivan = billSullivan  ?? "The Jordan Harb...";id = id  ?? ""; }

String? theJordanHarb;

String? billSullivan;

String? id;

 }
