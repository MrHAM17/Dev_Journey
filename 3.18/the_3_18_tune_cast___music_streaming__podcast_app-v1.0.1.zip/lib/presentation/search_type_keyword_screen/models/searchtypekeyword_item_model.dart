import '../../../core/app_export.dart';/// This class is used in the [searchtypekeyword_item_widget] screen.
class SearchtypekeywordItemModel {SearchtypekeywordItemModel({this.arianaGrande, this.id, }) { arianaGrande = arianaGrande  ?? "Ariana Grande";id = id  ?? ""; }

String? arianaGrande;

String? id;

 }
