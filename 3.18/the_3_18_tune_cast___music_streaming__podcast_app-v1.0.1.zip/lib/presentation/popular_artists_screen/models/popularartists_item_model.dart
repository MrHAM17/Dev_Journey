import '../../../core/app_export.dart';/// This class is used in the [popularartists_item_widget] screen.
class PopularartistsItemModel {PopularartistsItemModel({this.arianaGrande, this.artistsName, this.id, }) { arianaGrande = arianaGrande  ?? ImageConstant.imgImage21;artistsName = artistsName  ?? "Ariana Grande";id = id  ?? ""; }

String? arianaGrande;

String? artistsName;

String? id;

 }
