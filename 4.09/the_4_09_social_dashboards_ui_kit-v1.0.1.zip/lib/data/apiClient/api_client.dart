import 'package:the_4_09_social_dashboards_ui_kit/core/app_export.dart';

class ApiClient extends GetConnect {}
