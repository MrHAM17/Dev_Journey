import '../../../core/app_export.dart';

/// This class is used in the [tags_item_widget] screen.
class TagsItemModel {
  Rx<String>? chipSmall = Rx("Travel");

  Rx<bool>? isSelected = Rx(false);
}
