import '../events_page/widgets/events_item_widget.dart';
import 'controller/events_controller.dart';
import 'models/events_item_model.dart';
import 'models/events_model.dart';
import 'package:flutter/material.dart';
import 'package:the_4_09_social_dashboards_ui_kit/core/app_export.dart';

class EventsPage extends StatelessWidget {
  EventsPage({Key? key})
      : super(
          key: key,
        );

  EventsController controller = Get.put(EventsController(EventsModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillGray,
          child: Column(
            children: [
              SizedBox(height: 26.v),
              _buildEvents(),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEvents() {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 28.h),
        child: Obx(
          () => ListView.separated(
            physics: BouncingScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (
              context,
              index,
            ) {
              return SizedBox(
                height: 18.v,
              );
            },
            itemCount:
                controller.eventsModelObj.value.eventsItemList.value.length,
            itemBuilder: (context, index) {
              EventsItemModel model =
                  controller.eventsModelObj.value.eventsItemList.value[index];
              return EventsItemWidget(
                model,
              );
            },
          ),
        ),
      ),
    );
  }
}
