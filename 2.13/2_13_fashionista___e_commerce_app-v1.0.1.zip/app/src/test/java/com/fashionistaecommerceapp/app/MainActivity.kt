package com.fashionistaecommerceapp.app

import com.fashionistaecommerceapp.app.appcomponents.base.BaseActivity
import com.fashionistaecommerceapp.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}