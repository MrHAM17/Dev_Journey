package com.fashionistaecommerceapp.app.modules.homecontainer.`data`.model

class HomeContainerModel()
