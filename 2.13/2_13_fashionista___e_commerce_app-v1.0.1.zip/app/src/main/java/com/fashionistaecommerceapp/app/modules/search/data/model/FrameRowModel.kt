package com.fashionistaecommerceapp.app.modules.search.`data`.model

class FrameRowModel()
