package com.banksydigitalbanking.app.modules.moneyexchange.`data`.model

import kotlin.String

data class SpinnerFavoriteModel(
  val itemName: String
)
