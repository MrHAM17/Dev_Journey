package com.banksydigitalbanking.app.modules.splash.`data`.model

class SplashModel()
