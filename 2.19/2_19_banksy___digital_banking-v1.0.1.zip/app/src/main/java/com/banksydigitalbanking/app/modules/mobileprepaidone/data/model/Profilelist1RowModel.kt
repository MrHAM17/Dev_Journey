package com.banksydigitalbanking.app.modules.mobileprepaidone.`data`.model

class Profilelist1RowModel()
