package com.banksydigitalbanking.app.modules.sendmoney.`data`.model

class ProfilelistRowModel()
