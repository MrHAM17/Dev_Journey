package com.banksydigitalbanking.app.modules.history.`data`.model

import kotlin.String

data class SpinnerFavoriteModel(
  val itemName: String
)
