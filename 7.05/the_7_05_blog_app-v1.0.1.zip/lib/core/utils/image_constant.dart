class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Home images
  static String imgThumbnail = '$imagePath/img_thumbnail.png';

  // Interests People images
  static String imgProfilePicture = '$imagePath/img_profile_picture.png';

  // Privacy Policy images
  static String imgGroup14 = '$imagePath/img_group_14.svg';

  // Notifications images
  static String imgUnsplash93bshrwb1yq =
      '$imagePath/img_unsplash_93bshrwb1yq.png';

  // Common images
  static String imgMegaphone = '$imagePath/img_megaphone.svg';

  static String imgFrame11 = '$imagePath/img_frame_11.svg';

  static String imgRewind = '$imagePath/img_rewind.svg';

  static String imgBookmarkIcon = '$imagePath/img_bookmark_icon.svg';

  static String imgBlogThumbnail = '$imagePath/img_blog_thumbnail.png';

  static String imgDhiwiseBlackMonogram =
      '$imagePath/img_dhiwise_black_monogram.png';

  static String imgGoogle1 = '$imagePath/img_google_1.png';

  static String imgFacebook1 = '$imagePath/img_facebook_1.png';

  static String imgTwitter1 = '$imagePath/img_twitter_1.png';

  static String imgAppleblacklogo1 = '$imagePath/img_appleblacklogo_1.png';

  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgClose = '$imagePath/img_close.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
