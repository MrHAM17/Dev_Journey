import '../../../core/app_export.dart';
import 'intereststopics_item_model.dart';

class InterestsTopicsModel {
  List<IntereststopicsItemModel> intereststopicsItemList = [
    IntereststopicsItemModel(easyToUse: "Art"),
    IntereststopicsItemModel(easyToUse: "Books"),
    IntereststopicsItemModel(easyToUse: "Comics"),
    IntereststopicsItemModel(easyToUse: "Fiction"),
    IntereststopicsItemModel(easyToUse: "Film"),
    IntereststopicsItemModel(easyToUse: "Gaming"),
    IntereststopicsItemModel(easyToUse: "Humor"),
    IntereststopicsItemModel(easyToUse: "Music"),
    IntereststopicsItemModel(easyToUse: "Nonfiction"),
    IntereststopicsItemModel(easyToUse: "Art")
  ];
}
