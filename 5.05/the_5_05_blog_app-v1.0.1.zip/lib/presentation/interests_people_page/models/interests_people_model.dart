import '../../../core/app_export.dart';
import 'interestspeople_item_model.dart';

class InterestsPeopleModel {
  List<InterestspeopleItemModel> interestspeopleItemList = [
    InterestspeopleItemModel(morePeopleToFollow: "MORE PEOPLE TO FOLLOW")
  ];
}
