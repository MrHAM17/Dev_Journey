import '../../../core/app_export.dart';
import 'stories1_item_model.dart';

class ExploreModel {
  List<Stories1ItemModel> stories1ItemList = [
    Stories1ItemModel(
        home: "LOGO",
        easyToUse: "Lorem Ipsum dolor set amet",
        duration: "16 days ago",
        time: "3 min read")
  ];
}
