import 'intrestrow1_item_model.dart';
import '../../../core/app_export.dart';

class InterestsModel {
  List<Intrestrow1ItemModel> intrestrow1ItemList =
      List.generate(27, (index) => Intrestrow1ItemModel());
}
