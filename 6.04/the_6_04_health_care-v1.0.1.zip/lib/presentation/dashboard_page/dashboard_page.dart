import '../dashboard_page/widgets/doctor_item_widget.dart';
import '../dashboard_page/widgets/fortyseven_item_widget.dart';
import 'models/doctor_item_model.dart';
import 'models/fortyseven_item_model.dart';
import 'notifier/dashboard_notifier.dart';
import 'package:flutter/material.dart';
import 'package:the_6_04_health_care/core/app_export.dart';
import 'package:the_6_04_health_care/widgets/app_bar/appbar_title.dart';
import 'package:the_6_04_health_care/widgets/app_bar/appbar_trailing_image.dart';
import 'package:the_6_04_health_care/widgets/app_bar/custom_app_bar.dart';
import 'package:the_6_04_health_care/widgets/custom_elevated_button.dart';
import 'package:the_6_04_health_care/widgets/custom_search_view.dart';

class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  DashboardPageState createState() => DashboardPageState();
}

class DashboardPageState extends ConsumerState<DashboardPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 13.v),
                    child: Padding(
                        padding: EdgeInsets.only(left: 20.h, bottom: 5.v),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                  padding: EdgeInsets.only(right: 20.h),
                                  child: Consumer(builder: (context, ref, _) {
                                    return CustomSearchView(
                                        controller: ref
                                            .watch(dashboardNotifier)
                                            .searchController,
                                        hintText: "msg_search_doctor_drugs".tr);
                                  })),
                              SizedBox(height: 20.v),
                              _buildFortySeven(context),
                              SizedBox(height: 20.v),
                              _buildOfferBanner(context),
                              SizedBox(height: 42.v),
                              _buildTopDoctorSeeAll(context),
                              SizedBox(height: 10.v),
                              _buildDoctor(context),
                              SizedBox(height: 31.v),
                              _buildHealtArticleSee(context),
                              SizedBox(height: 12.v),
                              _buildArticle(context)
                            ]))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        height: 90.v,
        title: AppbarTitle(
            text: "msg_find_your_desire".tr,
            margin: EdgeInsets.only(left: 20.h)),
        actions: [
          AppbarTrailingImage(
              imagePath: ImageConstant.imgUser,
              margin: EdgeInsets.fromLTRB(20.h, 14.v, 20.h, 31.v))
        ]);
  }

  /// Section Widget
  Widget _buildFortySeven(BuildContext context) {
    return SizedBox(
        height: 71.v,
        child: Consumer(builder: (context, ref, _) {
          return ListView.separated(
              padding: EdgeInsets.only(right: 20.h),
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) {
                return SizedBox(width: 17.h);
              },
              itemCount: ref
                      .watch(dashboardNotifier)
                      .dashboardModelObj
                      ?.fortysevenItemList
                      .length ??
                  0,
              itemBuilder: (context, index) {
                FortysevenItemModel model = ref
                        .watch(dashboardNotifier)
                        .dashboardModelObj
                        ?.fortysevenItemList[index] ??
                    FortysevenItemModel();
                return FortysevenItemWidget(model, onTapBtnTicket: () {
                  onTapBtnTicket(context);
                });
              });
        }));
  }

  /// Section Widget
  Widget _buildOfferBanner(BuildContext context) {
    return Container(
        width: 335.h,
        margin: EdgeInsets.only(right: 20.h),
        padding: EdgeInsets.symmetric(horizontal: 26.h, vertical: 12.v),
        decoration: AppDecoration.fillTeal
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 4.v),
              SizedBox(
                  width: 168.h,
                  child: Text("msg_early_protection".tr,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.titleMedium18
                          .copyWith(height: 1.50))),
              SizedBox(height: 7.v),
              CustomElevatedButton(
                  height: 26.v,
                  width: 106.h,
                  text: "lbl_learn_more".tr,
                  buttonStyle: CustomButtonStyles.fillCyan,
                  buttonTextStyle: CustomTextStyles.labelLargePrimarySemiBold)
            ]));
  }

  /// Section Widget
  Widget _buildTopDoctorSeeAll(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(right: 20.h),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("lbl_top_doctor".tr, style: theme.textTheme.titleMedium),
              GestureDetector(
                  onTap: () {
                    onTapTxtSeeAll(context);
                  },
                  child: Padding(
                      padding: EdgeInsets.only(bottom: 5.v),
                      child: Text("lbl_see_all".tr,
                          style: CustomTextStyles.labelLargeCyan300)))
            ]));
  }

  /// Section Widget
  Widget _buildDoctor(BuildContext context) {
    return SizedBox(
        height: 173.v,
        child: Consumer(builder: (context, ref, _) {
          return ListView.separated(
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) {
                return SizedBox(width: 14.h);
              },
              itemCount: ref
                      .watch(dashboardNotifier)
                      .dashboardModelObj
                      ?.doctorItemList
                      .length ??
                  0,
              itemBuilder: (context, index) {
                DoctorItemModel model = ref
                        .watch(dashboardNotifier)
                        .dashboardModelObj
                        ?.doctorItemList[index] ??
                    DoctorItemModel();
                return DoctorItemWidget(model, onTapDoctor: () {
                  onTapDoctor(context);
                });
              });
        }));
  }

  /// Section Widget
  Widget _buildHealtArticleSee(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(right: 23.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text("lbl_healt_article".tr, style: theme.textTheme.titleMedium),
          GestureDetector(
              onTap: () {
                onTapTxtSeeAll1(context);
              },
              child: Padding(
                  padding: EdgeInsets.only(bottom: 3.v),
                  child: Text("lbl_see_all".tr,
                      style: CustomTextStyles.labelLargeCyan300)))
        ]));
  }

  /// Section Widget
  Widget _buildArticle(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(right: 20.h),
        padding: EdgeInsets.all(5.h),
        decoration: AppDecoration.outlineGray
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
        child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              CustomImageView(
                  imagePath: ImageConstant.imgThumbnail,
                  height: 55.adaptSize,
                  width: 55.adaptSize,
                  radius: BorderRadius.circular(6.h)),
              Padding(
                  padding: EdgeInsets.only(left: 12.h, bottom: 5.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            width: 179.h,
                            child: Text("msg_the_25_healthiest".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: CustomTextStyles.labelMediumOnPrimary
                                    .copyWith(height: 1.50))),
                        SizedBox(height: 8.v),
                        Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("lbl_jun_10_2021".tr,
                                  style: theme.textTheme.labelSmall),
                              Container(
                                  height: 2.adaptSize,
                                  width: 2.adaptSize,
                                  margin: EdgeInsets.only(
                                      left: 5.h, top: 3.v, bottom: 4.v),
                                  decoration: BoxDecoration(
                                      color: appTheme.gray500,
                                      borderRadius:
                                          BorderRadius.circular(1.h))),
                              Padding(
                                  padding: EdgeInsets.only(left: 5.h),
                                  child: Text("lbl_5min_read".tr,
                                      style: theme.textTheme.labelSmall))
                            ])
                      ]))
            ]));
  }

  /// Navigates to the drListScreen when the action is triggered.
  onTapTxtSeeAll(BuildContext context) {
    NavigatorService.pushNamed(AppRoutes.drListScreen);
  }

  /// Navigates to the articleScreen when the action is triggered.
  onTapTxtSeeAll1(BuildContext context) {
    NavigatorService.pushNamed(AppRoutes.articleScreen);
  }

  /// Navigates to the drDetailsScreen when the action is triggered.
  onTapDoctor(BuildContext context) {
    NavigatorService.pushNamed(AppRoutes.drDetailsScreen);
  }

  /// Navigates to the drListScreen when the action is triggered.
  onTapBtnTicket(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.drListScreen,
    );
  }
}
