import 'timeslots_item_model.dart';
import '../../../core/app_export.dart';

class DrDetailsModel {
  List<TimeslotsItemModel> timeslotsItemList =
      List.generate(9, (index) => TimeslotsItemModel());
}
