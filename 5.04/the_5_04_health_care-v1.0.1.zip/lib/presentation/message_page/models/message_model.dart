import '../../../core/app_export.dart';
import 'chat_item_model.dart';

class MessageModel {
  List<ChatItemModel> chatItemList = [
    ChatItemModel(
        drMarcusHorizon: ImageConstant.imgProfileThumbnail,
        drMarcusHorizon1: "Dr. Marcus Horizon",
        iDonTHaveAny: "I don,t have any fever, but headchace...",
        time: "10.24")
  ];
}
