import 'package:flutter/material.dart';
import 'package:the_7_13_fashionista___e_commerce_app/core/app_export.dart';
import 'package:the_7_13_fashionista___e_commerce_app/widgets/app_bar/appbar_leading_iconbutton_one.dart';
import 'package:the_7_13_fashionista___e_commerce_app/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:the_7_13_fashionista___e_commerce_app/widgets/app_bar/custom_app_bar.dart';
import 'package:the_7_13_fashionista___e_commerce_app/widgets/custom_switch.dart';

// ignore_for_file: must_be_immutable
class SettingsScreen extends StatelessWidget {
  SettingsScreen({Key? key}) : super(key: key);

  bool isSelectedSwitch = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 24.v),
                child: Column(children: [
                  _buildFrame1(context),
                  SizedBox(height: 26.v),
                  _buildFrame6(context),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 56.h,
        leading: AppbarLeadingIconbuttonOne(
            imagePath: ImageConstant.imgArrowDown,
            margin: EdgeInsets.only(left: 16.h, top: 5.v, bottom: 5.v),
            onTap: () {
              onTapArrowDown(context);
            }),
        centerTitle: true,
        title: AppbarSubtitleOne(text: "Settings"));
  }

  /// Section Widget
  Widget _buildFrame1(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(16.h),
        decoration: AppDecoration.fillGray
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder12),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          CustomImageView(
              imagePath: ImageConstant.imgEllipse45,
              height: 64.adaptSize,
              width: 64.adaptSize,
              radius: BorderRadius.circular(32.h)),
          Padding(
              padding: EdgeInsets.only(left: 16.h, top: 6.v, bottom: 6.v),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Anne Christion", style: CustomTextStyles.bodyLarge18),
                    SizedBox(height: 3.v),
                    Text("Premium User",
                        style: CustomTextStyles.bodyMediumGray500_1)
                  ])),
          Spacer(),
          CustomImageView(
              imagePath: ImageConstant.imgArrowRight,
              height: 16.adaptSize,
              width: 16.adaptSize,
              margin: EdgeInsets.symmetric(vertical: 24.v))
        ]));
  }

  /// Section Widget
  Widget _buildFrame6(BuildContext context) {
    return Column(children: [
      Align(
          alignment: Alignment.centerLeft,
          child: Text("Settings", style: theme.textTheme.titleMedium)),
      SizedBox(height: 9.v),
      GestureDetector(
          onTap: () {
            onTapFrame(context);
          },
          child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 11.v),
              decoration: AppDecoration.fillGray
                  .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
              child:
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                CustomImageView(
                    imagePath: ImageConstant.imgNotificationsActive,
                    height: 24.adaptSize,
                    width: 24.adaptSize),
                Padding(
                    padding: EdgeInsets.only(left: 24.h),
                    child: Text("Notifications",
                        style: theme.textTheme.bodyLarge)),
                Spacer(),
                CustomSwitch(
                    margin: EdgeInsets.symmetric(vertical: 4.v),
                    value: isSelectedSwitch,
                    onChange: (value) {
                      isSelectedSwitch = value;
                    })
              ]))),
      SizedBox(height: 16.v),
      _buildFrame(context,
          timer: ImageConstant.imgTimeline,
          orderStatus: "Tracking Order", onTapFrame: () {
        onTapFrame1(context);
      }),
      SizedBox(height: 16.v),
      _buildFrame(context,
          timer: ImageConstant.imgTimer,
          orderStatus: "Order Status", onTapFrame: () {
        onTapFrame2(context);
      }),
      SizedBox(height: 16.v),
      _buildFrame(context,
          timer: ImageConstant.imgTranslate, orderStatus: "Language"),
      SizedBox(height: 16.v),
      _buildFrame(context,
          timer: ImageConstant.imgQuestionAnswer, orderStatus: "FAQs")
    ]);
  }

  /// Common widget
  Widget _buildFrame(
    BuildContext context, {
    required String timer,
    required String orderStatus,
    Function? onTapFrame,
  }) {
    return GestureDetector(
        onTap: () {
          onTapFrame!.call();
        },
        child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 11.v),
            decoration: AppDecoration.fillGray
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              CustomImageView(
                  imagePath: timer, height: 24.adaptSize, width: 24.adaptSize),
              Padding(
                  padding: EdgeInsets.only(left: 24.h),
                  child: Text(orderStatus,
                      style: theme.textTheme.bodyLarge!
                          .copyWith(color: theme.colorScheme.primary))),
              Spacer(),
              CustomImageView(
                  imagePath: ImageConstant.imgArrowRight,
                  height: 16.adaptSize,
                  width: 16.adaptSize,
                  margin: EdgeInsets.symmetric(vertical: 4.v))
            ])));
  }

  /// Navigates back to the previous screen.
  onTapArrowDown(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the notificationScreen when the action is triggered.
  onTapFrame(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.notificationScreen);
  }

  /// Navigates to the trackingOrderScreen when the action is triggered.
  onTapFrame1(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.trackingOrderScreen);
  }

  /// Navigates to the orderStatusScreen when the action is triggered.
  onTapFrame2(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.orderStatusScreen);
  }
}
