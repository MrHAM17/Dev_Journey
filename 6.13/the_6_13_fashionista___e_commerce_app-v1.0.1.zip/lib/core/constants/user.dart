class User {
  static int role = 1;
}
