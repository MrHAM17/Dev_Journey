import '../../../core/app_export.dart';/// This class is used in the [tickets_item_widget] screen.
class TicketsItemModel {TicketsItemModel({this.bulgariResort, this.bulgariResort1, this.parisFrance, this.yeayyouhavecompletedit, this.id, }) { bulgariResort = bulgariResort  ?? ImageConstant.imgRectangle;bulgariResort1 = bulgariResort1  ?? "Bulgari Resort";parisFrance = parisFrance  ?? "Paris, France";yeayyouhavecompletedit = yeayyouhavecompletedit  ?? "Yeay, you have completed it!";id = id  ?? ""; }

String? bulgariResort;

String? bulgariResort1;

String? parisFrance;

String? yeayyouhavecompletedit;

String? id;

 }
