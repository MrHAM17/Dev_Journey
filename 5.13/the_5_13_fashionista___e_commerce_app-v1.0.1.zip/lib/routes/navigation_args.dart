class NavigationArgs {
  static String id = "id";
}
