import '../../../core/app_export.dart';
import 'mycart_item_model.dart';

class MyCartModel {
  List<MycartItemModel> mycartItemList = [
    MycartItemModel(
        jacket: ImageConstant.imgUnsplash8hqpxttomn0,
        jacket1: "Jacket",
        blackJacket: "Black Jacket",
        sizeXL: "Size: XL",
        one: "1"),
    MycartItemModel(
        jacket: ImageConstant.imgUnsplash8hqpxttomn0171x142,
        jacket1: "Casual",
        blackJacket: "Casual Jeans Shoes",
        sizeXL: "Size: XL",
        one: "1")
  ];
}
