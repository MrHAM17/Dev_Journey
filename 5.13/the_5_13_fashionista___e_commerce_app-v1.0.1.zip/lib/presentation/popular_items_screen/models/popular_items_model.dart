import '../../../core/app_export.dart';
import 'popularitems_item_model.dart';

class PopularItemsModel {
  List<PopularitemsItemModel> popularitemsItemList = [
    PopularitemsItemModel(
        blackJacket: ImageConstant.imgUnsplashEmlkhdeydhg4,
        casualJeansShoes: "Black Jacket"),
    PopularitemsItemModel(
        blackJacket: ImageConstant.imgUnsplashEmlkhdeydhg5,
        casualJeansShoes: "Black Jacket"),
    PopularitemsItemModel(
        blackJacket: ImageConstant.imgUnsplashEmlkhdeydhg6,
        casualJeansShoes: "Black Jacket"),
    PopularitemsItemModel(
        blackJacket: ImageConstant.imgUnsplashEmlkhdeydhg7,
        casualJeansShoes: "Black Jacket")
  ];
}
