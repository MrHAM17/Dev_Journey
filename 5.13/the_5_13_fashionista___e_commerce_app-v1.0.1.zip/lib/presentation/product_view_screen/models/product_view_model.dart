import 'frame4_item_model.dart';
import '../../../core/app_export.dart';

class ProductViewModel {
  List<Frame4ItemModel> frame4ItemList =
      List.generate(5, (index) => Frame4ItemModel());
}
