import 'frame_item_model.dart';
import '../../../core/app_export.dart';

class ExploreShopModel {
  List<FrameItemModel> frameItemList =
      List.generate(21, (index) => FrameItemModel());
}
