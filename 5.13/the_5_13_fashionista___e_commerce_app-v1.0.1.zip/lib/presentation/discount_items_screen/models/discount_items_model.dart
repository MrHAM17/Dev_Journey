import '../../../core/app_export.dart';
import 'discountitems_item_model.dart';

class DiscountItemsModel {
  List<DiscountitemsItemModel> discountitemsItemList = [
    DiscountitemsItemModel(
        premiumWatch: ImageConstant.imgUnsplashJj0tls2rod4,
        premiumWatch1: "Premium Watch"),
    DiscountitemsItemModel(
        premiumWatch: ImageConstant.imgUnsplashJj0tls2rod458x58,
        premiumWatch1: "Blue shoes"),
    DiscountitemsItemModel(
        premiumWatch: ImageConstant.imgUnsplashJj0tls2rod41,
        premiumWatch1: "Jamdan Dress")
  ];
}
