import 'package:the_4_15_safebank___mobile_banking_app/core/app_export.dart';

class ApiClient extends GetConnect {}
