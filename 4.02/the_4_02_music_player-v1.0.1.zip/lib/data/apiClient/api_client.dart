import 'package:the_4_02_music_player/core/app_export.dart';

class ApiClient extends GetConnect {}
