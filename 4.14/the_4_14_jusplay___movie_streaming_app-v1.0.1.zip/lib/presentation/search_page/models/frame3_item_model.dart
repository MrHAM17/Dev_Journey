import '../../../core/app_export.dart';

/// This class is used in the [frame3_item_widget] screen.
class Frame3ItemModel {
  Rx<String>? tabs = Rx("Marvel");

  Rx<bool>? isSelected = Rx(false);
}
