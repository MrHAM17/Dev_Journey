import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/call_screen/models/call_model.dart';/// A controller class for the CallScreen.
///
/// This class manages the state of the CallScreen, including the
/// current callModelObj
class CallController extends GetxController {Rx<CallModel> callModelObj = CallModel().obs;

 }
