import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/location_fill_screen/models/location_fill_model.dart';/// A controller class for the LocationFillScreen.
///
/// This class manages the state of the LocationFillScreen, including the
/// current locationFillModelObj
class LocationFillController extends GetxController {Rx<LocationFillModel> locationFillModelObj = LocationFillModel().obs;

 }
