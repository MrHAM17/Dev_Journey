import '../../../core/app_export.dart';/// This class is used in the [layout29_item_widget] screen.
class Layout29ItemModel {Layout29ItemModel({this.amanda, this.amanda1, this.id, }) { amanda = amanda  ?? Rx(ImageConstant.imgShape70x70);amanda1 = amanda1  ?? Rx("Amanda");id = id  ?? Rx(""); }

Rx<String>? amanda;

Rx<String>? amanda1;

Rx<String>? id;

 }
