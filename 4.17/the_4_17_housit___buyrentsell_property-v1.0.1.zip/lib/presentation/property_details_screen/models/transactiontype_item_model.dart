import '../../../core/app_export.dart';/// This class is used in the [transactiontype_item_widget] screen.
class TransactiontypeItemModel {Rx<String>? layout = Rx("Rent");

Rx<bool>? isSelected = Rx(false);

 }
