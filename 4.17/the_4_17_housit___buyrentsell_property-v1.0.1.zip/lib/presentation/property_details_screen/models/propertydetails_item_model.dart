import '../../../core/app_export.dart';/// This class is used in the [propertydetails_item_widget] screen.
class PropertydetailsItemModel {PropertydetailsItemModel({this.wingsTower, this.price, this.month, this.wingsTower1, this.text, this.jakartaIndonesia, this.skyDandelions, this.price1, this.month1, this.skyDandelions1, this.text1, this.jakartaIndonesia1, this.id, }) { wingsTower = wingsTower  ?? Rx(ImageConstant.imgShape2);price = price  ?? Rx(" 220");month = month  ?? Rx("/month");wingsTower1 = wingsTower1  ?? Rx("Wings Tower");text = text  ?? Rx("4.2");jakartaIndonesia = jakartaIndonesia  ?? Rx("Jakarta, Indonesia");skyDandelions = skyDandelions  ?? Rx(ImageConstant.imgShape1);price1 = price1  ?? Rx(" 190");month1 = month1  ?? Rx("/month");skyDandelions1 = skyDandelions1  ?? Rx("Sky Dandelions ");text1 = text1  ?? Rx("4.9");jakartaIndonesia1 = jakartaIndonesia1  ?? Rx("Jakarta, Indonesia");id = id  ?? Rx(""); }

Rx<String>? wingsTower;

Rx<String>? price;

Rx<String>? month;

Rx<String>? wingsTower1;

Rx<String>? text;

Rx<String>? jakartaIndonesia;

Rx<String>? skyDandelions;

Rx<String>? price1;

Rx<String>? month1;

Rx<String>? skyDandelions1;

Rx<String>? text1;

Rx<String>? jakartaIndonesia1;

Rx<String>? id;

 }
