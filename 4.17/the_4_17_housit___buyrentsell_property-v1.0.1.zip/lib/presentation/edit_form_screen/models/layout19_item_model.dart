import '../../../core/app_export.dart';/// This class is used in the [layout19_item_widget] screen.
class Layout19ItemModel {Rx<String>? buttonCategory = Rx("Monthly");

Rx<bool>? isSelected = Rx(false);

 }
