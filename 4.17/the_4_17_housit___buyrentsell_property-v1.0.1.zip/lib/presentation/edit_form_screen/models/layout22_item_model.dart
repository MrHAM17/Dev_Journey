import '../../../core/app_export.dart';/// This class is used in the [layout22_item_widget] screen.
class Layout22ItemModel {Rx<String>? buttonCategory = Rx("< 4");

Rx<bool>? isSelected = Rx(false);

 }
