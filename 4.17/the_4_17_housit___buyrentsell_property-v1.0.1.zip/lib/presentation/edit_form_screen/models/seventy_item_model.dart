import '../../../core/app_export.dart';/// This class is used in the [seventy_item_widget] screen.
class SeventyItemModel {Rx<String>? buttonCategory = Rx("Parking Lot");

Rx<bool>? isSelected = Rx(false);

 }
