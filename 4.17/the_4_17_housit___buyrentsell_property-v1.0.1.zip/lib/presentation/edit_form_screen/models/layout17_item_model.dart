import '../../../core/app_export.dart';/// This class is used in the [layout17_item_widget] screen.
class Layout17ItemModel {Rx<String>? buttonCategory = Rx("House");

Rx<bool>? isSelected = Rx(false);

 }
