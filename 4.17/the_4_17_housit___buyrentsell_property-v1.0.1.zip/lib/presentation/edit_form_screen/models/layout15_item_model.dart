import '../../../core/app_export.dart';/// This class is used in the [layout15_item_widget] screen.
class Layout15ItemModel {Rx<String>? buttonCategory = Rx("Rent");

Rx<bool>? isSelected = Rx(false);

 }
