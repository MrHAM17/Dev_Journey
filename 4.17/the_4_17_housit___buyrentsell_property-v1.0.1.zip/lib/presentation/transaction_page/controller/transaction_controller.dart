import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/transaction_page/models/transaction_model.dart';/// A controller class for the TransactionPage.
///
/// This class manages the state of the TransactionPage, including the
/// current transactionModelObj
class TransactionController extends GetxController {TransactionController(this.transactionModelObj);

Rx<TransactionModel> transactionModelObj;

 }
