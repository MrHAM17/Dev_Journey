import '../../../core/app_export.dart';/// This class is used in the [topagentsprofiledetail_item_widget] screen.
class TopagentsprofiledetailItemModel {TopagentsprofiledetailItemModel({this.brookvaleVilla, this.price, this.month, this.brookvaleVilla1, this.image, this.text, this.jakartaIndonesia, this.id, }) { brookvaleVilla = brookvaleVilla  ?? Rx(ImageConstant.imgShape17);price = price  ?? Rx(" 320");month = month  ?? Rx("/month");brookvaleVilla1 = brookvaleVilla1  ?? Rx("Brookvale Villa");image = image  ?? Rx(ImageConstant.imgSignalOrange3009x9);text = text  ?? Rx("5");jakartaIndonesia = jakartaIndonesia  ?? Rx("Jakarta, Indonesia");id = id  ?? Rx(""); }

Rx<String>? brookvaleVilla;

Rx<String>? price;

Rx<String>? month;

Rx<String>? brookvaleVilla1;

Rx<String>? image;

Rx<String>? text;

Rx<String>? jakartaIndonesia;

Rx<String>? id;

 }
