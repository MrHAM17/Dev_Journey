import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/add_location_screen/models/add_location_model.dart';/// A controller class for the AddLocationScreen.
///
/// This class manages the state of the AddLocationScreen, including the
/// current addLocationModelObj
class AddLocationController extends GetxController {Rx<AddLocationModel> addLocationModelObj = AddLocationModel().obs;

 }
