import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/reviews_gallery_screen/models/reviews_gallery_model.dart';/// A controller class for the ReviewsGalleryScreen.
///
/// This class manages the state of the ReviewsGalleryScreen, including the
/// current reviewsGalleryModelObj
class ReviewsGalleryController extends GetxController {Rx<ReviewsGalleryModel> reviewsGalleryModelObj = ReviewsGalleryModel().obs;

 }
