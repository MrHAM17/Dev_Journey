import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/view_screen/models/view_model.dart';/// A controller class for the ViewScreen.
///
/// This class manages the state of the ViewScreen, including the
/// current viewModelObj
class ViewController extends GetxController {Rx<ViewModel> viewModelObj = ViewModel().obs;

 }
