import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/promotion_screen/models/promotion_model.dart';/// A controller class for the PromotionScreen.
///
/// This class manages the state of the PromotionScreen, including the
/// current promotionModelObj
class PromotionController extends GetxController {Rx<PromotionModel> promotionModelObj = PromotionModel().obs;

 }
