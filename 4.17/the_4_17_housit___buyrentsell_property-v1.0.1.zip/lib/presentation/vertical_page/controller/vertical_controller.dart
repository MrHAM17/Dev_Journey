import 'package:the_4_17_housit___buyrentsell_property/core/app_export.dart';import 'package:the_4_17_housit___buyrentsell_property/presentation/vertical_page/models/vertical_model.dart';/// A controller class for the VerticalPage.
///
/// This class manages the state of the VerticalPage, including the
/// current verticalModelObj
class VerticalController extends GetxController {VerticalController(this.verticalModelObj);

Rx<VerticalModel> verticalModelObj;

 }
