import '../../../core/app_export.dart';/// This class is used in the [widget2_item_widget] screen.
class Widget2ItemModel {Rx<String>? buttonCategory = Rx("Home theatre");

Rx<bool>? isSelected = Rx(false);

 }
