import 'widget_item_model.dart';import 'widget2_item_model.dart';import '../../../core/app_export.dart';/// This class defines the variables used in the [filter_full_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class FilterFullModel {Rx<List<WidgetItemModel>> widgetItemList = Rx(List.generate(2,(index) =>WidgetItemModel()));

Rx<List<Widget2ItemModel>> widget2ItemList = Rx(List.generate(7,(index) =>Widget2ItemModel()));

 }
