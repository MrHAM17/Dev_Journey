import '../../../core/app_export.dart';/// This class is used in the [layout4_item_widget] screen.
class Layout4ItemModel {Rx<String>? buttonCategory = Rx("House");

Rx<bool>? isSelected = Rx(false);

 }
