import '../../../core/app_export.dart';/// This class is used in the [layout11_item_widget] screen.
class Layout11ItemModel {Rx<String>? buttonCategory = Rx("Parking Lot");

Rx<bool>? isSelected = Rx(false);

 }
