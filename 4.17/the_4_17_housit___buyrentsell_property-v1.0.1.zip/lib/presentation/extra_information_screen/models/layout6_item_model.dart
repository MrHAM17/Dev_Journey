import '../../../core/app_export.dart';/// This class is used in the [layout6_item_widget] screen.
class Layout6ItemModel {Rx<String>? buttonCategory = Rx("Monthly");

Rx<bool>? isSelected = Rx(false);

 }
