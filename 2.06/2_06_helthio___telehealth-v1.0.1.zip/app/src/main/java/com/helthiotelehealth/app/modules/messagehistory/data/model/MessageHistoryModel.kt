package com.helthiotelehealth.app.modules.messagehistory.`data`.model

class MessageHistoryModel()
