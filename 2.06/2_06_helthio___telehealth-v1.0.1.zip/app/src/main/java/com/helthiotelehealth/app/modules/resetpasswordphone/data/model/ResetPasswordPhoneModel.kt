package com.helthiotelehealth.app.modules.resetpasswordphone.`data`.model

import kotlin.String

data class ResetPasswordPhoneModel(
  /**
   * TODO Replace with dynamic value
   */
  var etMobileNoValue: String? = null
)
