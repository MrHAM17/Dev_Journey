package com.helthiotelehealth.app.modules.schedule.`data`.model

class ScheduleModel()
