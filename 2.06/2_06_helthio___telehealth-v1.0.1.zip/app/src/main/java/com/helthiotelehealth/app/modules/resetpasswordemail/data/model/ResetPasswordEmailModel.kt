package com.helthiotelehealth.app.modules.resetpasswordemail.`data`.model

import kotlin.String

data class ResetPasswordEmailModel(
  /**
   * TODO Replace with dynamic value
   */
  var etEmailValue: String? = null
)
