package com.helthiotelehealth.app.modules.home.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.helthiotelehealth.app.modules.home.`data`.model.CategoriesRowModel
import com.helthiotelehealth.app.modules.home.`data`.model.HomeModel
import com.helthiotelehealth.app.modules.home.`data`.model.HomeRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class HomeVM : ViewModel(), KoinComponent {
  val homeModel: MutableLiveData<HomeModel> = MutableLiveData(HomeModel())

  var navArguments: Bundle? = null

  val categoriesList: MutableLiveData<MutableList<CategoriesRowModel>> =
      MutableLiveData(mutableListOf())

  val homeList: MutableLiveData<MutableList<HomeRowModel>> = MutableLiveData(mutableListOf())
}
