import '../../../core/app_export.dart';
import 'messagehistory_item_model.dart';

class MessageHistoryModel {
  List<MessagehistoryItemModel> messagehistoryItemList = [
    MessagehistoryItemModel(
        drMarcusHorizon: ImageConstant.imgClose40x40,
        drMarcusHorizon1: "Dr. Marcus Horizon",
        iDonTHaveAny: "I don,t have any fever, but headchace...",
        oneThousandTwentyFour: "10.24",
        widget: "1")
  ];
}
