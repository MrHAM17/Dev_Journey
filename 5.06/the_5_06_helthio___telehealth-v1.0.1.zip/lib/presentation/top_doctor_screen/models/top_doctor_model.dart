import '../../../core/app_export.dart';
import 'topdoctor_item_model.dart';

class TopDoctorModel {
  List<TopdoctorItemModel> topdoctorItemList = [
    TopdoctorItemModel(
        drMarcusHorizon: "Dr. Marcus Horizon D",
        chardiologist: "Chardiologist",
        fortySeven: "4.7",
        distance: "800m away"),
    TopdoctorItemModel(
        drMarcusHorizon: "Dr. Marcus Horizon D",
        chardiologist: "Chardiologist",
        fortySeven: "4.7",
        distance: "800m away"),
    TopdoctorItemModel(
        drMarcusHorizon: "Dr. Marcus Horizon D",
        chardiologist: "Chardiologist",
        fortySeven: "4.7",
        distance: "800m away"),
    TopdoctorItemModel(
        drMarcusHorizon: "Dr. Marcus Horizon D",
        chardiologist: "Chardiologist",
        fortySeven: "4.7",
        distance: "800m away"),
    TopdoctorItemModel(
        drMarcusHorizon: "Dr. Marcus Horizon D",
        chardiologist: "Chardiologist",
        fortySeven: "4.7",
        distance: "800m away")
  ];
}
