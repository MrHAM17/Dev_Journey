package com.shopsieecommerceapp.app.modules.mainlanding.`data`.model

class MainlandingRowModel()
