package com.shopsieecommerceapp.app.modules.productdetailpage.`data`.model

import kotlin.String

data class ImageSliderProductCarouselModel(
  /**
   * TODO Replace with dynamic value
   */
  var imageImage: String? = ""

)
