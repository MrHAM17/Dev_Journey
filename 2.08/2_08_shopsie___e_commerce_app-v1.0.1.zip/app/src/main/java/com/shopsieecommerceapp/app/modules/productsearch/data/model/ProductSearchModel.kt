package com.shopsieecommerceapp.app.modules.productsearch.`data`.model

class ProductSearchModel()
