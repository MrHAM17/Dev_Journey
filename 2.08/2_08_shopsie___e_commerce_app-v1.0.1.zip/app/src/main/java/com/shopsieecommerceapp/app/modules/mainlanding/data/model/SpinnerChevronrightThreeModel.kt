package com.shopsieecommerceapp.app.modules.mainlanding.`data`.model

import kotlin.String

data class SpinnerChevronrightThreeModel(
  val itemName: String
)
