package com.shopsieecommerceapp.app.modules.mainlanding.`data`.model

import kotlin.String

data class SpinnerChevronrightFourModel(
  val itemName: String
)
