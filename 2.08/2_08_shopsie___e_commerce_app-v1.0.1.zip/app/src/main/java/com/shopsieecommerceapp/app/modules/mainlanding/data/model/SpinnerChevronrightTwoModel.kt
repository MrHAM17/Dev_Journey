package com.shopsieecommerceapp.app.modules.mainlanding.`data`.model

import kotlin.String

data class SpinnerChevronrightTwoModel(
  val itemName: String
)
