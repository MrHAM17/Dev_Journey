package com.ecommerce.app.modules.productdetail.`data`.model

class Products1RowModel()
