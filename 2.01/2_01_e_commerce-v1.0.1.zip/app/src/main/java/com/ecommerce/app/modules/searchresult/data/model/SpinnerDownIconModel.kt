package com.ecommerce.app.modules.searchresult.`data`.model

import kotlin.String

data class SpinnerDownIconModel(
  val itemName: String
)
