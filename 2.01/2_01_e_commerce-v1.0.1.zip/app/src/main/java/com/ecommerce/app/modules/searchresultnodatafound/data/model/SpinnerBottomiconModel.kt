package com.ecommerce.app.modules.searchresultnodatafound.`data`.model

import kotlin.String

data class SpinnerBottomiconModel(
  val itemName: String
)
