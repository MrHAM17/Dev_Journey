package com.ecommerce.app.modules.splashscreen.`data`.model

class SplashScreenModel()
