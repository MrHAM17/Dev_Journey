package com.ecommerce.app.modules.productdetail.`data`.model

class BlueRowModel()
