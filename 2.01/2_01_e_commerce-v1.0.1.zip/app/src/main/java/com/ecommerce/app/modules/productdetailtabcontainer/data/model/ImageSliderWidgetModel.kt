package com.ecommerce.app.modules.productdetailtabcontainer.`data`.model

import kotlin.String

data class ImageSliderWidgetModel(
  /**
   * TODO Replace with dynamic value
   */
  var imageProductImage: String? = ""

)
