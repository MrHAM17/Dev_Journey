import '../../../core/app_export.dart';

/// This class is used in the [notificationsgeneral_item_widget] screen.
class NotificationsgeneralItemModel {
  NotificationsgeneralItemModel({
    this.bag,
    this.juniorUIDesigner,
    this.shopeeSg,
    this.time,
    this.loremIpsumDolor,
    this.id,
  }) {
    bag = bag ?? ImageConstant.imgBag;
    juniorUIDesigner = juniorUIDesigner ?? "Junior UI Designer ";
    shopeeSg = shopeeSg ?? "Shopee Sg";
    time = time ?? "32 Min ago";
    loremIpsumDolor = loremIpsumDolor ??
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit.";
    id = id ?? "";
  }

  String? bag;

  String? juniorUIDesigner;

  String? shopeeSg;

  String? time;

  String? loremIpsumDolor;

  String? id;
}
