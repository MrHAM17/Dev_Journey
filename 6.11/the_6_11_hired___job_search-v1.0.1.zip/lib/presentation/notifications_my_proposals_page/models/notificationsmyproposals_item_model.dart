import '../../../core/app_export.dart';

/// This class is used in the [notificationsmyproposals_item_widget] screen.
class NotificationsmyproposalsItemModel {
  NotificationsmyproposalsItemModel({
    this.iconButton,
    this.seniorUIUXDesigner,
    this.smallLabelRegular,
    this.id,
  }) {
    iconButton = iconButton ?? ImageConstant.imgGroupRed800;
    seniorUIUXDesigner = seniorUIUXDesigner ?? "Senior UI/UX Designer";
    smallLabelRegular = smallLabelRegular ?? "Shell";
    id = id ?? "";
  }

  String? iconButton;

  String? seniorUIUXDesigner;

  String? smallLabelRegular;

  String? id;
}
