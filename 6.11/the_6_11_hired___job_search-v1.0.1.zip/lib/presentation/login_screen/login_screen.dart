import 'notifier/login_notifier.dart';
import 'package:flutter/material.dart';
import 'package:the_6_11_hired___job_search/core/app_export.dart';
import 'package:the_6_11_hired___job_search/core/utils/validation_functions.dart';
import 'package:the_6_11_hired___job_search/widgets/app_bar/appbar_leading_image.dart';
import 'package:the_6_11_hired___job_search/widgets/app_bar/appbar_trailing_image.dart';
import 'package:the_6_11_hired___job_search/widgets/app_bar/custom_app_bar.dart';
import 'package:the_6_11_hired___job_search/widgets/custom_elevated_button.dart';
import 'package:the_6_11_hired___job_search/widgets/custom_outlined_button.dart';
import 'package:the_6_11_hired___job_search/widgets/custom_text_form_field.dart';
import 'package:the_6_11_hired___job_search/domain/googleauth/google_auth_helper.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  LoginScreenState createState() => LoginScreenState();
}

// ignore_for_file: must_be_immutable
class LoginScreenState extends ConsumerState<LoginScreen> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 24.h, vertical: 31.v),
                            child: Column(children: [
                              Text("msg_hi_welcome_back".tr,
                                  style: theme.textTheme.headlineSmall),
                              SizedBox(height: 11.v),
                              Text("msg_lorem_ipsum_dolor".tr,
                                  style: CustomTextStyles.titleSmallGray500),
                              SizedBox(height: 31.v),
                              CustomOutlinedButton(
                                  text: "msg_continue_with_google".tr,
                                  leftIcon: Container(
                                      margin: EdgeInsets.only(right: 12.h),
                                      child: CustomImageView(
                                          imagePath:
                                              ImageConstant.imgGooglesymbol1,
                                          height: 23.v,
                                          width: 24.h)),
                                  onPressed: () {
                                    onTapContinueWithGoogle(context);
                                  }),
                              SizedBox(height: 16.v),
                              CustomOutlinedButton(
                                  text: "msg_continue_with_apple".tr,
                                  leftIcon: Container(
                                      margin: EdgeInsets.only(right: 12.h),
                                      child: CustomImageView(
                                          imagePath: ImageConstant.imgIconApple,
                                          height: 24.adaptSize,
                                          width: 24.adaptSize))),
                              SizedBox(height: 26.v),
                              Padding(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 33.h),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                            padding: EdgeInsets.symmetric(
                                                vertical: 8.v),
                                            child: SizedBox(
                                                width: 62.h, child: Divider())),
                                        Padding(
                                            padding:
                                                EdgeInsets.only(left: 12.h),
                                            child: Text(
                                                "msg_or_continue_with".tr,
                                                style: CustomTextStyles
                                                    .titleSmallGray500SemiBold_1)),
                                        Padding(
                                            padding: EdgeInsets.symmetric(
                                                vertical: 8.v),
                                            child: SizedBox(
                                                width: 74.h,
                                                child: Divider(indent: 12.h)))
                                      ])),
                              SizedBox(height: 28.v),
                              _buildINPUTFIELD(context),
                              SizedBox(height: 40.v),
                              CustomElevatedButton(
                                  text: "msg_continue_with_email".tr),
                              SizedBox(height: 26.v),
                              Padding(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 41.h),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                            padding:
                                                EdgeInsets.only(bottom: 1.v),
                                            child: Text(
                                                "msg_don_t_have_an_account".tr,
                                                style: CustomTextStyles
                                                    .titleMediumGray500)),
                                        GestureDetector(
                                            onTap: () {
                                              onTapTxtLargeLabelMedium(context);
                                            },
                                            child: Padding(
                                                padding:
                                                    EdgeInsets.only(left: 2.h),
                                                child: Text("lbl_sign_up".tr,
                                                    style: theme.textTheme
                                                        .titleMedium)))
                                      ])),
                              SizedBox(height: 84.v),
                              Container(
                                  width: 245.h,
                                  margin:
                                      EdgeInsets.symmetric(horizontal: 40.h),
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "msg_by_signing_up_you2".tr,
                                            style: CustomTextStyles
                                                .titleSmallGray500SemiBold),
                                        TextSpan(
                                            text: "lbl_terms".tr,
                                            style: CustomTextStyles
                                                .titleSmallBlack900),
                                        TextSpan(
                                            text: "lbl_and".tr,
                                            style: CustomTextStyles
                                                .titleSmallGray500SemiBold),
                                        TextSpan(
                                            text: "msg_conditions_of_use".tr,
                                            style: CustomTextStyles
                                                .titleSmallBlack900)
                                      ]),
                                      textAlign: TextAlign.center)),
                              SizedBox(height: 9.v)
                            ])))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 48.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgComponent1,
            margin: EdgeInsets.only(left: 24.h, top: 13.v, bottom: 13.v),
            onTap: () {
              onTapImage(context);
            }),
        actions: [
          AppbarTrailingImage(
              imagePath: ImageConstant.imgComponent3,
              margin: EdgeInsets.symmetric(horizontal: 16.h, vertical: 13.v))
        ]);
  }

  /// Section Widget
  Widget _buildINPUTFIELD(BuildContext context) {
    return Container(
        decoration:
            BoxDecoration(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("lbl_email".tr, style: theme.textTheme.titleSmall),
          SizedBox(height: 9.v),
          Consumer(builder: (context, ref, _) {
            return CustomTextFormField(
                controller: ref.watch(loginNotifier).emailController,
                hintText: "msg_enter_your_email".tr,
                textInputAction: TextInputAction.done,
                textInputType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null ||
                      (!isValidEmail(value, isRequired: true))) {
                    return "err_msg_please_enter_valid_email".tr;
                  }
                  return null;
                });
          })
        ]));
  }

  /// Navigates back to the previous screen.
  onTapImage(BuildContext context) {
    NavigatorService.goBack();
  }

  onTapContinueWithGoogle(BuildContext context) async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
        //TODO Actions to be performed after signin
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('user data is empty')));
      }
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }

  /// Navigates to the signUpCreateAcountScreen when the action is triggered.
  onTapTxtLargeLabelMedium(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.signUpCreateAcountScreen,
    );
  }
}
