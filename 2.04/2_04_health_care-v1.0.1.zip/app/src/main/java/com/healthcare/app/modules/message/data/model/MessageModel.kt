package com.healthcare.app.modules.message.`data`.model

class MessageModel()
