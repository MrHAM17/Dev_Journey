package com.healthcare.app.modules.schedule.`data`.model

class ScheduleModel()
