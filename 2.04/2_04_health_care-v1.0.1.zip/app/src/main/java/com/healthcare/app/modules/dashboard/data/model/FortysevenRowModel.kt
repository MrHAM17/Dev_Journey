package com.healthcare.app.modules.dashboard.`data`.model

class FortysevenRowModel()
