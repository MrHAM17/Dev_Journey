package com.healthcare.app.modules.splashscreen.`data`.model

class SplashScreenModel()
