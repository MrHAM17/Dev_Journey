package com.healthcare.app

import com.healthcare.app.appcomponents.base.BaseActivity
import com.healthcare.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}