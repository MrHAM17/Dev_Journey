import '../../../core/app_export.dart';
import 'comments_item_model.dart';

class CommentsModel {
  List<CommentsItemModel> commentsItemList = [
    CommentsItemModel(
        name: "Billy Green",
        time: "20min ago",
        copy:
            "Awesome Edward, remember that five tips for low cost holidays I sent you?",
        image: ImageConstant.imgFavoriteSecondarycontainer),
    CommentsItemModel(
        name: "Billy Green",
        time: "20min ago",
        copy:
            "Awesome Edward, remember that five tips for low cost holidays I sent you?",
        image: ImageConstant.imgFavoriteGray500),
    CommentsItemModel(
        name: "Billy Green",
        time: "20min ago",
        copy:
            "Awesome Edward, remember that five tips for low cost holidays I sent you?",
        image: ImageConstant.imgFavoriteSecondarycontainer),
    CommentsItemModel(
        name: "Billy Green",
        time: "20min ago",
        copy:
            "Awesome Edward, remember that five tips for low cost holidays I sent you?",
        image: ImageConstant.imgFavoriteSecondarycontainer)
  ];
}
