import 'tags_item_model.dart';
import '../../../core/app_export.dart';

class SingleVideoModel {
  List<TagsItemModel> tagsItemList =
      List.generate(5, (index) => TagsItemModel());
}
