import '../../../core/app_export.dart';
import 'search_item_model.dart';

class SearchModel {
  List<SearchItemModel> searchItemList = [
    SearchItemModel(
        edwardFord: ImageConstant.imgThumbnail,
        username: "Edward Ford",
        edwardFord1: ImageConstant.imgThumbnail229x154,
        edwardFord2: ImageConstant.imgImage6,
        username1: "Edward Ford",
        edwardFord3: ImageConstant.imgThumbnail1,
        edwardFord4: ImageConstant.imgImage7,
        username2: "Edward Ford",
        edwardFord5: ImageConstant.imgThumbnail2,
        edwardFord6: ImageConstant.imgImage8,
        username3: "Edward Ford")
  ];
}
