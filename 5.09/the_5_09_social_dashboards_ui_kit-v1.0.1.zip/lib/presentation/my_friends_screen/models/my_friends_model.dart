import '../../../core/app_export.dart';
import 'myfriends_item_model.dart';

class MyFriendsModel {
  List<MyfriendsItemModel> myfriendsItemList = [
    MyfriendsItemModel(username: "Logan Nasser", fullname: "@louisaingram"),
    MyfriendsItemModel(username: "Logan Nasser", fullname: "@louisaingram"),
    MyfriendsItemModel(username: "Logan Nasser", fullname: "@louisaingram"),
    MyfriendsItemModel(username: "Logan Nasser", fullname: "@louisaingram"),
    MyfriendsItemModel(username: "Logan Nasser", fullname: "@louisaingram")
  ];
}
