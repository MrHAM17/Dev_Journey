import '../../../core/app_export.dart';
import 'messages_item_model.dart';

class MessagesModel {
  List<MessagesItemModel> messagesItemList = [
    MessagesItemModel(
        billyGreen: ImageConstant.imgAvatar,
        username: "Billy Green",
        message: "Thank you for sharing",
        time: "3:03pm",
        notifications: "1"),
    MessagesItemModel(
        billyGreen: ImageConstant.imgImage8,
        username: "Billy Green",
        message: "Thank you for sharing",
        time: "3:03pm",
        notifications: "1"),
    MessagesItemModel(
        billyGreen: ImageConstant.imgAvatar48x48,
        username: "Billy Green",
        message: "Thank you for sharing",
        time: "3:03pm",
        notifications: "1"),
    MessagesItemModel(
        billyGreen: ImageConstant.imgAvatar1,
        username: "Billy Green",
        message: "Thank you for sharing"),
    MessagesItemModel(
        billyGreen: ImageConstant.imgAvatar2,
        username: "Billy Green",
        message: "Thank you for sharing"),
    MessagesItemModel(
        billyGreen: ImageConstant.imgAvatar3,
        username: "Billy Green",
        message: "Thank you for sharing")
  ];
}
