import '../../../core/app_export.dart';
import 'gallery_item_model.dart';

class GalleryModel {
  List<GalleryItemModel> galleryItemList = [
    GalleryItemModel(
        image: ImageConstant.imgImage99x99,
        image1: ImageConstant.imgImage12,
        image2: ImageConstant.imgImage13,
        image3: ImageConstant.imgImage14,
        image4: ImageConstant.imgImage15,
        image5: ImageConstant.imgImage16,
        image6: ImageConstant.imgImage17,
        image7: ImageConstant.imgImage18,
        image8: ImageConstant.imgImage19)
  ];
}
