import '../../../core/app_export.dart';

class HomeContainerModel {}
