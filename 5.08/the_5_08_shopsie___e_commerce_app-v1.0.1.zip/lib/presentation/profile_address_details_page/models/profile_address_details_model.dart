import '../../../core/app_export.dart';
import 'profileaddressdetails_item_model.dart';

class ProfileAddressDetailsModel {
  List<ProfileaddressdetailsItemModel> profileaddressdetailsItemList = [
    ProfileaddressdetailsItemModel(
        homeAddress: "Home address",
        edit: "Edit",
        addressCounter: "Address 1",
        amoySt: " Amoy st, 592",
        addressCounter1: "Address 2",
        amoySt1: " Amoy st, 592",
        city: "City",
        losAngeles: "Los Angeles",
        postalCode: "Postal code",
        zero: "0000000"),
    ProfileaddressdetailsItemModel(
        homeAddress: "Home address",
        edit: "Edit",
        addressCounter: "Address 1",
        amoySt: " Amoy st, 592",
        addressCounter1: "Address 2",
        amoySt1: " Amoy st, 592",
        city: "City",
        losAngeles: "Los Angeles",
        postalCode: "Postal code",
        zero: "0000000")
  ];
}
