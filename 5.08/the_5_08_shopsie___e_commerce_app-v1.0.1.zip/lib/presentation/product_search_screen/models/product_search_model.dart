import '../../../core/app_export.dart';
import 'productsearch_item_model.dart';

class ProductSearchModel {
  List<ProductsearchItemModel> productsearchItemList = [
    ProductsearchItemModel(
        longSleeveTshirt: ImageConstant.imgImage171x171,
        longSleeveTShirt: "Long Sleeve T-shirt"),
    ProductsearchItemModel(
        longSleeveTshirt: ImageConstant.imgImage7, longSleeveTShirt: "Sliders"),
    ProductsearchItemModel(
        longSleeveTshirt: ImageConstant.imgImage8,
        longSleeveTShirt: "Slippers"),
    ProductsearchItemModel(
        longSleeveTshirt: ImageConstant.imgImage9,
        longSleeveTShirt: "Long Sleeve Top"),
    ProductsearchItemModel(
        longSleeveTshirt: ImageConstant.imgImage10,
        longSleeveTShirt: "Slip Dress"),
    ProductsearchItemModel(
        longSleeveTshirt: ImageConstant.imgImage11,
        longSleeveTShirt: "Nike Slides")
  ];
}
