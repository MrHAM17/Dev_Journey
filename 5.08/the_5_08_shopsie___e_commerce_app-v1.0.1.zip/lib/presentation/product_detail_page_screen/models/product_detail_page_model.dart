import 'productcarousel_item_model.dart';
import '../../../core/app_export.dart';

class ProductDetailPageModel {
  List<ProductcarouselItemModel> productcarouselItemList =
      List.generate(1, (index) => ProductcarouselItemModel());
}
