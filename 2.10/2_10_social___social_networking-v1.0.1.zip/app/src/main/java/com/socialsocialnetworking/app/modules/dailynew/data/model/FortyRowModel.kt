package com.socialsocialnetworking.app.modules.dailynew.`data`.model

class FortyRowModel()
