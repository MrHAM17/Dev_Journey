package com.socialsocialnetworking.app.modules.accountdetails.`data`.model

class FortysixRowModel()
