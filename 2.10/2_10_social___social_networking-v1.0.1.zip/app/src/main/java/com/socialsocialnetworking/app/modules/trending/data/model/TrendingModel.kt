package com.socialsocialnetworking.app.modules.trending.`data`.model

class TrendingModel()
