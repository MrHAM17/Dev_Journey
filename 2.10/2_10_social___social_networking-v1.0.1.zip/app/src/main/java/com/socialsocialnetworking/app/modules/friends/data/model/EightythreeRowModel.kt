package com.socialsocialnetworking.app.modules.friends.`data`.model

class EightythreeRowModel()
