import '../../../core/app_export.dart';
import 'downloaded_item_model.dart';

class DownloadedModel {
  List<DownloadedItemModel> downloadedItemList = [
    DownloadedItemModel(
        image: ImageConstant.imgRectangle12103,
        actionAdventure: "Action, Adventure",
        twentyThousandFiveHundredThirt: "2:05:32",
        filesize: "1.2GB"),
    DownloadedItemModel(
        image: ImageConstant.imgRectangle12103112x112,
        actionAdventure: "Action, Adventure",
        twentyThousandFiveHundredThirt: "2:05:32",
        filesize: "1.2GB")
  ];
}
