import '../../../core/app_export.dart';
import 'selectsaved_item_model.dart';

class SelectSavedModel {
  List<SelectsavedItemModel> selectsavedItemList = [
    SelectsavedItemModel(
        image: ImageConstant.imgRectangle121031,
        theIceAgeAdventures: "The Ice Age: Adventures of buck Wild",
        actionAdventure: "Action, Adventure"),
    SelectsavedItemModel(
        image: ImageConstant.imgRectangle12103,
        theIceAgeAdventures: "Captain America: The Winter Soldier",
        actionAdventure: "Action, Adventure"),
    SelectsavedItemModel(
        image: ImageConstant.imgRectangle12103112x112,
        theIceAgeAdventures: "Captain Marvel",
        actionAdventure: "Action, Adventure"),
    SelectsavedItemModel(
        image: ImageConstant.imgRectangle121032,
        theIceAgeAdventures: "Encanto 2021",
        actionAdventure: "Action, Adventure")
  ];
}
