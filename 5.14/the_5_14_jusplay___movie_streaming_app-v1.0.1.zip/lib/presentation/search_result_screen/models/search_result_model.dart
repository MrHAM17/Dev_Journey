import '../../../core/app_export.dart';
import 'searchresult_item_model.dart';

class SearchResultModel {
  List<SearchresultItemModel> searchresultItemList = [
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle12078),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle12078140x102),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120781),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120782),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120783),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120784),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120785),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120786),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120787),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120788),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle120789),
    SearchresultItemModel(rectangle: ImageConstant.imgRectangle1207810)
  ];
}
