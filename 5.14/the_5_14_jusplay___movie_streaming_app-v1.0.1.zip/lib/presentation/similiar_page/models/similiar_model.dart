import '../../../core/app_export.dart';
import 'similiar_item_model.dart';

class SimiliarModel {
  List<SimiliarItemModel> similiarItemList = [
    SimiliarItemModel(
        image: ImageConstant.imgRectangle12078,
        image1: ImageConstant.imgRectangle12078140x102,
        image2: ImageConstant.imgRectangle120781)
  ];
}
