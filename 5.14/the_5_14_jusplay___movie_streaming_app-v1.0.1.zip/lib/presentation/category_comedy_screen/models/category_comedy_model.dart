import '../../../core/app_export.dart';
import 'categorycomedy_item_model.dart';

class CategoryComedyModel {
  List<CategorycomedyItemModel> categorycomedyItemList = [
    CategorycomedyItemModel(rectangle: ImageConstant.imgRectangle12078),
    CategorycomedyItemModel(rectangle: ImageConstant.imgRectangle12078140x102),
    CategorycomedyItemModel(rectangle: ImageConstant.imgRectangle120781)
  ];
}
