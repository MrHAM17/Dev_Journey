import '../../../core/app_export.dart';
import 'chooseplan_item_model.dart';

class ChoosePlanModel {
  List<ChooseplanItemModel> chooseplanItemList = [
    ChooseplanItemModel(voucher: "Voucher")
  ];
}
