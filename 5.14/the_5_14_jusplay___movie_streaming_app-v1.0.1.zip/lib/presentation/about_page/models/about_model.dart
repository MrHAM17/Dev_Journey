import '../../../core/app_export.dart';
import 'about_item_model.dart';

class AboutModel {
  List<AboutItemModel> aboutItemList = [
    AboutItemModel(
        menaMassoud: ImageConstant.imgRectangle12050,
        menaMassoud1: "Mena Massoud"),
    AboutItemModel(
        menaMassoud: ImageConstant.imgRectangle12050127x104,
        menaMassoud1: "Naomi Scott"),
    AboutItemModel(
        menaMassoud: ImageConstant.imgRectangle120501,
        menaMassoud1: "Will Smith"),
    AboutItemModel(
        menaMassoud: ImageConstant.imgRectangle120502,
        menaMassoud1: "Mena Massoud")
  ];
}
