import 'widget_item_model.dart';
import '../../../core/app_export.dart';

class HomeTabContainerModel {
  List<WidgetItemModel> widgetItemList =
      List.generate(1, (index) => WidgetItemModel());
}
