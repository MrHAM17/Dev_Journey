import '../../../core/app_export.dart';
import 'language_item_model.dart';

class LanguageModel {
  List<LanguageItemModel> languageItemList = [
    LanguageItemModel(
        england: ImageConstant.imgBg,
        england1: "England",
        england2: ImageConstant.imgCheckmarkWhiteA700)
  ];
}
