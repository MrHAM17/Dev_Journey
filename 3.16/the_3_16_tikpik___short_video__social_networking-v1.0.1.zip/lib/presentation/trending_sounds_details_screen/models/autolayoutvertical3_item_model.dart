import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical3_item_widget] screen.
class Autolayoutvertical3ItemModel {Autolayoutvertical3ItemModel({this.k, this.k1, this.k2, this.k3, this.k4, this.k5, this.k6, this.k7, this.k8, this.id, }) { k = k  ?? ImageConstant.imgImage25;k1 = k1  ?? ImageConstant.imgOverflowmenuPrimary;k2 = k2  ?? "837.5K";k3 = k3  ?? ImageConstant.imgImage26;k4 = k4  ?? "837.5K";k5 = k5  ?? ImageConstant.imgImage27;k6 = k6  ?? "837.5K";k7 = k7  ?? ImageConstant.imgImage28;k8 = k8  ?? "837.5K";id = id  ?? ""; }

String? k;

String? k1;

String? k2;

String? k3;

String? k4;

String? k5;

String? k6;

String? k7;

String? k8;

String? id;

 }
