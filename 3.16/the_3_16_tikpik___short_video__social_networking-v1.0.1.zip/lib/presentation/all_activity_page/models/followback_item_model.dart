import '../../../core/app_export.dart';/// This class is used in the [followback_item_widget] screen.
class FollowbackItemModel {FollowbackItemModel({this.charoletteHanlin, this.charoletteHanlin1, this.information, this.charoletteHanlin2, this.id, }) { charoletteHanlin = charoletteHanlin  ?? ImageConstant.imgEllipse14;charoletteHanlin1 = charoletteHanlin1  ?? "Charolette Hanlin";information = information  ?? "Leave a comment on your video";charoletteHanlin2 = charoletteHanlin2  ?? ImageConstant.imgImage60x60;id = id  ?? ""; }

String? charoletteHanlin;

String? charoletteHanlin1;

String? information;

String? charoletteHanlin2;

String? id;

 }
