// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [trending_sounds_tab_container_page],
/// and is typically used to hold data that is passed between different parts of the application.
class TrendingSoundsTabContainerModel extends Equatable {TrendingSoundsTabContainerModel() {  }

TrendingSoundsTabContainerModel copyWith() { return TrendingSoundsTabContainerModel(
); } 
@override List<Object?> get props => [];
 }
