import '../../../core/app_export.dart';/// This class is used in the [postsaddeffects_item_widget] screen.
class PostsaddeffectsItemModel {PostsaddeffectsItemModel({this.image, this.image1, this.image2, this.image3, this.image4, this.image5, this.id, }) { image = image  ?? ImageConstant.imgImage45;image1 = image1  ?? ImageConstant.imgImage46;image2 = image2  ?? ImageConstant.imgImage47;image3 = image3  ?? ImageConstant.imgImage48;image4 = image4  ?? ImageConstant.imgImage49;image5 = image5  ?? ImageConstant.imgImage50;id = id  ?? ""; }

String? image;

String? image1;

String? image2;

String? image3;

String? image4;

String? image5;

String? id;

 }
