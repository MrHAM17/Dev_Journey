import '../../../core/app_export.dart';/// This class is used in the [seelive_item_widget] screen.
class SeeliveItemModel {SeeliveItemModel({this.darylNehls, this.woohoooo, this.id, }) { darylNehls = darylNehls  ?? "Daryl Nehls";woohoooo = woohoooo  ?? "woohoooo";id = id  ?? ""; }

String? darylNehls;

String? woohoooo;

String? id;

 }
