import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical1_item_widget] screen.
class Autolayoutvertical1ItemModel {Autolayoutvertical1ItemModel({this.theresaWebb, this.id, }) { theresaWebb = theresaWebb  ?? "Theresa Webb";id = id  ?? ""; }

String? theresaWebb;

String? id;

 }
