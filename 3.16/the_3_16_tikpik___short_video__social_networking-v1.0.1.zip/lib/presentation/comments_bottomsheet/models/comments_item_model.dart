import '../../../core/app_export.dart';/// This class is used in the [comments_item_widget] screen.
class CommentsItemModel {CommentsItemModel({this.adipiscingElit, this.kristinWatson, this.image, this.text, this.duration, this.reply, this.id, }) { adipiscingElit = adipiscingElit  ?? "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.";kristinWatson = kristinWatson  ?? "Kristin Watson";image = image  ?? ImageConstant.imgIconlyBoldHeart;text = text  ?? "938";duration = duration  ?? "3 days ago";reply = reply  ?? "Reply";id = id  ?? ""; }

String? adipiscingElit;

String? kristinWatson;

String? image;

String? text;

String? duration;

String? reply;

String? id;

 }
