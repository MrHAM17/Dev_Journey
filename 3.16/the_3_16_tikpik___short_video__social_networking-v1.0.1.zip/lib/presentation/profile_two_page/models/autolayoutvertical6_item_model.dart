import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical6_item_widget] screen.
class Autolayoutvertical6ItemModel {Autolayoutvertical6ItemModel({this.k, this.k1, this.k2, this.k3, this.overflowMenu, this.k4, this.id, }) { k = k  ?? ImageConstant.imgImage72;k1 = k1  ?? ImageConstant.imgOverflowmenuPrimary;k2 = k2  ?? "367.5K";k3 = k3  ?? ImageConstant.imgImage73;overflowMenu = overflowMenu  ?? ImageConstant.imgOverflowMenuPrimary16x16;k4 = k4  ?? "837.9K";id = id  ?? ""; }

String? k;

String? k1;

String? k2;

String? k3;

String? overflowMenu;

String? k4;

String? id;

 }
