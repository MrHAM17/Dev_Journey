import '../../../core/app_export.dart';/// This class is used in the [postsaddsounds_item_widget] screen.
class PostsaddsoundsItemModel {PostsaddsoundsItemModel({this.asItWas, this.overflowMenu, this.asItWas1, this.harryStyles, this.time, this.distance, this.m, this.id, }) { asItWas = asItWas  ?? ImageConstant.imgImage15;overflowMenu = overflowMenu  ?? ImageConstant.imgOverflowMenuOnerrorcontainer;asItWas1 = asItWas1  ?? "As It Was";harryStyles = harryStyles  ?? "Harry Styles";time = time  ?? "01:00";distance = distance  ?? "65.1M";m = m  ?? ImageConstant.imgBookmarkPrimary24x24;id = id  ?? ""; }

String? asItWas;

String? overflowMenu;

String? asItWas1;

String? harryStyles;

String? time;

String? distance;

String? m;

String? id;

 }
