// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [posts_add_effects_tab_container_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class PostsAddEffectsTabContainerModel extends Equatable {PostsAddEffectsTabContainerModel() {  }

PostsAddEffectsTabContainerModel copyWith() { return PostsAddEffectsTabContainerModel(
); } 
@override List<Object?> get props => [];
 }
