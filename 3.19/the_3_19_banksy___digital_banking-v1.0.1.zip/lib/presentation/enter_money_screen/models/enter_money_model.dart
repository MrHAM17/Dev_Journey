// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [enter_money_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class EnterMoneyModel extends Equatable {
  EnterMoneyModel() {}

  EnterMoneyModel copyWith() {
    return EnterMoneyModel();
  }

  @override
  List<Object?> get props => [];
}
