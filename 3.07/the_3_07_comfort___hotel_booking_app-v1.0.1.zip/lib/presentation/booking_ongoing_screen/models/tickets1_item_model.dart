import '../../../core/app_export.dart';/// This class is used in the [tickets1_item_widget] screen.
class Tickets1ItemModel {Tickets1ItemModel({this.royalePresident, this.image, this.parisFrance, this.id, }) { royalePresident = royalePresident  ?? "Royale President Hotel";image = image  ?? ImageConstant.imgRectangle;parisFrance = parisFrance  ?? "Paris, France";id = id  ?? ""; }

String? royalePresident;

String? image;

String? parisFrance;

String? id;

 }
