import '../../../core/app_export.dart';/// This class is used in the [framenineteen_item_widget] screen.
class FramenineteenItemModel {FramenineteenItemModel({this.jennyWilson, this.jennyWilson1, this.dec, this.veryniceandcomfortab, this.id, }) { jennyWilson = jennyWilson  ?? ImageConstant.imgEllipse1;jennyWilson1 = jennyWilson1  ?? "Jenny Wilson";dec = dec  ?? "Dec 10, 2024";veryniceandcomfortab = veryniceandcomfortab  ?? "Very nice and comfortable hotel, thank you for accompanying my vacation!";id = id  ?? ""; }

String? jennyWilson;

String? jennyWilson1;

String? dec;

String? veryniceandcomfortab;

String? id;

 }
