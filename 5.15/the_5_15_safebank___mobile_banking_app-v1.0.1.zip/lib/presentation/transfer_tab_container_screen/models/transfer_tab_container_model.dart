import '../../../core/app_export.dart';
import 'transfertabcontainer_item_model.dart';

class TransferTabContainerModel {
  List<TransfertabcontainerItemModel> transfertabcontainerItemList = [
    TransfertabcontainerItemModel(ellipse: ImageConstant.imgEllipse309),
    TransfertabcontainerItemModel(ellipse: ImageConstant.imgEllipse310),
    TransfertabcontainerItemModel(ellipse: ImageConstant.imgEllipse313),
    TransfertabcontainerItemModel(ellipse: ImageConstant.imgEllipse312),
    TransfertabcontainerItemModel(ellipse: ImageConstant.imgEllipse311)
  ];
}
