import 'duration_item_model.dart';
import '../../../core/app_export.dart';

class HistoryModel {
  List<DurationItemModel> durationItemList = [
    DurationItemModel(groupBy: "Today, 25 June"),
    DurationItemModel(groupBy: "Today, 25 June"),
    DurationItemModel(groupBy: "Today, 25 June"),
    DurationItemModel(groupBy: "Today, 25 June"),
    DurationItemModel(groupBy: "Yesterday"),
    DurationItemModel(groupBy: "Yesterday"),
    DurationItemModel(groupBy: "Yesterday"),
    DurationItemModel(groupBy: "20 June, 2022"),
    DurationItemModel(groupBy: "20 June, 2022")
  ];
}
