import '../../../core/app_export.dart';
import 'card_item_model.dart';

class PaymentModel {
  List<CardItemModel> cardItemList = [
    CardItemModel(television: ImageConstant.imgTelevision)
  ];
}
