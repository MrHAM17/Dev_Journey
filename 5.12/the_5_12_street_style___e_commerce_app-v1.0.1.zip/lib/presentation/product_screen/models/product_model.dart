import '../../../core/app_export.dart';
import 'twelve_item_model.dart';

class ProductModel {
  List<TwelveItemModel> twelveItemList = [
    TwelveItemModel(image: ImageConstant.imgRectangle14),
    TwelveItemModel(image: ImageConstant.imgRectangle14)
  ];
}
