import '../../../core/app_export.dart';
import 'myorder_item_model.dart';

class MyOrderModel {
  List<MyorderItemModel> myorderItemList = [
    MyorderItemModel(
        x: ImageConstant.imgRectangle9237x175,
        vERTLUNEBoyfriend: "VERTLUNE\nBoyfriend Tee",
        yellowSizeCounter: "Yellow\nSize 8"),
    MyorderItemModel(
        x: ImageConstant.imgRectangle10,
        vERTLUNEBoyfriend: "VERTLUNE\nBoyfriend Tee",
        yellowSizeCounter: "Yellow\nSize 8")
  ];
}
