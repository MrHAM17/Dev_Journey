import '../../../core/app_export.dart';
import 'shop_item_model.dart';

class ShopModel {
  List<ShopItemModel> shopItemList = [
    ShopItemModel(
        surgeShort: ImageConstant.imgRectangle9,
        surgeShort1: "Surge Short",
        price: "68 USD"),
    ShopItemModel(
        surgeShort: ImageConstant.imgRectangle9237x175,
        surgeShort1: "Sweat Jogger French",
        price: "68 USD")
  ];
}
