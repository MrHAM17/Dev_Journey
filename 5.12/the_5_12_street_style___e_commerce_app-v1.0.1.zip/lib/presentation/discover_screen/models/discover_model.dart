import '../../../core/app_export.dart';
import 'discover_item_model.dart';

class DiscoverModel {
  List<DiscoverItemModel> discoverItemList = [
    DiscoverItemModel(shirtSleeve: ImageConstant.imgImage2),
    DiscoverItemModel(shirtSleeve: ImageConstant.imgImage3)
  ];
}
