import 'package:the_3_15_safebank___mobile_banking_app/core/app_export.dart';

class ApiClient {}
