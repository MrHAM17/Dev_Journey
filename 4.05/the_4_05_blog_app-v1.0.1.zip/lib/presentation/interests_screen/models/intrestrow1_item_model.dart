import '../../../core/app_export.dart';

/// This class is used in the [intrestrow1_item_widget] screen.
class Intrestrow1ItemModel {
  Rx<String>? chips = Rx("Art");

  Rx<bool>? isSelected = Rx(false);
}
