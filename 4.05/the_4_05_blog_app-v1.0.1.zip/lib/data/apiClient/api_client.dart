import 'package:the_4_05_blog_app/core/app_export.dart';

class ApiClient extends GetConnect {}
