import 'user_item_model.dart';import '../../../core/app_export.dart';class ChooseCreditOrDebitCardModel {List<UserItemModel> userItemList = List.generate(1,(index) => UserItemModel());

 }
