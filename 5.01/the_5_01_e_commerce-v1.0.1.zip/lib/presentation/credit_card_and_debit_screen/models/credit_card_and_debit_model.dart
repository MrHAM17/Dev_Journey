import '../../../core/app_export.dart';import 'cards_item_model.dart';class CreditCardAndDebitModel {List<CardsItemModel> cardsItemList = [CardsItemModel(debitCardNumber: "6326    9124    8124    9875",cardholder: "CARD HOLDER",dominicOvo: "Dominic Ovo",cardsave: "CARD SAVE",debitCardExpiry: "06/24"),CardsItemModel(debitCardNumber: "6326    9124    8124    9875",cardholder: "CARD HOLDER",dominicOvo: "Dominic Ovo",cardsave: "CARD SAVE",debitCardExpiry: "06/24")];

 }
