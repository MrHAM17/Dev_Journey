import '../../../core/app_export.dart';import 'cart_item_model.dart';class CartModel {List<CartItemModel> cartItemList = [CartItemModel(nikeAirZoomPegasus: "Nike Air Zoom Pegasus 36 Miami",price: "299,43",one: "1"),CartItemModel(nikeAirZoomPegasus: "Nike Air Zoom Pegasus 36 Miami",price: "299,43",one: "1")];

 }
