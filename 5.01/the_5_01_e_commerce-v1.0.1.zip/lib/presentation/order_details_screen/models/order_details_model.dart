import '../../../core/app_export.dart';import 'product_item_model.dart';class OrderDetailsModel {List<ProductItemModel> productItemList = [ProductItemModel(image:ImageConstant.imgImageProduct,nikeAirZoomPegasus: "Nike Air Zoom Pegasus 36 Miami",image1:ImageConstant.imgLoveIconPink300,price: "299,43",one: "1"),ProductItemModel(image:ImageConstant.imgProductImage1,nikeAirZoomPegasus: "Nike Air Zoom Pegasus 36 Miami",image1:ImageConstant.imgLoveIcon,price: "299,43",one: "1")];

 }
