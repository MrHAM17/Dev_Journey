import '../../../core/app_export.dart';import 'offerscreen_item_model.dart';class OfferScreenModel {List<OfferscreenItemModel> offerscreenItemList = [OfferscreenItemModel(image:ImageConstant.imgPromotionImage,offer: "Super Flash Sale\n50% Off",hours: "08",text: ":",minutes: "34",text1: ":",secounds: "52"),OfferscreenItemModel(image:ImageConstant.imgRecomendedProduct,offer: "90% Off Super Mega Sale")];

 }
