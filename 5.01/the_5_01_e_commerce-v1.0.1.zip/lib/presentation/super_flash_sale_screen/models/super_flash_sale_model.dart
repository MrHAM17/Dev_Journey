import '../../../core/app_export.dart';import 'superflashsale_item_model.dart';class SuperFlashSaleModel {List<SuperflashsaleItemModel> superflashsaleItemList = [SuperflashsaleItemModel(image:ImageConstant.imgPromotionImage,offer: "Super Flash Sale\n50% Off",clock: "08",text: ":",minutes: "34",text1: ":",secounds: "52"),SuperflashsaleItemModel(image:ImageConstant.imgProductImage3)];

 }
