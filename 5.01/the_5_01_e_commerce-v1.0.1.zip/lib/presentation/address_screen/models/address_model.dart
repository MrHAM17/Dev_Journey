import '../../../core/app_export.dart';import 'addresses_item_model.dart';class AddressModel {List<AddressesItemModel> addressesItemList = [AddressesItemModel(priscekila: "Priscekila",address: "3711 Spring Hill Rd undefined Tallahassee, Nevada 52874 United States",mobileNo: "+99 1234567890",edit: "Edit",delete: "Delete"),AddressesItemModel(priscekila: "Ahmad Khaidir",address: "3711 Spring Hill Rd undefined Tallahassee, Nevada 52874 United States",mobileNo: "+99 1234567890",edit: "Edit",delete: "Delete")];

 }
