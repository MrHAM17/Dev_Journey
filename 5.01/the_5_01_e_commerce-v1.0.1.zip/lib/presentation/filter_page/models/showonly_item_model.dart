import '../../../core/app_export.dart';/// This class is used in the [showonly_item_widget] screen.
class ShowonlyItemModel {ShowonlyItemModel({this.freeReturns, this.isSelected, }) { freeReturns = freeReturns  ?? "Free Returns";isSelected = isSelected  ?? false; }

String? freeReturns;

bool? isSelected;

 }
