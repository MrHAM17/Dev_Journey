import 'buyingformate_item_model.dart';import 'itemlocation_item_model.dart';import 'showonly_item_model.dart';import '../../../core/app_export.dart';class FilterModel {List<BuyingformateItemModel> buyingformateItemList = List.generate(5,(index) =>BuyingformateItemModel());

List<ItemlocationItemModel> itemlocationItemList = List.generate(4,(index) =>ItemlocationItemModel());

List<ShowonlyItemModel> showonlyItemList = List.generate(11,(index) =>ShowonlyItemModel());

 }
