import '../../../core/app_export.dart';/// This class is used in the [itemlocation_item_widget] screen.
class ItemlocationItemModel {ItemlocationItemModel({this.uSOnly, this.isSelected, }) { uSOnly = uSOnly  ?? "US Only";isSelected = isSelected  ?? false; }

String? uSOnly;

bool? isSelected;

 }
