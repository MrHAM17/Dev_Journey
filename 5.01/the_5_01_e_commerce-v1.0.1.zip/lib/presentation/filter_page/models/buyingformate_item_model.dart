import '../../../core/app_export.dart';/// This class is used in the [buyingformate_item_widget] screen.
class BuyingformateItemModel {BuyingformateItemModel({this.allListings, this.isSelected, }) { allListings = allListings  ?? "All Listings";isSelected = isSelected  ?? false; }

String? allListings;

bool? isSelected;

 }
