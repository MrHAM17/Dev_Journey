import '../../../core/app_export.dart';

/// This class is used in the [fulltime1_item_widget] screen.
class Fulltime1ItemModel {
  Rx<String>? fulltime = Rx("Fulltime");

  Rx<bool>? isSelected = Rx(false);
}
