import '../../../core/app_export.dart';

/// This class is used in the [fulltime3_item_widget] screen.
class Fulltime3ItemModel {
  Rx<String>? fulltime = Rx("Fulltime");

  Rx<bool>? isSelected = Rx(false);
}
