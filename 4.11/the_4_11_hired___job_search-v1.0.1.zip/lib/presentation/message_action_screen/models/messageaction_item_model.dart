import '../../../core/app_export.dart';

/// This class is used in the [messageaction_item_widget] screen.
class MessageactionItemModel {
  MessageactionItemModel({
    this.estherHoward,
    this.estherHoward1,
    this.loremIpsumDolor,
    this.time,
    this.widget,
    this.id,
  }) {
    estherHoward = estherHoward ?? Rx(ImageConstant.imgImage56x56);
    estherHoward1 = estherHoward1 ?? Rx("Esther Howard");
    loremIpsumDolor = loremIpsumDolor ?? Rx("Lorem ipsum dolor sit amet...");
    time = time ?? Rx("10:20");
    widget = widget ?? Rx("2");
    id = id ?? Rx("");
  }

  Rx<String>? estherHoward;

  Rx<String>? estherHoward1;

  Rx<String>? loremIpsumDolor;

  Rx<String>? time;

  Rx<String>? widget;

  Rx<String>? id;
}
