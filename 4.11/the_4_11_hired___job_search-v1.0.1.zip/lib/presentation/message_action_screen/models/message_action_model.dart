import '../../../core/app_export.dart';
import 'messageaction_item_model.dart';

/// This class defines the variables used in the [message_action_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class MessageActionModel {
  Rx<List<MessageactionItemModel>> messageactionItemList = Rx([
    MessageactionItemModel(
        estherHoward: ImageConstant.imgImage56x56.obs,
        estherHoward1: "Esther Howard".obs,
        loremIpsumDolor: "Lorem ipsum dolor sit amet...".obs,
        time: "10:20".obs,
        widget: "2".obs),
    MessageactionItemModel(
        estherHoward1: "Wade Warren".obs,
        loremIpsumDolor: "Lorem ipsum dolor sit amet...".obs,
        time: "10:20".obs,
        widget: "2".obs),
    MessageactionItemModel(
        estherHoward1: "Robert Fox".obs,
        loremIpsumDolor: "Lorem ipsum dolor sit amet...".obs)
  ]);
}
