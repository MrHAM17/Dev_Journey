import '../../../core/app_export.dart';

/// This class is used in the [fortyseven_item_widget] screen.
class FortysevenItemModel {
  Rx<String>? skills = Rx("Design & Creative");

  Rx<bool>? isSelected = Rx(false);
}
