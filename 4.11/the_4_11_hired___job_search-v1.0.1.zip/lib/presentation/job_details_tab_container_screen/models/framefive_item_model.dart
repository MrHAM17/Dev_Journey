import '../../../core/app_export.dart';

/// This class is used in the [framefive_item_widget] screen.
class FramefiveItemModel {
  Rx<String>? fulltime = Rx("Fulltime");

  Rx<bool>? isSelected = Rx(false);
}
