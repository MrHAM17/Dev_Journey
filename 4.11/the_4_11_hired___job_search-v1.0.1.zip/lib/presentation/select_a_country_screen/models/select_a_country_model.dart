import '../../../core/app_export.dart';

/// This class defines the variables used in the [select_a_country_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SelectACountryModel {
  Rx<List<String>> radioList = Rx([
    "lbl_afghanistan",
    "lbl_albania",
    "lbl_algeria",
    "lbl_andorra",
    "lbl_angola",
    "msg_antigua_and_barbuda",
    "lbl_argentina",
    "lbl_argentina",
    "lbl_armenia",
    "lbl_australia",
    "lbl_austria",
    "lbl_azerbaijan",
    "lbl_azerbaijan"
  ]);
}
