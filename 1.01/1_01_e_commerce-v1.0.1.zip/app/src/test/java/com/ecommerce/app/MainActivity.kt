package com.ecommerce.app

import com.ecommerce.app.appcomponents.base.BaseActivity
import com.ecommerce.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}