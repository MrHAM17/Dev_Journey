import '../../../core/app_export.dart';import 'homealarm_item_model.dart';class HomeAlarmModel {List<HomealarmItemModel> homealarmItemList = [HomealarmItemModel(mightyCincoFamily: "Mighty Cinco Family",stCelinaDelaware: "St. Celina, Delaware 10299",jan:ImageConstant.imgCalendar,jan1: "Jan 1, 2021",pm:ImageConstant.imgClock,time: "4:00 PM",mightyCincoFamily1:ImageConstant.imgAvatar,buyerSAgent: "Buyer’s Agent",leslieAlexander: "Leslie Alexander")];

 }
