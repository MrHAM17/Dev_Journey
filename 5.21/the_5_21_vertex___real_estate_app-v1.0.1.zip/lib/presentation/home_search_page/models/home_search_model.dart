import '../../../core/app_export.dart';import 'homesearch_item_model.dart';class HomeSearchModel {List<HomesearchItemModel> homesearchItemList = [HomesearchItemModel(mightyCincoFamily:ImageConstant.imgImg40x40,mightyCincoFamily1: "Mighty Cinco Family"),HomesearchItemModel(mightyCincoFamily:ImageConstant.imgImg5,mightyCincoFamily1: "Casablanca Ground"),HomesearchItemModel(mightyCincoFamily:ImageConstant.imgImg6,mightyCincoFamily1: "Primary Apartment")];

 }
