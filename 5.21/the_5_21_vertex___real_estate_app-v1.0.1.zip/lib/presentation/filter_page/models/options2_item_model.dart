import '../../../core/app_export.dart';/// This class is used in the [options2_item_widget] screen.
class Options2ItemModel {Options2ItemModel({this.freeWiFi, this.isSelected, }) { freeWiFi = freeWiFi  ?? "Free WiFi";isSelected = isSelected  ?? false; }

String? freeWiFi;

bool? isSelected;

 }
