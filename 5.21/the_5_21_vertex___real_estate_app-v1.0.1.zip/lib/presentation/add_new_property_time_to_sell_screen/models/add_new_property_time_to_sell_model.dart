import '../../../core/app_export.dart';import 'addnewpropertytimetosell_item_model.dart';class AddNewPropertyTimeToSellModel {List<AddnewpropertytimetosellItemModel> addnewpropertytimetosellItemList = [AddnewpropertytimetosellItemModel(duration: "Within 3 days"),AddnewpropertytimetosellItemModel(duration: "Within 1 week"),AddnewpropertytimetosellItemModel(duration: "Within 1 month"),AddnewpropertytimetosellItemModel(duration: "Within 2 months"),AddnewpropertytimetosellItemModel(duration: "In more than 2 months"),AddnewpropertytimetosellItemModel(duration: "I’m not sure")];

 }
