import '../../../core/app_export.dart';import 'selectvirtualapp_item_model.dart';class SelectVirtualAppModel {List<SelectvirtualappItemModel> selectvirtualappItemList = [SelectvirtualappItemModel(whatsapp:ImageConstant.imgWhatsapp,whatsapp1: "Whatsapp",recommend: "Recommend",check:ImageConstant.imgCheck)];

 }
