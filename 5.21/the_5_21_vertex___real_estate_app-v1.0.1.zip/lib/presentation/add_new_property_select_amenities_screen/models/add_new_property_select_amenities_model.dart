import 'options_item_model.dart';import '../../../core/app_export.dart';class AddNewPropertySelectAmenitiesModel {List<OptionsItemModel> optionsItemList = List.generate(8,(index) =>OptionsItemModel());

 }
