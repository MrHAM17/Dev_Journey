import '../../../core/app_export.dart';import 'list_item_model.dart';class MyHomeModel {List<ListItemModel> listItemList = [ListItemModel(primaryApartment: "Primary Apartment",three: "3",two: "2",price: "1,600 - 1,800 "),ListItemModel(primaryApartment: "Primary Apartment",price: "1,600 - 1,800 "),ListItemModel(primaryApartment: "Primary Apartment",price: "1,600 - 1,800 ")];

 }
