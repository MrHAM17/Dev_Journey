import '../../../core/app_export.dart';class RecentlyViewsModel { }
