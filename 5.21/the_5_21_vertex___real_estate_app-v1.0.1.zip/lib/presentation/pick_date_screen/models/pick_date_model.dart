import '../../../core/app_export.dart';import 'time1_item_model.dart';class PickDateModel {List<Time1ItemModel> time1ItemList = [Time1ItemModel(time: "9:00 AM"),Time1ItemModel(time: "9:30 AM"),Time1ItemModel(time: "10:00 AM"),Time1ItemModel(time: "10:30 AM")];

 }
