import '../../../core/app_export.dart';import 'time_item_model.dart';class AddNewPropertyMeetWithAAgentModel {List<TimeItemModel> timeItemList = [TimeItemModel(time: "9:00 AM"),TimeItemModel(time: "9:30 AM"),TimeItemModel(time: "10:00 AM"),TimeItemModel(time: "10:30 AM")];

 }
