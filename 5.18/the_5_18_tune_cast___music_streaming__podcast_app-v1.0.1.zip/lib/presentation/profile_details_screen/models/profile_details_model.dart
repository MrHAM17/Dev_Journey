import '../../../core/app_export.dart';import 'profiledetails_item_model.dart';class ProfileDetailsModel {List<ProfiledetailsItemModel> profiledetailsItemList = [ProfiledetailsItemModel(image:ImageConstant.imgImage74,positions: "Ariana Grande - All \nSongs "),ProfiledetailsItemModel(image:ImageConstant.imgImage75,positions: "Ariana Grande - Top \nGreatest Hits")];

 }
