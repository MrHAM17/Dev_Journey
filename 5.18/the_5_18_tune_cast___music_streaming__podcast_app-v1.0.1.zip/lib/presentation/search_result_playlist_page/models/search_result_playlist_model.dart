import '../../../core/app_export.dart';import 'searchresultplaylist_item_model.dart';class SearchResultPlaylistModel {List<SearchresultplaylistItemModel> searchresultplaylistItemList = [SearchresultplaylistItemModel(image:ImageConstant.imgImage74,positions: "Ariana Grande - All \nSongs ",image1:ImageConstant.imgImage75,positions1: "Ariana Grande - Top \nGreatest Hits"),SearchresultplaylistItemModel(image:ImageConstant.imgImage76,positions: "Ariana Grande - Most\nListened Songs",image1:ImageConstant.imgImage77,positions1: "Ariana Grande - \nComplete Albums")];

 }
