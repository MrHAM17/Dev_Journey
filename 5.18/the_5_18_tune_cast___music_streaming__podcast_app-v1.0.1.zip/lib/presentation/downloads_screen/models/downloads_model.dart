import '../../../core/app_export.dart';import 'downloads_item_model.dart';class DownloadsModel {List<DownloadsItemModel> downloadsItemList = [DownloadsItemModel(image:ImageConstant.imgImage61,songTitle: "Starboy Speed Up",details: "Just Lowkey"),DownloadsItemModel(image:ImageConstant.imgImage63,songTitle: "Blinding Lights",details: "The Weeknd")];

 }
