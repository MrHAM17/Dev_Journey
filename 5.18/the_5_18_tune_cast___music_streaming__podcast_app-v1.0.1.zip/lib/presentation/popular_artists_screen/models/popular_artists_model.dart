import '../../../core/app_export.dart';import 'popularartists_item_model.dart';class PopularArtistsModel {List<PopularartistsItemModel> popularartistsItemList = [PopularartistsItemModel(arianaGrande:ImageConstant.imgImage21,artistsName: "Ariana Grande"),PopularartistsItemModel(arianaGrande:ImageConstant.imgImage22,artistsName: "The Weeknd"),PopularartistsItemModel(arianaGrande:ImageConstant.imgImage23,artistsName: "Acidrap"),PopularartistsItemModel(arianaGrande:ImageConstant.imgImage24,artistsName: "Ryan Jones")];

 }
