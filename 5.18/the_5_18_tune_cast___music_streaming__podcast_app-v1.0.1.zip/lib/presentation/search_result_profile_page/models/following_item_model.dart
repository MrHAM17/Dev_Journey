import '../../../core/app_export.dart';/// This class is used in the [following_item_widget] screen.
class FollowingItemModel {FollowingItemModel({this.id}) { id = id  ?? ""; }

String? id;

 }
