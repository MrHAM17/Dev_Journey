import '../../../core/app_export.dart';import 'fortyfive_item_model.dart';import 'following_item_model.dart';class SearchResultProfileModel {List<FortyfiveItemModel> fortyfiveItemList = [FortyfiveItemModel(jennyWilson:ImageConstant.imgImage78,artistName: "Jenny Wilson",followersCounter: "9,489 Followers"),FortyfiveItemModel(jennyWilson:ImageConstant.imgImage79,artistName: "Jenny Foose",followersCounter: "8,811 Followers"),FortyfiveItemModel(jennyWilson:ImageConstant.imgImage80,artistName: "Jenny Hanlin",followersCounter: "3,933 Followers")];

List<FollowingItemModel> followingItemList = List.generate(1,(index) => FollowingItemModel());

 }
