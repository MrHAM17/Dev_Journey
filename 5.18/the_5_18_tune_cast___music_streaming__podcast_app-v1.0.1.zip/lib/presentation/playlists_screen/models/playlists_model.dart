import '../../../core/app_export.dart';import 'playlists_item_model.dart';class PlaylistsModel {List<PlaylistsItemModel> playlistsItemList = [PlaylistsItemModel(addNewPlaylist:ImageConstant.imgCategoriesPlus,loremIpsum: "Add New Playlist")];

 }
