import 'trendingnow_item_model.dart';import '../../../core/app_export.dart';class HomeModel {List<TrendingnowItemModel> trendingnowItemList = [TrendingnowItemModel(groupBy: "Trending Now"),TrendingnowItemModel(groupBy: "Trending Now"),TrendingnowItemModel(groupBy: "Trending Now"),TrendingnowItemModel(groupBy: "Popular Artists"),TrendingnowItemModel(groupBy: "Popular Artists"),TrendingnowItemModel(groupBy: "Popular Artists"),TrendingnowItemModel(groupBy: "Top Charts"),TrendingnowItemModel(groupBy: "Top Charts"),TrendingnowItemModel(groupBy: "Top Charts")];

 }
