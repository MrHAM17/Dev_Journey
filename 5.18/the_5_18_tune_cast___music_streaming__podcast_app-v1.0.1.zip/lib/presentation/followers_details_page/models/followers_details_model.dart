import '../../../core/app_export.dart';import 'ninetyfive_item_model.dart';import 'following1_item_model.dart';class FollowersDetailsModel {List<NinetyfiveItemModel> ninetyfiveItemList = [NinetyfiveItemModel(jennyWilson:ImageConstant.imgImage78,artistName: "Jenny Wilson",followersCounter: "9,489 Followers"),NinetyfiveItemModel(jennyWilson:ImageConstant.imgImage79,artistName: "Jenny Foose",followersCounter: "8,811 Followers")];

List<Following1ItemModel> following1ItemList = List.generate(1,(index) => Following1ItemModel());

 }
