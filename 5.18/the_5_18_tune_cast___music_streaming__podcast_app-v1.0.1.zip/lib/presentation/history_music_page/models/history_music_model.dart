import '../../../core/app_export.dart';import 'historymusic_item_model.dart';class HistoryMusicModel {List<HistorymusicItemModel> historymusicItemList = [HistorymusicItemModel(image:ImageConstant.imgImage61,songTitle: "Starboy Speed Up",details: "Just Lowkey",image1:ImageConstant.imgCategoriesMore),HistorymusicItemModel(image:ImageConstant.imgImage62,songTitle: "Die For You",details: "The Weeknd",image1:ImageConstant.imgCategoriesMore)];

 }
