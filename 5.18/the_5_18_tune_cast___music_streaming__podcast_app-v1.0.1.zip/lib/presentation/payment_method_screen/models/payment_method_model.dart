import '../../../core/app_export.dart';import 'paymentmethod_item_model.dart';class PaymentMethodModel {List<PaymentmethodItemModel> paymentmethodItemList = [PaymentmethodItemModel(payPal:ImageConstant.imgFrameLightBlue600,payPal1: "PayPal"),PaymentmethodItemModel(payPal:ImageConstant.imgFrameRed500,payPal1: "Google Pay")];

 }
