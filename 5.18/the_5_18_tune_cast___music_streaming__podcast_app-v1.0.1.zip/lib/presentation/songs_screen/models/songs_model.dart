import '../../../core/app_export.dart';import 'songs_item_model.dart';class SongsModel {List<SongsItemModel> songsItemList = [SongsItemModel(image:ImageConstant.imgImage61,songTitle: "Starboy Speed Up",details: "Just Lowkey"),SongsItemModel(image:ImageConstant.imgImage63,songTitle: "Blinding Lights",details: "The Weeknd")];

 }
