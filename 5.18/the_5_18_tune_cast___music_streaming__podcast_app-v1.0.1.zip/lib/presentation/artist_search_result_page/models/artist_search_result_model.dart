import '../../../core/app_export.dart';import 'artistsearchresult_item_model.dart';class ArtistSearchResultModel {List<ArtistsearchresultItemModel> artistsearchresultItemList = [ArtistsearchresultItemModel(theWeeknd:ImageConstant.imgImage66,artistName: "The Weeknd"),ArtistsearchresultItemModel(theWeeknd:ImageConstant.imgImage67,artistName: "Ariana Grande"),ArtistsearchresultItemModel(theWeeknd:ImageConstant.imgImage48,artistName: "Katy Perry"),ArtistsearchresultItemModel(theWeeknd:ImageConstant.imgImage69,artistName: "Acidrap")];

 }
