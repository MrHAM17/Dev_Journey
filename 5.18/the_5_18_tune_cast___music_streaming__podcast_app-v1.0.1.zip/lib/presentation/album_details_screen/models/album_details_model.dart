import '../../../core/app_export.dart';import 'albumdetails_item_model.dart';class AlbumDetailsModel {List<AlbumdetailsItemModel> albumdetailsItemList = [AlbumdetailsItemModel(image:ImageConstant.imgImage60,songTitle: "Starboy",details: "The Weeknd, Daft Punk")];

 }
