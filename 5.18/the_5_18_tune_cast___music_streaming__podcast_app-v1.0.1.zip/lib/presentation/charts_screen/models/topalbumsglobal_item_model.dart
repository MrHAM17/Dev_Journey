import '../../../core/app_export.dart';/// This class is used in the [topalbumsglobal_item_widget] screen.
class TopalbumsglobalItemModel {TopalbumsglobalItemModel({this.price, this.loremIpsumDolor, this.id, }) { price = price  ?? "TOP\nALBUMS\nGLOBAL";loremIpsumDolor = loremIpsumDolor  ?? "Top Albums Global";id = id  ?? ""; }

String? price;

String? loremIpsumDolor;

String? id;

 }
