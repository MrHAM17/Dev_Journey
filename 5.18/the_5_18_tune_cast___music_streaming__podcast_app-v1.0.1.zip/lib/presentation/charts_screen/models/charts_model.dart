import '../../../core/app_export.dart';import 'topalbumsglobal_item_model.dart';import 'topalbumsglobal1_item_model.dart';class ChartsModel {List<TopalbumsglobalItemModel> topalbumsglobalItemList = [TopalbumsglobalItemModel(price: "TOP\nALBUMS\nGLOBAL",loremIpsumDolor: "Top Albums Global"),TopalbumsglobalItemModel(price: "TOP\nALBUMS\nGLOBAL",loremIpsumDolor: "Top Albums United..")];

List<Topalbumsglobal1ItemModel> topalbumsglobal1ItemList = [Topalbumsglobal1ItemModel(price: "TOP\nALBUMS\nGLOBAL",loremIpsumDolor: "Top Albums Global"),Topalbumsglobal1ItemModel(price: "TOP\nALBUMS\nGLOBAL",loremIpsumDolor: "Top Albums United..")];

 }
