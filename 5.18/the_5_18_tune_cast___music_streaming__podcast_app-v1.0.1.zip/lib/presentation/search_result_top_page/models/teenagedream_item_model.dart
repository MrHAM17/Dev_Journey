import '../../../core/app_export.dart';/// This class is used in the [teenagedream_item_widget] screen.
class TeenagedreamItemModel {TeenagedreamItemModel({this.id}) { id = id  ?? ""; }

String? id;

 }
