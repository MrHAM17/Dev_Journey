import '../../../core/app_export.dart';import 'follow_item_model.dart';import 'teenagedream_item_model.dart';class SearchResultTopModel {List<FollowItemModel> followItemList = [FollowItemModel(handsome:ImageConstant.imgImage27,songTitle: "HANDSOME",details: "Warren Hue",overflowMenu:ImageConstant.imgOverflowMenuOnprimarycontainer,handsome1:ImageConstant.imgCategoriesMore),FollowItemModel(handsome:ImageConstant.imgImage52,songTitle: "Firework Cover",details: "The Sappear",overflowMenu:ImageConstant.imgOverflowMenuOnprimarycontainer,handsome1:ImageConstant.imgVectorGray90001)];

List<TeenagedreamItemModel> teenagedreamItemList = List.generate(1,(index) => TeenagedreamItemModel());

 }
