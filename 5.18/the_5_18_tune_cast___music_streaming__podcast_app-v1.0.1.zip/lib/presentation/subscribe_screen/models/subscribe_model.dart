import '../../../core/app_export.dart';import 'subscribe_item_model.dart';class SubscribeModel {List<SubscribeItemModel> subscribeItemList = [SubscribeItemModel(price: "9.99",month: "/month",listeningWithBetter: "Listening with better audio quality",listeningWithout: "Listening without restrictions & ads",shufflePlayDownload: "Shuffle play & download unlimited"),SubscribeItemModel(price: "19.99",month: "/3 months",listeningWithBetter: "Listening with better audio quality",listeningWithout: "Listening without restrictions & ads",shufflePlayDownload: "Shuffle play & download unlimited")];

 }
