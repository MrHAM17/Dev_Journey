import '../../../core/app_export.dart';import 'searchresultssongs_item_model.dart';class SearchResultsSongsModel {List<SearchresultssongsItemModel> searchresultssongsItemList = [SearchresultssongsItemModel(image:ImageConstant.imgImage54,songTitle: "Starboy",details: "The Weeknd, Daft Punk"),SearchresultssongsItemModel(image:ImageConstant.imgImage58,songTitle: "The Hills",details: "The Weeknd"),SearchresultssongsItemModel(image:ImageConstant.imgImage59,songTitle: "I Feel It Coming",details: "The Weeknd, Daft Punk")];

 }
