import '../../../core/app_export.dart';import 'profiledetailsone_item_model.dart';class ProfileDetailsOneModel {List<ProfiledetailsoneItemModel> profiledetailsoneItemList = [ProfiledetailsoneItemModel(image:ImageConstant.imgImage74,positions: "Ariana Grande - All \nSongs "),ProfiledetailsoneItemModel(image:ImageConstant.imgImage75,positions: "Ariana Grande - Top \nGreatest Hits")];

 }
