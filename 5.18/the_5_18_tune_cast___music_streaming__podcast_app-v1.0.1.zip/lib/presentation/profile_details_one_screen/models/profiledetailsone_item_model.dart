import '../../../core/app_export.dart';/// This class is used in the [profiledetailsone_item_widget] screen.
class ProfiledetailsoneItemModel {ProfiledetailsoneItemModel({this.image, this.positions, this.id, }) { image = image  ?? ImageConstant.imgImage74;positions = positions  ?? "Ariana Grande - All \nSongs ";id = id  ?? ""; }

String? image;

String? positions;

String? id;

 }
