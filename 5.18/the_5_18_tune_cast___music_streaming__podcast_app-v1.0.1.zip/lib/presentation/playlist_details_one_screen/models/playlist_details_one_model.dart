import '../../../core/app_export.dart';import 'playlistdetailsone_item_model.dart';class PlaylistDetailsOneModel {List<PlaylistdetailsoneItemModel> playlistdetailsoneItemList = [PlaylistdetailsoneItemModel(image:ImageConstant.imgImage60,songTitle: "Starboy",details: "The Weeknd, Daft Punk")];

 }
