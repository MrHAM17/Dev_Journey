import '../../../core/app_export.dart';import 'songplayoverscreen_item_model.dart';class SongPlayOverScreenModel {List<SongplayoverscreenItemModel> songplayoverscreenItemList = [SongplayoverscreenItemModel(image:ImageConstant.imgImage60,songTitle: "Starboy",details: "The Weeknd, Daft Punk",image1:ImageConstant.imgIconlyBoldPlayOnprimarycontainer,image2:ImageConstant.imgCategoriesMore)];

 }
