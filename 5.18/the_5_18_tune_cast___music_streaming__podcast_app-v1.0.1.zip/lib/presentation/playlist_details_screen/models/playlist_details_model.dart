import '../../../core/app_export.dart';import 'playlistdetails_item_model.dart';class PlaylistDetailsModel {List<PlaylistdetailsItemModel> playlistdetailsItemList = [PlaylistdetailsItemModel(image:ImageConstant.imgImage61,songTitle: "Starboy Speed Up",details: "Just Lowkey"),PlaylistdetailsItemModel(image:ImageConstant.imgImage64,songTitle: "The Hills",details: "The Weeknd"),PlaylistdetailsItemModel(image:ImageConstant.imgImage65,songTitle: "I Feel It Coming",details: "The Weeknd, Daft Punk")];

 }
