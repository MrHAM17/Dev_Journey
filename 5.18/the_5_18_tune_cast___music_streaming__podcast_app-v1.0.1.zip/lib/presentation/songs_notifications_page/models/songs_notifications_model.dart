import '../../../core/app_export.dart';import 'songsnotifications_item_model.dart';class SongsNotificationsModel {List<SongsnotificationsItemModel> songsnotificationsItemList = [SongsnotificationsItemModel(today:ImageConstant.imgImage80x80,today1: "Today",text: "|",time: "04:36 mins",breakmysoul: "BREAK MY SOUL",beyonce: "Beyonce",text1: "|",album: "Album",today2:ImageConstant.imgVectorGray90001)];

 }
