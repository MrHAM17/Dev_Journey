import '../../../core/app_export.dart';/// This class is used in the [songsnotifications_item_widget] screen.
class SongsnotificationsItemModel {SongsnotificationsItemModel({this.today, this.today1, this.text, this.time, this.breakmysoul, this.beyonce, this.text1, this.album, this.today2, this.id, }) { today = today  ?? ImageConstant.imgImage80x80;today1 = today1  ?? "Today";text = text  ?? "|";time = time  ?? "04:36 mins";breakmysoul = breakmysoul  ?? "BREAK MY SOUL";beyonce = beyonce  ?? "Beyonce";text1 = text1  ?? "|";album = album  ?? "Album";today2 = today2  ?? ImageConstant.imgVectorGray90001;id = id  ?? ""; }

String? today;

String? today1;

String? text;

String? time;

String? breakmysoul;

String? beyonce;

String? text1;

String? album;

String? today2;

String? id;

 }
