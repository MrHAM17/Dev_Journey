import '../../../core/app_export.dart';class LanguageModel {List<String> radioList = ["lbl_english_us","lbl_english_uk"];

List<String> radioList1 = ["lbl_mandarin","lbl_hindi","lbl_spanish","lbl_french","lbl_arabic","lbl_bengali"];

 }
