import '../../../core/app_export.dart';/// This class is used in the [topalbumsglobal2_item_widget] screen.
class Topalbumsglobal2ItemModel {Topalbumsglobal2ItemModel({this.zero, this.image, this.songTitle, this.details, this.overflowMenu, this.image1, this.id, }) { zero = zero  ?? "1";image = image  ?? ImageConstant.imgImage27;songTitle = songTitle  ?? "HANDSOME";details = details  ?? "Warren Hue";overflowMenu = overflowMenu  ?? ImageConstant.imgOverflowMenuOnprimarycontainer;image1 = image1  ?? ImageConstant.imgCategoriesMore;id = id  ?? ""; }

String? zero;

String? image;

String? songTitle;

String? details;

String? overflowMenu;

String? image1;

String? id;

 }
