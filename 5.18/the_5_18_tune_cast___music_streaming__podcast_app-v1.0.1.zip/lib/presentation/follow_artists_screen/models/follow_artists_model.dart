import '../../../core/app_export.dart';import 'followartists_item_model.dart';class FollowArtistsModel {List<FollowartistsItemModel> followartistsItemList = [FollowartistsItemModel(theWeeknd:ImageConstant.imgEllipse1,artistName: "The Weeknd"),FollowartistsItemModel(theWeeknd:ImageConstant.imgEllipse4,artistName: "Ryan Jones")];

 }
