import '../../../core/app_export.dart';import 'selectpaymentmethod_item_model.dart';class SelectPaymentMethodModel {List<SelectpaymentmethodItemModel> selectpaymentmethodItemList = [SelectpaymentmethodItemModel(payPal:ImageConstant.imgFrameLightBlue600,payPal1: "PayPal"),SelectpaymentmethodItemModel(payPal:ImageConstant.imgFrameRed500,payPal1: "Google Pay")];

 }
