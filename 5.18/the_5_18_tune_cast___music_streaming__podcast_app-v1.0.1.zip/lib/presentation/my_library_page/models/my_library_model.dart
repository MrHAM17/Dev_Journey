import '../../../core/app_export.dart';import 'frame2_item_model.dart';class MyLibraryModel {List<Frame2ItemModel> frame2ItemList = [Frame2ItemModel(theJordanHarb:ImageConstant.imgImage31,billSullivan: "The Jordan Harb..."),Frame2ItemModel(theJordanHarb:ImageConstant.imgImage32,billSullivan: "Apple Talk"),Frame2ItemModel(theJordanHarb:ImageConstant.imgImage33,billSullivan: "Dr. Death")];

 }
