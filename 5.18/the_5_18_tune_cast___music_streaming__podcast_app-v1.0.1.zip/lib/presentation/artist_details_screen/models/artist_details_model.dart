import '../../../core/app_export.dart';import 'artistdetails_item_model.dart';class ArtistDetailsModel {List<ArtistdetailsItemModel> artistdetailsItemList = [ArtistdetailsItemModel(image:ImageConstant.imgImage60,songTitle: "Starboy",details: "The Weeknd, Daft Punk")];

 }
