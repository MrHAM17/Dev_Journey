import '../../../core/app_export.dart';import 'newreleases_item_model.dart';class NewReleasesModel {List<NewreleasesItemModel> newreleasesItemList = [NewreleasesItemModel(positions:ImageConstant.imgImage184x184,positions1: "Positions",arianaGrande: "Ariana Grande"),NewreleasesItemModel(positions:ImageConstant.imgImage41,positions1: "Motomami",arianaGrande: "The Weeknd")];

 }
