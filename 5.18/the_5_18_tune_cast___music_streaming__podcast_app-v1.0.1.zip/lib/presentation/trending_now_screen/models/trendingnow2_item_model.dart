import '../../../core/app_export.dart';/// This class is used in the [trendingnow2_item_widget] screen.
class Trendingnow2ItemModel {Trendingnow2ItemModel({this.image, this.loremIpsumDolor, this.id, }) { image = image  ?? ImageConstant.imgImage188x184;loremIpsumDolor = loremIpsumDolor  ?? "Shades of Love - Ania Szarmach";id = id  ?? ""; }

String? image;

String? loremIpsumDolor;

String? id;

 }
