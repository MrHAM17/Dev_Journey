import '../../../core/app_export.dart';/// This class is used in the [newreleases_item_widget] screen.
class NewreleasesItemModel {NewreleasesItemModel({this.positions, this.positions1, this.arianaGrande, this.id, }) { positions = positions  ?? ImageConstant.imgImage184x184;positions1 = positions1  ?? "Positions";arianaGrande = arianaGrande  ?? "Ariana Grande";id = id  ?? ""; }

String? positions;

String? positions1;

String? arianaGrande;

String? id;

 }
