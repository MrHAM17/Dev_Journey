import '../../../core/app_export.dart';/// This class is used in the [fortyfive_item_widget] screen.
class FortyfiveItemModel {FortyfiveItemModel({this.jennyWilson, this.artistName, this.followersCounter, this.id, }) { jennyWilson = jennyWilson  ?? ImageConstant.imgImage78;artistName = artistName  ?? "Jenny Wilson";followersCounter = followersCounter  ?? "9,489 Followers";id = id  ?? ""; }

String? jennyWilson;

String? artistName;

String? followersCounter;

String? id;

 }
