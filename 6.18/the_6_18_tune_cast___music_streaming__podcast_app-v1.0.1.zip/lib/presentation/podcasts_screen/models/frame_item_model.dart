import '../../../core/app_export.dart';/// This class is used in the [frame_item_widget] screen.
class FrameItemModel {FrameItemModel({this.image, this.billSullivan, this.id, }) { image = image  ?? ImageConstant.imgImage31;billSullivan = billSullivan  ?? "610: Bill Sullivan | Pleased to Meet ...";id = id  ?? ""; }

String? image;

String? billSullivan;

String? id;

 }
