import '../../../core/app_export.dart';/// This class is used in the [frame1_item_widget] screen.
class Frame1ItemModel {Frame1ItemModel({this.theJordanHarb, this.billSullivan, this.id, }) { theJordanHarb = theJordanHarb  ?? ImageConstant.imgImage31;billSullivan = billSullivan  ?? "The Jordan Harb...";id = id  ?? ""; }

String? theJordanHarb;

String? billSullivan;

String? id;

 }
