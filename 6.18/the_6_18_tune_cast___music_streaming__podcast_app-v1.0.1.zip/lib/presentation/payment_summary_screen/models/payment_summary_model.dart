// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [payment_summary_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class PaymentSummaryModel extends Equatable {PaymentSummaryModel() {  }

PaymentSummaryModel copyWith() { return PaymentSummaryModel(
); } 
@override List<Object?> get props => [];
 }
