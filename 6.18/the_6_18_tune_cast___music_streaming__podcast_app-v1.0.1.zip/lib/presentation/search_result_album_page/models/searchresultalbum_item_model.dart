import '../../../core/app_export.dart';/// This class is used in the [searchresultalbum_item_widget] screen.
class SearchresultalbumItemModel {SearchresultalbumItemModel({this.sweetener, this.positions, this.arianaGrande, this.zipcode, this.id, }) { sweetener = sweetener  ?? ImageConstant.imgImage70;positions = positions  ?? "Sweetener";arianaGrande = arianaGrande  ?? "Ariana Grande";zipcode = zipcode  ?? "2018";id = id  ?? ""; }

String? sweetener;

String? positions;

String? arianaGrande;

String? zipcode;

String? id;

 }
