package com.socialdashboardsuikit.app

import com.socialdashboardsuikit.app.appcomponents.base.BaseActivity
import com.socialdashboardsuikit.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}