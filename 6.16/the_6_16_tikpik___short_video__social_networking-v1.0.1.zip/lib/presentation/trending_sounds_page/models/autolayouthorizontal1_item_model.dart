import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal1_item_widget] screen.
class Autolayouthorizontal1ItemModel {Autolayouthorizontal1ItemModel({this.k, this.k1, this.id, }) { k = k  ?? ImageConstant.imgImage19;k1 = k1  ?? "728.5K";id = id  ?? ""; }

String? k;

String? k1;

String? id;

 }
