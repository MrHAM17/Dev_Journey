import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal7_item_widget] screen.
class Autolayouthorizontal7ItemModel {Autolayouthorizontal7ItemModel({this.aubrey, this.name, this.id, }) { aubrey = aubrey  ?? ImageConstant.imgEllipse80x80;name = name  ?? "Aubrey";id = id  ?? ""; }

String? aubrey;

String? name;

String? id;

 }
