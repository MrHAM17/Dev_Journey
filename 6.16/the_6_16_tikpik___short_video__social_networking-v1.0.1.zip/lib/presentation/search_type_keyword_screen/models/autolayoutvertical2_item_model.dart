import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical2_item_widget] screen.
class Autolayoutvertical2ItemModel {Autolayoutvertical2ItemModel({this.arianaGrande, this.id, }) { arianaGrande = arianaGrande  ?? "Ariana Grande";id = id  ?? ""; }

String? arianaGrande;

String? id;

 }
