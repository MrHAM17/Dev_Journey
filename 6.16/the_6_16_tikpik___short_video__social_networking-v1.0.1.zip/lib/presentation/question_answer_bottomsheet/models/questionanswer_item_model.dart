import '../../../core/app_export.dart';/// This class is used in the [questionanswer_item_widget] screen.
class QuestionanswerItemModel {QuestionanswerItemModel({this.bennySpanbauer, this.bennySpanbauer1, this.whatIsYourFavorite, this.image, this.sevenHundredThirtySix, this.id, }) { bennySpanbauer = bennySpanbauer  ?? ImageConstant.imgEllipse15;bennySpanbauer1 = bennySpanbauer1  ?? "Benny Spanbauer";whatIsYourFavorite = whatIsYourFavorite  ?? "What is your favorite fruit?";image = image  ?? ImageConstant.imgIconlyBoldHeart;sevenHundredThirtySix = sevenHundredThirtySix  ?? "736";id = id  ?? ""; }

String? bennySpanbauer;

String? bennySpanbauer1;

String? whatIsYourFavorite;

String? image;

String? sevenHundredThirtySix;

String? id;

 }
