import '../../../core/app_export.dart';/// This class is used in the [golivetogether_item_widget] screen.
class GolivetogetherItemModel {GolivetogetherItemModel({this.chantalShelburne, this.chantalShelburne1, this.time, this.id, }) { chantalShelburne = chantalShelburne  ?? ImageConstant.imgEllipse12;chantalShelburne1 = chantalShelburne1  ?? "Chantal Shelburne";time = time  ?? "9 min ago";id = id  ?? ""; }

String? chantalShelburne;

String? chantalShelburne1;

String? time;

String? id;

 }
