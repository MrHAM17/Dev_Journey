import '../../../core/app_export.dart';/// This class is used in the [follow_item_widget] screen.
class FollowItemModel {FollowItemModel({this.arianaGrande, this.arianaGrande1, this.price, this.id, }) { arianaGrande = arianaGrande  ?? ImageConstant.imgEllipse8;arianaGrande1 = arianaGrande1  ?? "Ariana Grande";price = price  ?? "arianagrande | 27.3M followers";id = id  ?? ""; }

String? arianaGrande;

String? arianaGrande1;

String? price;

String? id;

 }
