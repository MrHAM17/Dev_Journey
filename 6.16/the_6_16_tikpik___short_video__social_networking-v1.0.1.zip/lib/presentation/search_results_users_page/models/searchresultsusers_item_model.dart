import '../../../core/app_export.dart';/// This class is used in the [searchresultsusers_item_widget] screen.
class SearchresultsusersItemModel {SearchresultsusersItemModel({this.darcelBallentine, this.darcelBallentine1, this.price, this.id, }) { darcelBallentine = darcelBallentine  ?? ImageConstant.imgEllipse2;darcelBallentine1 = darcelBallentine1  ?? "Darcel Ballentine";price = price  ?? "darcelballentine | 26.37K ";id = id  ?? ""; }

String? darcelBallentine;

String? darcelBallentine1;

String? price;

String? id;

 }
