import '../../../core/app_export.dart';/// This class is used in the [risingstars_item_widget] screen.
class RisingstarsItemModel {RisingstarsItemModel({this.rochelFoose, this.rochelFoose1, this.distance, this.id, }) { rochelFoose = rochelFoose  ?? ImageConstant.imgEllipse4;rochelFoose1 = rochelFoose1  ?? "Rochel Foose";distance = distance  ?? "55.65M";id = id  ?? ""; }

String? rochelFoose;

String? rochelFoose1;

String? distance;

String? id;

 }
