import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical5_item_widget] screen.
class Autolayoutvertical5ItemModel {Autolayoutvertical5ItemModel({this.image, this.checkmark, this.id, }) { image = image  ?? ImageConstant.imgImage121x121;checkmark = checkmark  ?? ImageConstant.imgCheckmarkPrimary;id = id  ?? ""; }

String? image;

String? checkmark;

String? id;

 }
