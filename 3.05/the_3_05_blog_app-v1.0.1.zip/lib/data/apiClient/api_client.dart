import 'package:the_3_05_blog_app/core/app_export.dart';

class ApiClient {}
