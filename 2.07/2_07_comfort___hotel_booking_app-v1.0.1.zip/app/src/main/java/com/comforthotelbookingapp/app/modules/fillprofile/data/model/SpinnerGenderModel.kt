package com.comforthotelbookingapp.app.modules.fillprofile.`data`.model

import kotlin.String

data class SpinnerGenderModel(
  val itemName: String
)
