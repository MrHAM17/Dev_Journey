package com.comforthotelbookingapp.app.modules.editprofile.`data`.model

import kotlin.String

data class SpinnerGenderModel(
  val itemName: String
)
