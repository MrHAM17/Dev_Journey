package com.comforthotelbookingapp.app.modules.hoteldetails.`data`.model

import kotlin.String

data class SpinnerTypeButtonTypeModel(
  val itemName: String
)
