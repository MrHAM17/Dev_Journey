package com.comforthotelbookingapp.app.modules.gallery.`data`.model

class GalleryRowModel()
