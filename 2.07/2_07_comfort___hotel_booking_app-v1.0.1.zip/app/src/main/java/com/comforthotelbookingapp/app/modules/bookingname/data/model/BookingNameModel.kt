package com.comforthotelbookingapp.app.modules.bookingname.`data`.model

import kotlin.String

data class BookingNameModel(
  /**
   * TODO Replace with dynamic value
   */
  var etLabelValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etLabel1Value: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etDateValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etEmailValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etPhoneValue: String? = null
)
