package com.comforthotelbookingapp.app.modules.searchpagetabcontainer.`data`.model

class SearchPageTabContainerModel()
