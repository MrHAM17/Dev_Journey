package com.comforthotelbookingapp.app.modules.hoteldetails.`data`.model

class PhotosRowModel()
