package com.comforthotelbookingapp.app.modules.editprofile.`data`.model

import kotlin.String

data class SpinnerCountryModel(
  val itemName: String
)
