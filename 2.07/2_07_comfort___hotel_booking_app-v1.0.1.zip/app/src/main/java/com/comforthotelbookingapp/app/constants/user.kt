package com.comforthotelbookingapp.app.constants

import kotlin.Int
import kotlin.String

public object user {
    public val PASSWROD: String = "Abcd1234@@"

    public val ROLE: Int = 1
}
