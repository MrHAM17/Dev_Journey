package com.comforthotelbookingapp.app.modules.searchtypetabcontainer.`data`.model

class SearchTypeTabContainerModel()
