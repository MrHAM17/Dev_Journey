// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [recently_views_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class RecentlyViewsModel extends Equatable {RecentlyViewsModel() {  }

RecentlyViewsModel copyWith() { return RecentlyViewsModel(
); } 
@override List<Object?> get props => [];
 }
