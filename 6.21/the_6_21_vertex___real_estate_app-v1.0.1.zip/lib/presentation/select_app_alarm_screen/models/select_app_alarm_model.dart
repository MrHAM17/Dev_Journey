// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [select_app_alarm_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SelectAppAlarmModel extends Equatable {SelectAppAlarmModel() {  }

SelectAppAlarmModel copyWith() { return SelectAppAlarmModel(
); } 
@override List<Object?> get props => [];
 }
