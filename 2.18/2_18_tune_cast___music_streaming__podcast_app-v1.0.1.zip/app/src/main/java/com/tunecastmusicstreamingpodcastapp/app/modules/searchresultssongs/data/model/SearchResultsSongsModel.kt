package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultssongs.`data`.model

class SearchResultsSongsModel()
