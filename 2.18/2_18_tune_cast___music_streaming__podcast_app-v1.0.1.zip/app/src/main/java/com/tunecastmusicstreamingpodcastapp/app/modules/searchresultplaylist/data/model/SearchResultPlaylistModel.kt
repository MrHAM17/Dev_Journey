package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultplaylist.`data`.model

class SearchResultPlaylistModel()
