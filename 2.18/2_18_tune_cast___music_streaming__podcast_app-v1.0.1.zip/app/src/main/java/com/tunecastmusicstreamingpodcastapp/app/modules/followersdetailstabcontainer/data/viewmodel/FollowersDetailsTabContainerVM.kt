package com.tunecastmusicstreamingpodcastapp.app.modules.followersdetailstabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tunecastmusicstreamingpodcastapp.app.modules.followersdetailstabcontainer.`data`.model.FollowersDetailsTabContainerModel
import org.koin.core.KoinComponent

class FollowersDetailsTabContainerVM : ViewModel(), KoinComponent {
  val followersDetailsTabContainerModel: MutableLiveData<FollowersDetailsTabContainerModel> =
      MutableLiveData(FollowersDetailsTabContainerModel())

  var navArguments: Bundle? = null
}
