package com.tunecastmusicstreamingpodcastapp.app.modules.searchresulttop.`data`.model

class SearchResultTopModel()
