package com.tunecastmusicstreamingpodcastapp.app.modules.historypodcasttabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tunecastmusicstreamingpodcastapp.app.modules.historypodcasttabcontainer.`data`.model.HistoryPodcastTabContainerModel
import org.koin.core.KoinComponent

class HistoryPodcastTabContainerVM : ViewModel(), KoinComponent {
  val historyPodcastTabContainerModel: MutableLiveData<HistoryPodcastTabContainerModel> =
      MutableLiveData(HistoryPodcastTabContainerModel())

  var navArguments: Bundle? = null
}
