package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultprofiletabcontainer.`data`.model

class SearchResultProfileTabContainerModel()
