package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultprofiletabcontainer.ui

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.tunecastmusicstreamingpodcastapp.app.R
import com.tunecastmusicstreamingpodcastapp.app.appcomponents.di.MyApp
import com.tunecastmusicstreamingpodcastapp.app.modules.artistsearchresult.ui.ArtistSearchResultFragment
import com.tunecastmusicstreamingpodcastapp.app.modules.searchresultalbum.ui.SearchResultAlbumFragment
import com.tunecastmusicstreamingpodcastapp.app.modules.searchresultplaylist.ui.SearchResultPlaylistFragment
import com.tunecastmusicstreamingpodcastapp.app.modules.searchresultpodcast.ui.SearchResultPodcastFragment
import com.tunecastmusicstreamingpodcastapp.app.modules.searchresultprofile.ui.SearchResultProfileFragment
import kotlin.Int
import kotlin.String
import kotlin.collections.List

class SearchResultProfileTabContainerActivityPagerAdapter(
    val fragmentManager: FragmentManager,
    val lifecycle: Lifecycle
) : FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int = viewPages.size

    override fun createFragment(position: Int): Fragment = viewPages[position]

    companion object AdapterConstant {
        val title: List<String> =
                listOf(MyApp.getInstance().resources.getString(R.string.lbl_songs),MyApp.getInstance().resources.getString(R.string.lbl_artists),MyApp.getInstance().resources.getString(R.string.lbl_albums),MyApp.getInstance().resources.getString(R.string.lbl_podcasts),MyApp.getInstance().resources.getString(R.string.lbl_playlist),MyApp.getInstance().resources.getString(R.string.lbl_profile))

        val viewPages: List<Fragment> =
                listOf(SearchResultPlaylistFragment(),ArtistSearchResultFragment(),SearchResultAlbumFragment(),SearchResultPodcastFragment(),SearchResultPlaylistFragment(),SearchResultProfileFragment())

    }
}
