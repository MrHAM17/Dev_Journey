package com.tunecastmusicstreamingpodcastapp.app.modules.podcastsnotificationstabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tunecastmusicstreamingpodcastapp.app.modules.podcastsnotificationstabcontainer.`data`.model.PodcastsNotificationsTabContainerModel
import org.koin.core.KoinComponent

class PodcastsNotificationsTabContainerVM : ViewModel(), KoinComponent {
  val podcastsNotificationsTabContainerModel:
      MutableLiveData<PodcastsNotificationsTabContainerModel> =
      MutableLiveData(PodcastsNotificationsTabContainerModel())

  var navArguments: Bundle? = null
}
