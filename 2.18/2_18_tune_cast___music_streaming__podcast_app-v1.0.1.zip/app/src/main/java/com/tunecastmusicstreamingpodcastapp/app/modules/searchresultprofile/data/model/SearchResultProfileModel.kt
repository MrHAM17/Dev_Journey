package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultprofile.`data`.model

class SearchResultProfileModel()
