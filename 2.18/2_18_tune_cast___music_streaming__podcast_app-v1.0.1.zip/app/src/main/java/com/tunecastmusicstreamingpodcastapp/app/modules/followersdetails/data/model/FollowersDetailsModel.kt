package com.tunecastmusicstreamingpodcastapp.app.modules.followersdetails.`data`.model

class FollowersDetailsModel()
