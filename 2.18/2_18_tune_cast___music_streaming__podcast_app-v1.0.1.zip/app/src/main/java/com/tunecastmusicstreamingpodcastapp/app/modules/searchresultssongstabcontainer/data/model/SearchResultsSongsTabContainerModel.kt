package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultssongstabcontainer.`data`.model

class SearchResultsSongsTabContainerModel()
