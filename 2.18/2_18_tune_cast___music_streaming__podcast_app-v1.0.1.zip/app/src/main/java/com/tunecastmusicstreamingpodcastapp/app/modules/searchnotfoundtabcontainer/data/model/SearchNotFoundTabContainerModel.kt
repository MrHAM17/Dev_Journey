package com.tunecastmusicstreamingpodcastapp.app.modules.searchnotfoundtabcontainer.`data`.model

class SearchNotFoundTabContainerModel()
