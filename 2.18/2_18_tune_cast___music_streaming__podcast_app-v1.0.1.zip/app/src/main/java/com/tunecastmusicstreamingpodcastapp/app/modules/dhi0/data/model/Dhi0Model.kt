package com.tunecastmusicstreamingpodcastapp.app.modules.dhi0.`data`.model

import kotlin.String

data class Dhi0Model(
  /**
   * TODO Replace with dynamic value
   */
  var etPhoneNumberValue: String? = null
)
