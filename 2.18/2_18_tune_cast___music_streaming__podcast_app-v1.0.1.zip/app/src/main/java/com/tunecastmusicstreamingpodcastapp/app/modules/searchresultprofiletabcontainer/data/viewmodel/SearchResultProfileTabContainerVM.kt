package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultprofiletabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tunecastmusicstreamingpodcastapp.app.modules.searchresultprofiletabcontainer.`data`.model.SearchResultProfileTabContainerModel
import org.koin.core.KoinComponent

class SearchResultProfileTabContainerVM : ViewModel(), KoinComponent {
  val searchResultProfileTabContainerModel: MutableLiveData<SearchResultProfileTabContainerModel> =
      MutableLiveData(SearchResultProfileTabContainerModel())

  var navArguments: Bundle? = null
}
