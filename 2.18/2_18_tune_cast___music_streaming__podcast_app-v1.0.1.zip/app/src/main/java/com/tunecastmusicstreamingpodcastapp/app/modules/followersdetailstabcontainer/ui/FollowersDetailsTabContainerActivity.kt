package com.tunecastmusicstreamingpodcastapp.app.modules.followersdetailstabcontainer.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.tunecastmusicstreamingpodcastapp.app.R
import com.tunecastmusicstreamingpodcastapp.app.appcomponents.base.BaseActivity
import com.tunecastmusicstreamingpodcastapp.app.databinding.ActivityFollowersDetailsTabContainerBinding
import com.tunecastmusicstreamingpodcastapp.app.modules.followersdetailstabcontainer.`data`.viewmodel.FollowersDetailsTabContainerVM
import kotlin.String
import kotlin.Unit

class FollowersDetailsTabContainerActivity :
    BaseActivity<ActivityFollowersDetailsTabContainerBinding>(R.layout.activity_followers_details_tab_container)
    {
  private val viewModel: FollowersDetailsTabContainerVM by
      viewModels<FollowersDetailsTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.followersDetailsTabContainerVM = viewModel
    val adapter =
    FollowersDetailsTabContainerActivityPagerAdapter(supportFragmentManager,lifecycle)
    binding.viewPagerTabBarView.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTabview,binding.viewPagerTabBarView) { tab, position ->
      tab.text = FollowersDetailsTabContainerActivityPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
      binding.imageArrowDown.setOnClickListener {
        finish()
      }
    }

    companion object {
      const val TAG: String = "FOLLOWERS_DETAILS_TAB_CONTAINER_ACTIVITY"


      fun getIntent(context: Context, bundle: Bundle?): Intent {
        val destIntent = Intent(context, FollowersDetailsTabContainerActivity::class.java)
        destIntent.putExtra("bundle", bundle)
        return destIntent
      }
    }
  }
