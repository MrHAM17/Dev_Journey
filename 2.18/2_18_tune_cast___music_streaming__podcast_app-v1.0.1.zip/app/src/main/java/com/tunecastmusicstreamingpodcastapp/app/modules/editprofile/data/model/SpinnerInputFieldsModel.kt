package com.tunecastmusicstreamingpodcastapp.app.modules.editprofile.`data`.model

import kotlin.String

data class SpinnerInputFieldsModel(
  val itemName: String
)
