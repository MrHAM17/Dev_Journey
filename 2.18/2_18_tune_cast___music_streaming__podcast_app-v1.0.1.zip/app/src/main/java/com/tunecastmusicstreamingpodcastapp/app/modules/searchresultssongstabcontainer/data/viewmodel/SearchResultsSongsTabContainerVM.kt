package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultssongstabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tunecastmusicstreamingpodcastapp.app.modules.searchresultssongstabcontainer.`data`.model.SearchResultsSongsTabContainerModel
import org.koin.core.KoinComponent

class SearchResultsSongsTabContainerVM : ViewModel(), KoinComponent {
  val searchResultsSongsTabContainerModel: MutableLiveData<SearchResultsSongsTabContainerModel> =
      MutableLiveData(SearchResultsSongsTabContainerModel())

  var navArguments: Bundle? = null
}
