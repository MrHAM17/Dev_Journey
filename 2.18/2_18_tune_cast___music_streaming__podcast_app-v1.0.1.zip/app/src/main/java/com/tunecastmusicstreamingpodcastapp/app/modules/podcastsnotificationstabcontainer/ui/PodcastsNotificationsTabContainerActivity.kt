package com.tunecastmusicstreamingpodcastapp.app.modules.podcastsnotificationstabcontainer.ui

import androidx.activity.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.tunecastmusicstreamingpodcastapp.app.R
import com.tunecastmusicstreamingpodcastapp.app.appcomponents.base.BaseActivity
import com.tunecastmusicstreamingpodcastapp.app.databinding.ActivityPodcastsNotificationsTabContainerBinding
import com.tunecastmusicstreamingpodcastapp.app.modules.podcastsnotificationstabcontainer.`data`.viewmodel.PodcastsNotificationsTabContainerVM
import kotlin.String
import kotlin.Unit

class PodcastsNotificationsTabContainerActivity :
    BaseActivity<ActivityPodcastsNotificationsTabContainerBinding>(R.layout.activity_podcasts_notifications_tab_container)
    {
  private val viewModel: PodcastsNotificationsTabContainerVM by
      viewModels<PodcastsNotificationsTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.podcastsNotificationsTabContainerVM = viewModel
    val adapter =
    PodcastsNotificationsTabContainerActivityPagerAdapter(supportFragmentManager,lifecycle)
    binding.viewPagerTabBarView.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTabview,binding.viewPagerTabBarView) { tab, position ->
      tab.text = PodcastsNotificationsTabContainerActivityPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
      binding.imageArrowDown.setOnClickListener {
        finish()
      }
    }

    companion object {
      const val TAG: String = "PODCASTS_NOTIFICATIONS_TAB_CONTAINER_ACTIVITY"

    }
  }
