package com.tunecastmusicstreamingpodcastapp.app.modules.searchresultalbum.`data`.model

class SearchResultAlbumModel()
