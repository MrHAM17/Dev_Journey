package com.tunecastmusicstreamingpodcastapp.app.modules.splash.`data`.model

class SplashModel()
