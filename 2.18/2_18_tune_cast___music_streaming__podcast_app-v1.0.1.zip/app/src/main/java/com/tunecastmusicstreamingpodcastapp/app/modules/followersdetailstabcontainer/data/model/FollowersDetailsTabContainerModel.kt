package com.tunecastmusicstreamingpodcastapp.app.modules.followersdetailstabcontainer.`data`.model

class FollowersDetailsTabContainerModel()
