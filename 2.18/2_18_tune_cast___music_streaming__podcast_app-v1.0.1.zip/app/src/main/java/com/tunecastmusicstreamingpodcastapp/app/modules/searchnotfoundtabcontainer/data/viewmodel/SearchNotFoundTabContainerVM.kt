package com.tunecastmusicstreamingpodcastapp.app.modules.searchnotfoundtabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tunecastmusicstreamingpodcastapp.app.modules.searchnotfoundtabcontainer.`data`.model.SearchNotFoundTabContainerModel
import org.koin.core.KoinComponent

class SearchNotFoundTabContainerVM : ViewModel(), KoinComponent {
  val searchNotFoundTabContainerModel: MutableLiveData<SearchNotFoundTabContainerModel> =
      MutableLiveData(SearchNotFoundTabContainerModel())

  var navArguments: Bundle? = null
}
