package com.tunecastmusicstreamingpodcastapp.app.modules.artistsearchresult.`data`.model

class ArtistSearchResultModel()
