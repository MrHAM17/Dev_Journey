package com.tunecastmusicstreamingpodcastapp.app.modules.newplaylist.`data`.model

import kotlin.String

data class SpinnerEyeModel(
  val itemName: String
)
