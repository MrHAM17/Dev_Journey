package com.musicplayer.app.modules.playlist.`data`.model

class PlaylistModel()
