package com.vertexrealestateapp.app.modules.filter.`data`.model

import kotlin.String

data class SpinnerMin1Model(
  val itemName: String
)
