package com.vertexrealestateapp.app.modules.addnewpropertyhomefacts.`data`.model

import kotlin.String

data class SpinnerInputFieldsModel(
  val itemName: String
)
