package com.vertexrealestateapp.app.modules.addnewpropertyaddress.`data`.model

import kotlin.String

data class SpinnerInputFieldsModel(
  val itemName: String
)
