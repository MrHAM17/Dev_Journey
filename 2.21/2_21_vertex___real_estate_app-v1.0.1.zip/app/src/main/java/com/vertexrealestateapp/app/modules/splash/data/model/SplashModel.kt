package com.vertexrealestateapp.app.modules.splash.`data`.model

class SplashModel()
