package com.vertexrealestateapp.app.modules.productdetails.`data`.model

class ImagesRowModel()
