package com.vertexrealestateapp.app.modules.filter.`data`.model

import kotlin.String

data class SpinnerMin2Model(
  val itemName: String
)
