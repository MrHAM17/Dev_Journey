package com.vertexrealestateapp.app.modules.filter.`data`.model

import kotlin.String

data class SpinnerMinModel(
  val itemName: String
)
