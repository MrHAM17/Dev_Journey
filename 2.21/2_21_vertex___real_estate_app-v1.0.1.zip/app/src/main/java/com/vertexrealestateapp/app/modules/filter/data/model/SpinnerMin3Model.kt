package com.vertexrealestateapp.app.modules.filter.`data`.model

import kotlin.String

data class SpinnerMin3Model(
  val itemName: String
)
