import '../../../core/app_export.dart';import 'golivetogether_item_model.dart';class GoLiveTogetherModel {List<GolivetogetherItemModel> golivetogetherItemList = [GolivetogetherItemModel(chantalShelburne:ImageConstant.imgEllipse12,chantalShelburne1: "Chantal Shelburne",time: "9 min ago"),GolivetogetherItemModel(chantalShelburne:ImageConstant.imgEllipse14,chantalShelburne1: "Krishna Barbe",time: "12 min ago"),GolivetogetherItemModel(chantalShelburne:ImageConstant.imgEllipse7,chantalShelburne1: "Sanjuanita Ordonez",time: "14 min ago")];

 }
