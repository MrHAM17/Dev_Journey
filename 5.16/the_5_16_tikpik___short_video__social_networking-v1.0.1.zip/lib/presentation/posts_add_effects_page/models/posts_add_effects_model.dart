import '../../../core/app_export.dart';import 'postsaddeffects_item_model.dart';class PostsAddEffectsModel {List<PostsaddeffectsItemModel> postsaddeffectsItemList = [PostsaddeffectsItemModel(image:ImageConstant.imgImage45,image1:ImageConstant.imgImage46,image2:ImageConstant.imgImage47,image3:ImageConstant.imgImage48,image4:ImageConstant.imgImage49,image5:ImageConstant.imgImage50)];

 }
