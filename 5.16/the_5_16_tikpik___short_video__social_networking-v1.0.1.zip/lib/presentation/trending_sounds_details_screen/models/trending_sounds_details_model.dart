import '../../../core/app_export.dart';import 'autolayoutvertical3_item_model.dart';class TrendingSoundsDetailsModel {List<Autolayoutvertical3ItemModel> autolayoutvertical3ItemList = [Autolayoutvertical3ItemModel(k:ImageConstant.imgImage25,k1:ImageConstant.imgOverflowmenuPrimary,k2: "837.5K",k3:ImageConstant.imgImage26,k4: "837.5K",k5:ImageConstant.imgImage27,k6: "837.5K",k7:ImageConstant.imgImage28,k8: "837.5K")];

 }
