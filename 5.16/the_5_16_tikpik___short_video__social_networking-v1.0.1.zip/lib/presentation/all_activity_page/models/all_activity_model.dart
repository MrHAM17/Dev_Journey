import 'package:the_5_16_tikpik___short_video__social_networking/data/models/selectionPopupModel/selection_popup_model.dart';import '../../../core/app_export.dart';import 'followback_item_model.dart';import 'followback1_item_model.dart';class AllActivityModel {List<SelectionPopupModel> dropdownItemList = [SelectionPopupModel(id:1,title:"Item One",isSelected:true,),SelectionPopupModel(id:2,title:"Item Two",),SelectionPopupModel(id:3,title:"Item Three",)];

List<FollowbackItemModel> followbackItemList = [FollowbackItemModel(charoletteHanlin:ImageConstant.imgEllipse14,charoletteHanlin1: "Charolette Hanlin",information: "Leave a comment on your video",charoletteHanlin2:ImageConstant.imgImage60x60),FollowbackItemModel(charoletteHanlin:ImageConstant.imgEllipse20,charoletteHanlin1: "Annabel Rohan",information: "Started following you"),FollowbackItemModel(charoletteHanlin:ImageConstant.imgEllipse12,charoletteHanlin1: "Sanjuanita Ordonez",information: "Liked your video",charoletteHanlin2:ImageConstant.imgImage70)];

List<Followback1ItemModel> followback1ItemList = [Followback1ItemModel(clintonMcclure:ImageConstant.imgEllipse21,clintonMcclure1: "Clinton Mcclure",startedfollowingyou: "Started following you")];

 }
