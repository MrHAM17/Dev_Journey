import '../../../core/app_export.dart';/// This class is used in the [followback1_item_widget] screen.
class Followback1ItemModel {Followback1ItemModel({this.clintonMcclure, this.clintonMcclure1, this.startedfollowingyou, this.id, }) { clintonMcclure = clintonMcclure  ?? ImageConstant.imgEllipse21;clintonMcclure1 = clintonMcclure1  ?? "Clinton Mcclure";startedfollowingyou = startedfollowingyou  ?? "Started following you";id = id  ?? ""; }

String? clintonMcclure;

String? clintonMcclure1;

String? startedfollowingyou;

String? id;

 }
