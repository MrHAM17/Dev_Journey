import '../../../core/app_export.dart';import 'autolayouthorizontal3_item_model.dart';import 'autolayouthorizontal4_item_model.dart';class TrendingHashtagModel {List<Autolayouthorizontal3ItemModel> autolayouthorizontal3ItemList = [Autolayouthorizontal3ItemModel(k:ImageConstant.imgImage31,overflowMenu:ImageConstant.imgOverflowMenuPrimary16x16,k1: "728.5K"),Autolayouthorizontal3ItemModel(k:ImageConstant.imgImage32,k1: "837.9K"),Autolayouthorizontal3ItemModel(k:ImageConstant.imgImage33,k1: "736.2K")];

List<Autolayouthorizontal4ItemModel> autolayouthorizontal4ItemList = [Autolayouthorizontal4ItemModel(k:ImageConstant.imgImage19,k1:ImageConstant.imgOverflowmenuPrimary,k2: "728.5K"),Autolayouthorizontal4ItemModel(k:ImageConstant.imgImage20,k2: "837.9K"),Autolayouthorizontal4ItemModel(k:ImageConstant.imgImage21,k2: "736.2K")];

 }
