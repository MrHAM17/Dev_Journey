import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical4_item_widget] screen.
class Autolayoutvertical4ItemModel {Autolayoutvertical4ItemModel({this.k, this.overflowMenu, this.k1, this.id, }) { k = k  ?? ImageConstant.imgImage34;overflowMenu = overflowMenu  ?? ImageConstant.imgOverflowMenuPrimary16x16;k1 = k1  ?? "837.5K";id = id  ?? ""; }

String? k;

String? overflowMenu;

String? k1;

String? id;

 }
