import '../../../core/app_export.dart';class ReportModel {List<String> radioList = ["msg_violent_graphic","lbl_animal_cruelty","msg_pornography_nudity","lbl_hate_speech","msg_harassment_or_bullying","msg_intellectual_property","lbl_spam","lbl_minor_safety","lbl_other"];

 }
