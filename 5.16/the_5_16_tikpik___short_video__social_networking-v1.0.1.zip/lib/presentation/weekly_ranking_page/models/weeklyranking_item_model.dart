import '../../../core/app_export.dart';/// This class is used in the [weeklyranking_item_widget] screen.
class WeeklyrankingItemModel {WeeklyrankingItemModel({this.tynishaObey, this.distance, this.id, }) { tynishaObey = tynishaObey  ?? "Tynisha Obey";distance = distance  ?? "26.37M";id = id  ?? ""; }

String? tynishaObey;

String? distance;

String? id;

 }
