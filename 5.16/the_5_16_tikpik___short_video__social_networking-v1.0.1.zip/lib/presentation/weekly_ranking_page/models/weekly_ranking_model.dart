import '../../../core/app_export.dart';import 'weeklyranking_item_model.dart';class WeeklyRankingModel {List<WeeklyrankingItemModel> weeklyrankingItemList = [WeeklyrankingItemModel(tynishaObey: "Tynisha Obey",distance: "26.37M")];

 }
