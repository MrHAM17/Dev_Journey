import '../../../core/app_export.dart';import 'autolayoutvertical_item_model.dart';class ProfileModel {List<AutolayoutverticalItemModel> autolayoutverticalItemList = [AutolayoutverticalItemModel(k:ImageConstant.imgImage5,k1:ImageConstant.imgOverflowmenuPrimary,k2: "367.5K",k3:ImageConstant.imgImage6,overflowMenu:ImageConstant.imgOverflowMenuPrimary16x16,k4: "837.9K")];

 }
