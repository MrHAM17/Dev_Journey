import '../../../core/app_export.dart';import 'searchresultsvideos_item_model.dart';class SearchResultsVideosModel {List<SearchresultsvideosItemModel> searchresultsvideosItemList = [SearchresultsvideosItemModel(k:ImageConstant.imgImage300x186,k1:ImageConstant.imgOverflowmenuPrimary,k2: "837.5K"),SearchresultsvideosItemModel(k:ImageConstant.imgImage11,k2: "736.3K"),SearchresultsvideosItemModel(k:ImageConstant.imgImage12,k1:ImageConstant.imgOverflowmenuPrimary,k2: "639.8K"),SearchresultsvideosItemModel(k:ImageConstant.imgImage13,k1:ImageConstant.imgOverflowmenuPrimary,k2: "528.5K")];

 }
