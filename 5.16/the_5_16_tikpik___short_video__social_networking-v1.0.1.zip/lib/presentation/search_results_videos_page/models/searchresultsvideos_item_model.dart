import '../../../core/app_export.dart';/// This class is used in the [searchresultsvideos_item_widget] screen.
class SearchresultsvideosItemModel {SearchresultsvideosItemModel({this.k, this.k1, this.k2, this.radioGroup, this.id, }) { k = k  ?? ImageConstant.imgImage300x186;k1 = k1  ?? ImageConstant.imgOverflowmenuPrimary;k2 = k2  ?? "837.5K";radioGroup = radioGroup  ?? "";id = id  ?? ""; }

String? k;

String? k1;

String? k2;

String? radioGroup;

String? id;

 }
