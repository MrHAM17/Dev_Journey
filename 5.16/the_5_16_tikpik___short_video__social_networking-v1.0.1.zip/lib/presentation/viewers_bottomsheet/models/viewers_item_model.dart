import '../../../core/app_export.dart';/// This class is used in the [viewers_item_widget] screen.
class ViewersItemModel {ViewersItemModel({this.darylNehls, this.id, }) { darylNehls = darylNehls  ?? "Daryl Nehls";id = id  ?? ""; }

String? darylNehls;

String? id;

 }
