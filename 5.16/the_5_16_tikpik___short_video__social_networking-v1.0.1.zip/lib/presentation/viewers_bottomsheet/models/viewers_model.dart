import '../../../core/app_export.dart';import 'viewers_item_model.dart';class ViewersModel {List<ViewersItemModel> viewersItemList = [ViewersItemModel(darylNehls: "Daryl Nehls"),ViewersItemModel(darylNehls: "Daryl Nehls")];

 }
