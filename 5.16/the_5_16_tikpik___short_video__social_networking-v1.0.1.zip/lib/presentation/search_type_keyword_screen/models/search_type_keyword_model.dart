import '../../../core/app_export.dart';import 'autolayoutvertical1_item_model.dart';import 'autolayoutvertical2_item_model.dart';class SearchTypeKeywordModel {List<Autolayoutvertical1ItemModel> autolayoutvertical1ItemList = [Autolayoutvertical1ItemModel(theresaWebb: "Theresa Webb"),Autolayoutvertical1ItemModel(theresaWebb: "Cameron Williamson"),Autolayoutvertical1ItemModel(theresaWebb: "Floyd Miles"),Autolayoutvertical1ItemModel(theresaWebb: "Savannah Nguyen")];

List<Autolayoutvertical2ItemModel> autolayoutvertical2ItemList = [Autolayoutvertical2ItemModel(arianaGrande: "Ariana Grande"),Autolayoutvertical2ItemModel(arianaGrande: "Ariana Cooper"),Autolayoutvertical2ItemModel(arianaGrande: "Ariana Wilson")];

 }
