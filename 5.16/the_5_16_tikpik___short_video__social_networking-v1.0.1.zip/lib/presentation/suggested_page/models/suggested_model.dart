import '../../../core/app_export.dart';import 'suggested_item_model.dart';class SuggestedModel {List<SuggestedItemModel> suggestedItemList = [SuggestedItemModel(rayfordChenail:ImageConstant.imgEllipse3,rayfordChenail1: "Rayford Chenail",price: "rayfordchenail | 42.9K")];

 }
