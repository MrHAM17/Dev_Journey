import '../../../core/app_export.dart';/// This class is used in the [suggested_item_widget] screen.
class SuggestedItemModel {SuggestedItemModel({this.rayfordChenail, this.rayfordChenail1, this.price, this.id, }) { rayfordChenail = rayfordChenail  ?? ImageConstant.imgEllipse3;rayfordChenail1 = rayfordChenail1  ?? "Rayford Chenail";price = price  ?? "rayfordchenail | 42.9K";id = id  ?? ""; }

String? rayfordChenail;

String? rayfordChenail1;

String? price;

String? id;

 }
