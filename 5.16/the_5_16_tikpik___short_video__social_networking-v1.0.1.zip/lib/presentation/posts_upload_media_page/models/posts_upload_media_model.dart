import '../../../core/app_export.dart';import 'autolayoutvertical5_item_model.dart';class PostsUploadMediaModel {List<Autolayoutvertical5ItemModel> autolayoutvertical5ItemList = [Autolayoutvertical5ItemModel(image:ImageConstant.imgImage121x121,checkmark:ImageConstant.imgCheckmarkPrimary),Autolayoutvertical5ItemModel(image:ImageConstant.imgImage121x120,checkmark:ImageConstant.imgContrastPrimary20x20),Autolayoutvertical5ItemModel(image:ImageConstant.imgImage57)];

 }
