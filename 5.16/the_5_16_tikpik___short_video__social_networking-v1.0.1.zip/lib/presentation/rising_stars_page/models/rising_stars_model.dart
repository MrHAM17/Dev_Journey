import '../../../core/app_export.dart';import 'risingstars_item_model.dart';class RisingStarsModel {List<RisingstarsItemModel> risingstarsItemList = [RisingstarsItemModel(rochelFoose:ImageConstant.imgEllipse4,rochelFoose1: "Rochel Foose",distance: "55.65M")];

 }
