import '../../../core/app_export.dart';import 'autolayouthorizontal7_item_model.dart';import 'theresavarnes_item_model.dart';class MessagesModel {List<Autolayouthorizontal7ItemModel> autolayouthorizontal7ItemList = [Autolayouthorizontal7ItemModel(aubrey:ImageConstant.imgEllipse80x80,name: "Aubrey"),Autolayouthorizontal7ItemModel(aubrey:ImageConstant.imgEllipse23,name: "Darrell"),Autolayouthorizontal7ItemModel(aubrey:ImageConstant.imgEllipse24,name: "Julie"),Autolayouthorizontal7ItemModel(aubrey:ImageConstant.imgEllipse25,name: "Kristin"),Autolayouthorizontal7ItemModel(aubrey:ImageConstant.imgEllipse26,name: "Brandie")];

List<TheresavarnesItemModel> theresavarnesItemList = [TheresavarnesItemModel(theresaVarnes:ImageConstant.imgEllipse4,name: "Theresa Varnes",message: "Hi, morning too Andrew!",autoLayoutHorizontal: "1",twoThousand: "10.00")];

 }
