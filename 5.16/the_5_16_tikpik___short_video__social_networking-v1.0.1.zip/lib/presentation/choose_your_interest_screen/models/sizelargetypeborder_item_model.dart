import '../../../core/app_export.dart';/// This class is used in the [sizelargetypeborder_item_widget] screen.
class SizelargetypeborderItemModel {SizelargetypeborderItemModel({this.sizeLargeTypeBorder, this.isSelected, }) { sizeLargeTypeBorder = sizeLargeTypeBorder  ?? "Gaming";isSelected = isSelected  ?? false; }

String? sizeLargeTypeBorder;

bool? isSelected;

 }
