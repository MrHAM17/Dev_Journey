import 'sizelargetypeborder_item_model.dart';import '../../../core/app_export.dart';class ChooseYourInterestModel {List<SizelargetypeborderItemModel> sizelargetypeborderItemList = List.generate(17,(index) =>SizelargetypeborderItemModel());

 }
