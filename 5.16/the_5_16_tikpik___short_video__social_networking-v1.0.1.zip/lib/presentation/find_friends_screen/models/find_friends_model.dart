import '../../../core/app_export.dart';import 'findfriends_item_model.dart';class FindFriendsModel {List<FindfriendsItemModel> findfriendsItemList = [FindfriendsItemModel(categoriesShare:ImageConstant.imgCategoriesSharePrimary,inviteFriends: "Invite Friends",stayConnectedWith: "Stay Connected with friends")];

 }
