import '../../../core/app_export.dart';import 'seelive_item_model.dart';class SeeLiveModel {List<SeeliveItemModel> seeliveItemList = [SeeliveItemModel(darylNehls: "Daryl Nehls",woohoooo: "woohoooo"),SeeliveItemModel(darylNehls: "Alfonzo Schuessler",woohoooo: "How are you?"),SeeliveItemModel(darylNehls: "Tynisha Obey",woohoooo: "I'd like if we could elaborate more on this."),SeeliveItemModel(darylNehls: "Kylee Danford",woohoooo: "Wow, this is really epic"),SeeliveItemModel(darylNehls: "Benny Spanbauer",woohoooo: "Haha that's terrifying 😂"),SeeliveItemModel(woohoooo: "Augustina Midgett")];

 }
