import 'autolayouthorizontal5_item_model.dart';import '../../../core/app_export.dart';class PostsCameraModel {List<Autolayouthorizontal5ItemModel> autolayouthorizontal5ItemList = List.generate(3,(index) =>Autolayouthorizontal5ItemModel());

 }
