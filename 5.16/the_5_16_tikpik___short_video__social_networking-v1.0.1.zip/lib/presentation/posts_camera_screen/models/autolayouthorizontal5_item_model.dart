import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal5_item_widget] screen.
class Autolayouthorizontal5ItemModel {Autolayouthorizontal5ItemModel({this.m, this.isSelected, }) { m = m  ?? "3m";isSelected = isSelected  ?? false; }

String? m;

bool? isSelected;

 }
