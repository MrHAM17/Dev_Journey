import '../../../core/app_export.dart';import 'searchresultssounds_item_model.dart';class SearchResultsSoundsModel {List<SearchresultssoundsItemModel> searchresultssoundsItemList = [SearchresultssoundsItemModel(k:ImageConstant.imgImage80x80,soundsTitle: "Side to Side",singer: "Ariana Grande",time: "01:00",total: "938.6K"),SearchresultssoundsItemModel(k:ImageConstant.imgImage15,soundsTitle: "7 Rings",singer: "Ariana Grande",time: "00:50",total: "762.5K")];

 }
