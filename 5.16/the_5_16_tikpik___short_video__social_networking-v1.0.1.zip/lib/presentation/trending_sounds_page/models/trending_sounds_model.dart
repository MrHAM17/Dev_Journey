import '../../../core/app_export.dart';import 'autolayouthorizontal1_item_model.dart';import 'autolayouthorizontal2_item_model.dart';class TrendingSoundsModel {List<Autolayouthorizontal1ItemModel> autolayouthorizontal1ItemList = [Autolayouthorizontal1ItemModel(k:ImageConstant.imgImage19,k1: "728.5K"),Autolayouthorizontal1ItemModel(k:ImageConstant.imgImage20,k1: "837.9K"),Autolayouthorizontal1ItemModel(k:ImageConstant.imgImage21,k1: "736.2K")];

List<Autolayouthorizontal2ItemModel> autolayouthorizontal2ItemList = [Autolayouthorizontal2ItemModel(k:ImageConstant.imgImage22,k1:ImageConstant.imgOverflowmenuPrimary,k2: "728.5K"),Autolayouthorizontal2ItemModel(k:ImageConstant.imgImage23,k2: "837.9K"),Autolayouthorizontal2ItemModel(k:ImageConstant.imgImage24,k1:ImageConstant.imgOverflowmenuPrimary,k2: "736.2K")];

 }
