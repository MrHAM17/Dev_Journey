import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal_item_widget] screen.
class AutolayouthorizontalItemModel {AutolayouthorizontalItemModel({this.k, this.k1, this.k2, this.id, }) { k = k  ?? ImageConstant.imgImage5;k1 = k1  ?? ImageConstant.imgOverflowmenuPrimary;k2 = k2  ?? "367.5K";id = id  ?? ""; }

String? k;

String? k1;

String? k2;

String? id;

 }
