import '../../../core/app_export.dart';import 'follow_item_model.dart';import 'autolayouthorizontal_item_model.dart';class SearchResultsTopModel {List<FollowItemModel> followItemList = [FollowItemModel(arianaGrande:ImageConstant.imgEllipse8,arianaGrande1: "Ariana Grande",price: "arianagrande | 27.3M followers"),FollowItemModel(arianaGrande:ImageConstant.imgEllipse9,arianaGrande1: "Ariana Cooper",price: "arianacooper | 24.5M followers")];

List<AutolayouthorizontalItemModel> autolayouthorizontalItemList = [AutolayouthorizontalItemModel(k:ImageConstant.imgImage5,k1:ImageConstant.imgOverflowmenuPrimary,k2: "367.5K"),AutolayouthorizontalItemModel(k:ImageConstant.imgImage10,k2: "837.9K"),AutolayouthorizontalItemModel(k:ImageConstant.imgImage7,k2: "736.2K")];

 }
