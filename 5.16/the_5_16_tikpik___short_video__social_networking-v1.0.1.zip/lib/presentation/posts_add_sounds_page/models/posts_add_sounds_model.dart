import '../../../core/app_export.dart';import 'postsaddsounds_item_model.dart';class PostsAddSoundsModel {List<PostsaddsoundsItemModel> postsaddsoundsItemList = [PostsaddsoundsItemModel(asItWas:ImageConstant.imgImage15,overflowMenu:ImageConstant.imgOverflowMenuOnerrorcontainer,asItWas1: "As It Was",harryStyles: "Harry Styles",time: "01:00",distance: "65.1M",m:ImageConstant.imgBookmarkPrimary24x24)];

 }
