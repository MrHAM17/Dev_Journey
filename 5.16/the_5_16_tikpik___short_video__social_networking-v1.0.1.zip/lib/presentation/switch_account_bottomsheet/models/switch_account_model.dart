import '../../../core/app_export.dart';import 'switchaccount_item_model.dart';class SwitchAccountModel {List<SwitchaccountItemModel> switchaccountItemList = [SwitchaccountItemModel(andrewAinsley:ImageConstant.imgEllipse30,name: "Andrew Ainsley",information: "andrew_aisnley",andrewAinsley1:ImageConstant.imgCategoriesCheck)];

 }
