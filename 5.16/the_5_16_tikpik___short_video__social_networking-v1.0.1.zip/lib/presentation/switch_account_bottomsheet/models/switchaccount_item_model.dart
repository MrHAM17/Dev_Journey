import '../../../core/app_export.dart';/// This class is used in the [switchaccount_item_widget] screen.
class SwitchaccountItemModel {SwitchaccountItemModel({this.andrewAinsley, this.name, this.information, this.andrewAinsley1, this.id, }) { andrewAinsley = andrewAinsley  ?? ImageConstant.imgEllipse30;name = name  ?? "Andrew Ainsley";information = information  ?? "andrew_aisnley";andrewAinsley1 = andrewAinsley1  ?? ImageConstant.imgCategoriesCheck;id = id  ?? ""; }

String? andrewAinsley;

String? name;

String? information;

String? andrewAinsley1;

String? id;

 }
