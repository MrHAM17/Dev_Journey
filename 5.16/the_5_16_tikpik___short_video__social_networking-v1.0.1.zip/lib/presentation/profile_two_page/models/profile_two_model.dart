import '../../../core/app_export.dart';import 'autolayoutvertical6_item_model.dart';class ProfileTwoModel {List<Autolayoutvertical6ItemModel> autolayoutvertical6ItemList = [Autolayoutvertical6ItemModel(k:ImageConstant.imgImage72,k1:ImageConstant.imgOverflowmenuPrimary,k2: "367.5K",k3:ImageConstant.imgImage73,overflowMenu:ImageConstant.imgOverflowMenuPrimary16x16,k4: "837.9K")];

 }
