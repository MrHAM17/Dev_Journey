import '../../../core/app_export.dart';import 'soundused_item_model.dart';class SoundUsedModel {List<SoundusedItemModel> soundusedItemList = [SoundusedItemModel(image:ImageConstant.imgImage200x121),SoundusedItemModel(image:ImageConstant.imgImage200x120),SoundusedItemModel(image:ImageConstant.imgImage1),SoundusedItemModel(image:ImageConstant.imgImage2),SoundusedItemModel(image:ImageConstant.imgImage3),SoundusedItemModel(image:ImageConstant.imgImage4)];

 }
