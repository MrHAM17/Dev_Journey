import '../../../core/app_export.dart';/// This class is used in the [soundused_item_widget] screen.
class SoundusedItemModel {SoundusedItemModel({this.image, this.id, }) { image = image  ?? ImageConstant.imgImage200x121;id = id  ?? ""; }

String? image;

String? id;

 }
