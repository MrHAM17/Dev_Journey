import 'package:the_4_07_comfort___hotel_booking_app/core/app_export.dart';import 'package:the_4_07_comfort___hotel_booking_app/presentation/refund_method_screen/models/refund_method_model.dart';/// A controller class for the RefundMethodScreen.
///
/// This class manages the state of the RefundMethodScreen, including the
/// current refundMethodModelObj
class RefundMethodController extends GetxController {Rx<RefundMethodModel> refundMethodModelObj = RefundMethodModel().obs;

@override void onReady() { // TODO: implement Actions
 } 
 }
