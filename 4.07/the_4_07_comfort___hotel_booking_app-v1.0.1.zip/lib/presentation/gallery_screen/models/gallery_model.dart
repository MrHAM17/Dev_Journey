import '../../../core/app_export.dart';import 'gallery_item_model.dart';/// This class defines the variables used in the [gallery_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class GalleryModel {Rx<List<GalleryItemModel>> galleryItemList = Rx([GalleryItemModel(rectangle:ImageConstant.imgRectangle10.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle11140x182.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle12140x182.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle13.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle14.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle15.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle16.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle10.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle18.obs),GalleryItemModel(rectangle:ImageConstant.imgRectangle19.obs)]);

 }
