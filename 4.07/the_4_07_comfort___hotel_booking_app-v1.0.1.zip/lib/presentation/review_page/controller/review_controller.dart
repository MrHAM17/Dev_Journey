import 'package:the_4_07_comfort___hotel_booking_app/core/app_export.dart';import 'package:the_4_07_comfort___hotel_booking_app/presentation/review_page/models/review_model.dart';/// A controller class for the ReviewPage.
///
/// This class manages the state of the ReviewPage, including the
/// current reviewModelObj
class ReviewController extends GetxController {ReviewController(this.reviewModelObj);

Rx<ReviewModel> reviewModelObj;

 }
