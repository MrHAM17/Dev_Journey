import '../../../core/app_export.dart';/// This class is used in the [review_item_widget] screen.
class ReviewItemModel {ReviewItemModel({this.jennyWilson, this.jennyWilson1, this.dec, this.veryniceandcomfortab, this.id, }) { jennyWilson = jennyWilson  ?? Rx(ImageConstant.imgEllipse1);jennyWilson1 = jennyWilson1  ?? Rx("Jenny Wilson");dec = dec  ?? Rx("Dec 10, 2024");veryniceandcomfortab = veryniceandcomfortab  ?? Rx("Very nice and comfortable hotel, thank you for accompanying my vacation!");id = id  ?? Rx(""); }

Rx<String>? jennyWilson;

Rx<String>? jennyWilson1;

Rx<String>? dec;

Rx<String>? veryniceandcomfortab;

Rx<String>? id;

 }
