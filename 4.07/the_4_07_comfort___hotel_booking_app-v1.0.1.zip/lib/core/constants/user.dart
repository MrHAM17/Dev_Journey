class User {
  static String passwrod = "Abcd1234@@";

  static int role = 1;
}
