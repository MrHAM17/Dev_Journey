package com.housitbuyrentsellproperty.app.modules.editform.`data`.model

class ShapeRowModel()
