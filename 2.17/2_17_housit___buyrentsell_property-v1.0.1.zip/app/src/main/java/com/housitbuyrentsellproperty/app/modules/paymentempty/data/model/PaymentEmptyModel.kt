package com.housitbuyrentsellproperty.app.modules.paymentempty.`data`.model

class PaymentEmptyModel()
