package com.housitbuyrentsellproperty.app.modules.topagentsprofiledetailtabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.housitbuyrentsellproperty.app.modules.topagentsprofiledetailtabcontainer.`data`.model.TopAgentsProfileDetailTabContainerModel
import org.koin.core.KoinComponent

class TopAgentsProfileDetailTabContainerVM : ViewModel(), KoinComponent {
  val topAgentsProfileDetailTabContainerModel:
      MutableLiveData<TopAgentsProfileDetailTabContainerModel> =
      MutableLiveData(TopAgentsProfileDetailTabContainerModel())

  var navArguments: Bundle? = null
}
