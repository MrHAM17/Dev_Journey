package com.housitbuyrentsellproperty.app.modules.notificationlisttabcontainer.`data`.model

class NotificationListTabContainerModel()
