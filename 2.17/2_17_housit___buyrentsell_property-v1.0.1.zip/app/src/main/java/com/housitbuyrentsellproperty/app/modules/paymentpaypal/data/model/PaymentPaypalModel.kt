package com.housitbuyrentsellproperty.app.modules.paymentpaypal.`data`.model

import kotlin.String

data class PaymentPaypalModel(
  /**
   * TODO Replace with dynamic value
   */
  var etLockValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etEmailValue: String? = null
)
