package com.housitbuyrentsellproperty.app.modules.emptymap.`data`.model

class EmptyMapModel()
