package com.housitbuyrentsellproperty.app.modules.homecontainer.`data`.model

class HomeContainerModel()
