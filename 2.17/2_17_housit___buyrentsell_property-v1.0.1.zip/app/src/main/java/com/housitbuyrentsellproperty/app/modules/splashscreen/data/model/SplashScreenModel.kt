package com.housitbuyrentsellproperty.app.modules.splashscreen.`data`.model

class SplashScreenModel()
