package com.housitbuyrentsellproperty.app.modules.viewonmap.`data`.model

class ViewOnMapModel()
