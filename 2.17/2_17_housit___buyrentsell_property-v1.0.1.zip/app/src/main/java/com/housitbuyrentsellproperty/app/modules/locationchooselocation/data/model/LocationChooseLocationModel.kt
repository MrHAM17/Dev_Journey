package com.housitbuyrentsellproperty.app.modules.locationchooselocation.`data`.model

class LocationChooseLocationModel()
