package com.housitbuyrentsellproperty.app.modules.filterchooselocation.`data`.model

class FilterChooseLocationModel()
