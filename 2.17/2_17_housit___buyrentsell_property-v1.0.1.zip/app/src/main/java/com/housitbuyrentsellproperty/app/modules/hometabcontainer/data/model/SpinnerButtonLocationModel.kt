package com.housitbuyrentsellproperty.app.modules.hometabcontainer.`data`.model

import kotlin.String

data class SpinnerButtonLocationModel(
  val itemName: String
)
