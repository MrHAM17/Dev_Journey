package com.safebankmobilebankingapp.app.modules.signuppage.`data`.model

import kotlin.String

data class SpinnerJanModel(
  val itemName: String
)
