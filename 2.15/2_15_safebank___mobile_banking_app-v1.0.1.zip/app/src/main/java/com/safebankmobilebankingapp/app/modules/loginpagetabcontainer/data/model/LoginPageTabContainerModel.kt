package com.safebankmobilebankingapp.app.modules.loginpagetabcontainer.`data`.model

class LoginPageTabContainerModel()
