package com.safebankmobilebankingapp.app.modules.statisticstabcontainer.`data`.model

import kotlin.String

data class SpinnerUSDModel(
  val itemName: String
)
