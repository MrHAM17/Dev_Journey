package com.safebankmobilebankingapp.app.modules.signuppage.`data`.model

import kotlin.String

data class SpinnerUnitedEstateModel(
  val itemName: String
)
