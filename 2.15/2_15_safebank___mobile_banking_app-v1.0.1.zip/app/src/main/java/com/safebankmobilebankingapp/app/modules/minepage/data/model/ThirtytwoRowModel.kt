package com.safebankmobilebankingapp.app.modules.minepage.`data`.model

class ThirtytwoRowModel()
