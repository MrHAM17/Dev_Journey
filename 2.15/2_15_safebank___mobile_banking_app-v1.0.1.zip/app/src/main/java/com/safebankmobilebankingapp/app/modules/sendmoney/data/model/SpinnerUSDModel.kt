package com.safebankmobilebankingapp.app.modules.sendmoney.`data`.model

import kotlin.String

data class SpinnerUSDModel(
  val itemName: String
)
