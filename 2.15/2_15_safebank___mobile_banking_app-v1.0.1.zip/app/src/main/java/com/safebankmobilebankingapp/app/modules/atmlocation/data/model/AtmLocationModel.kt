package com.safebankmobilebankingapp.app.modules.atmlocation.`data`.model

class AtmLocationModel()
