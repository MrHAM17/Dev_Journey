package com.safebankmobilebankingapp.app.modules.currencyexchange.`data`.model

import kotlin.String

data class SpinnerUSDModel(
  val itemName: String
)
