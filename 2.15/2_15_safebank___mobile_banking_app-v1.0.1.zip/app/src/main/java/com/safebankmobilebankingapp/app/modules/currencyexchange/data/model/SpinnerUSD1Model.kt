package com.safebankmobilebankingapp.app.modules.currencyexchange.`data`.model

import kotlin.String

data class SpinnerUSD1Model(
  val itemName: String
)
