package com.safebankmobilebankingapp.app.modules.transfertabcontainer.`data`.model

class TransfertabcontainerRowModel()
