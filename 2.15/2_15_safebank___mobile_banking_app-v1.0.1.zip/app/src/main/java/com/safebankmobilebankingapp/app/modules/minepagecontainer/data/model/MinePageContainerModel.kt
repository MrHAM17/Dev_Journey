package com.safebankmobilebankingapp.app.modules.minepagecontainer.`data`.model

class MinePageContainerModel()
