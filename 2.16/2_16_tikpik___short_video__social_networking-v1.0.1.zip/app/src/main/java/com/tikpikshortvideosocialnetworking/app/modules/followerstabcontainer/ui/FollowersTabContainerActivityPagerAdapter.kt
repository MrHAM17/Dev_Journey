package com.tikpikshortvideosocialnetworking.app.modules.followerstabcontainer.ui

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.di.MyApp
import com.tikpikshortvideosocialnetworking.app.modules.followers.ui.FollowersFragment
import com.tikpikshortvideosocialnetworking.app.modules.suggested.ui.SuggestedFragment
import kotlin.Int
import kotlin.String
import kotlin.collections.List

class FollowersTabContainerActivityPagerAdapter(
    val fragmentManager: FragmentManager,
    val lifecycle: Lifecycle
) : FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int = viewPages.size

    override fun createFragment(position: Int): Fragment = viewPages[position]

    companion object AdapterConstant {
        val title: List<String> =
                listOf(MyApp.getInstance().resources.getString(R.string.lbl_followers),MyApp.getInstance().resources.getString(R.string.lbl_following),MyApp.getInstance().resources.getString(R.string.lbl_suggested))

        val viewPages: List<Fragment> =
                listOf(FollowersFragment(),SuggestedFragment(),SuggestedFragment())

    }
}
