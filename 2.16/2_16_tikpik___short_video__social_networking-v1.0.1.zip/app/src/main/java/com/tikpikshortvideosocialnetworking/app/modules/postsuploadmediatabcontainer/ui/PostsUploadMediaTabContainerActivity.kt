package com.tikpikshortvideosocialnetworking.app.modules.postsuploadmediatabcontainer.ui

import androidx.activity.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.base.BaseActivity
import com.tikpikshortvideosocialnetworking.app.databinding.ActivityPostsUploadMediaTabContainerBinding
import com.tikpikshortvideosocialnetworking.app.modules.postseditpage.ui.PostsEditPageActivity
import com.tikpikshortvideosocialnetworking.app.modules.postsuploadmediatabcontainer.`data`.viewmodel.PostsUploadMediaTabContainerVM
import kotlin.String
import kotlin.Unit

class PostsUploadMediaTabContainerActivity :
    BaseActivity<ActivityPostsUploadMediaTabContainerBinding>(R.layout.activity_posts_upload_media_tab_container)
    {
  private val viewModel: PostsUploadMediaTabContainerVM by
      viewModels<PostsUploadMediaTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.postsUploadMediaTabContainerVM = viewModel
    val adapter =
    PostsUploadMediaTabContainerActivityPagerAdapter(supportFragmentManager,lifecycle)
    binding.viewPagerTabBarView.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTabview,binding.viewPagerTabBarView) { tab, position ->
      tab.text = PostsUploadMediaTabContainerActivityPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
      binding.btnNext.setOnClickListener {
        val destIntent = PostsEditPageActivity.getIntent(this, null)
        startActivity(destIntent)
      }
      binding.imageCategoriesXClose.setOnClickListener {
        finish()
      }
    }

    companion object {
      const val TAG: String = "POSTS_UPLOAD_MEDIA_TAB_CONTAINER_ACTIVITY"

    }
  }
