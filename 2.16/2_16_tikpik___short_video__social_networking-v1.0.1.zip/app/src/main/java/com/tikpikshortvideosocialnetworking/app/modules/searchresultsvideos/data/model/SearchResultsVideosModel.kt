package com.tikpikshortvideosocialnetworking.app.modules.searchresultsvideos.`data`.model

class SearchResultsVideosModel()
