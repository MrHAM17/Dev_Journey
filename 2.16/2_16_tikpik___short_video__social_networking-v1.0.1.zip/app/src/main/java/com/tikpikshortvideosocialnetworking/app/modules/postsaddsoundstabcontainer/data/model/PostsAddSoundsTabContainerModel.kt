package com.tikpikshortvideosocialnetworking.app.modules.postsaddsoundstabcontainer.`data`.model

import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.di.MyApp
import kotlin.String

data class PostsAddSoundsTabContainerModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAllSounds: String? = MyApp.getInstance().resources.getString(R.string.lbl_all_sounds)

)
