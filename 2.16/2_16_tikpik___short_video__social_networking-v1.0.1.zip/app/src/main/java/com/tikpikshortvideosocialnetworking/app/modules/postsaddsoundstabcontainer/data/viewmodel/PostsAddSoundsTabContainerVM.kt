package com.tikpikshortvideosocialnetworking.app.modules.postsaddsoundstabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tikpikshortvideosocialnetworking.app.modules.postsaddsoundstabcontainer.`data`.model.PostsAddSoundsTabContainerModel
import org.koin.core.KoinComponent

class PostsAddSoundsTabContainerVM : ViewModel(), KoinComponent {
  val postsAddSoundsTabContainerModel: MutableLiveData<PostsAddSoundsTabContainerModel> =
      MutableLiveData(PostsAddSoundsTabContainerModel())

  var navArguments: Bundle? = null
}
