package com.tikpikshortvideosocialnetworking.app.modules.searchresultsuserstabcontainer.`data`.model

class SearchResultsUsersTabContainerModel()
