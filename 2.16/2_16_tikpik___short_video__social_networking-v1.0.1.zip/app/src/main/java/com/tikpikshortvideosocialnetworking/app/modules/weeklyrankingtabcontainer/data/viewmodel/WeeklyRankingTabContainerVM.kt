package com.tikpikshortvideosocialnetworking.app.modules.weeklyrankingtabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tikpikshortvideosocialnetworking.app.modules.weeklyrankingtabcontainer.`data`.model.WeeklyRankingTabContainerModel
import org.koin.core.KoinComponent

class WeeklyRankingTabContainerVM : ViewModel(), KoinComponent {
  val weeklyRankingTabContainerModel: MutableLiveData<WeeklyRankingTabContainerModel> =
      MutableLiveData(WeeklyRankingTabContainerModel())

  var navArguments: Bundle? = null
}
