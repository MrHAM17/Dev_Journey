package com.tikpikshortvideosocialnetworking.app.modules.postsuploadmedia.`data`.model

class PostsUploadMediaModel()
