package com.tikpikshortvideosocialnetworking.app.modules.trendingsoundstabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tikpikshortvideosocialnetworking.app.modules.trendingsoundstabcontainer.`data`.model.TrendingSoundsTabContainerModel
import org.koin.core.KoinComponent

class TrendingSoundsTabContainerVM : ViewModel(), KoinComponent {
  val trendingSoundsTabContainerModel: MutableLiveData<TrendingSoundsTabContainerModel> =
      MutableLiveData(TrendingSoundsTabContainerModel())

  var navArguments: Bundle? = null
}
