package com.tikpikshortvideosocialnetworking.app.modules.searchresultssounds.`data`.model

class SearchResultsSoundsModel()
