package com.tikpikshortvideosocialnetworking.app.modules.searchresultsusers.`data`.model

class SearchResultsUsersModel()
