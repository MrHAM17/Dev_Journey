package com.tikpikshortvideosocialnetworking.app.modules.searchresultsuserstabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tikpikshortvideosocialnetworking.app.modules.searchresultsuserstabcontainer.`data`.model.SearchResultsUsersTabContainerModel
import org.koin.core.KoinComponent

class SearchResultsUsersTabContainerVM : ViewModel(), KoinComponent {
  val searchResultsUsersTabContainerModel: MutableLiveData<SearchResultsUsersTabContainerModel> =
      MutableLiveData(SearchResultsUsersTabContainerModel())

  var navArguments: Bundle? = null
}
