package com.tikpikshortvideosocialnetworking.app.modules.allactivity.`data`.model

import kotlin.String

data class SpinnerChooseModel(
  val itemName: String
)
