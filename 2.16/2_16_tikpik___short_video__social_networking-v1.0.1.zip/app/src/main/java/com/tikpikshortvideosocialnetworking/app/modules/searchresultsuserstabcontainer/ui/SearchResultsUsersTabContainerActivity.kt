package com.tikpikshortvideosocialnetworking.app.modules.searchresultsuserstabcontainer.ui

import androidx.activity.viewModels
import androidx.appcompat.widget.SearchView
import com.google.android.material.tabs.TabLayoutMediator
import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.base.BaseActivity
import com.tikpikshortvideosocialnetworking.app.databinding.ActivitySearchResultsUsersTabContainerBinding
import com.tikpikshortvideosocialnetworking.app.modules.searchresultsuserstabcontainer.`data`.viewmodel.SearchResultsUsersTabContainerVM
import kotlin.Boolean
import kotlin.String
import kotlin.Unit

class SearchResultsUsersTabContainerActivity :
    BaseActivity<ActivitySearchResultsUsersTabContainerBinding>(R.layout.activity_search_results_users_tab_container)
    {
  private val viewModel: SearchResultsUsersTabContainerVM by
      viewModels<SearchResultsUsersTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.searchResultsUsersTabContainerVM = viewModel
    val adapter =
    SearchResultsUsersTabContainerActivityPagerAdapter(supportFragmentManager,lifecycle)
    binding.viewPagerTabBarView.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTabview,binding.viewPagerTabBarView) { tab, position ->
      tab.text = SearchResultsUsersTabContainerActivityPagerAdapter.title[position]
      }.attach()
      setUpSearchViewSearchListener()
    }

    override fun setUpClicks(): Unit {
    }

    private fun setUpSearchViewSearchListener(): Unit {
      binding.searchViewSearch.setOnQueryTextListener(object :
      SearchView.OnQueryTextListener {
        override fun onQueryTextSubmit(p0 : String) : Boolean {
          // Performs search when user hit
          // the search button on the keyboard
          return false
        }
        override fun onQueryTextChange(p0 : String) : Boolean {
          // Start filtering the list as user
          // start entering the characters
          return false
        }
        })
      }

      companion object {
        const val TAG: String = "SEARCH_RESULTS_USERS_TAB_CONTAINER_ACTIVITY"

      }
    }
