package com.tikpikshortvideosocialnetworking.app.modules.profile.`data`.model

import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.di.MyApp
import kotlin.String

data class Autolayoutvertical1RowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtK1: String? = MyApp.getInstance().resources.getString(R.string.lbl_367_5k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK2: String? = MyApp.getInstance().resources.getString(R.string.lbl_837_9k)

)
