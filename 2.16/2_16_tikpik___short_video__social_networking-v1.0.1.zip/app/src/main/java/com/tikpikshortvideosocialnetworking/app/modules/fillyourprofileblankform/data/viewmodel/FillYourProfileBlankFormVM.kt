package com.tikpikshortvideosocialnetworking.app.modules.fillyourprofileblankform.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tikpikshortvideosocialnetworking.app.modules.dhi1.`data`.model.Dhi1Model
import com.tikpikshortvideosocialnetworking.app.modules.fillyourprofileblankform.`data`.model.FillYourProfileBlankFormModel
import org.koin.core.KoinComponent

class FillYourProfileBlankFormVM : ViewModel(), KoinComponent {
  val fillYourProfileBlankFormModel: MutableLiveData<FillYourProfileBlankFormModel> =
      MutableLiveData(FillYourProfileBlankFormModel())

  var navArguments: Bundle? = null

  public var includedModel: MutableLiveData<Dhi1Model> = MutableLiveData(Dhi1Model())
}
