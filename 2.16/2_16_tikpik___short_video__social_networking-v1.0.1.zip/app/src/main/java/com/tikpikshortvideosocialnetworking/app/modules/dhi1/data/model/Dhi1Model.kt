package com.tikpikshortvideosocialnetworking.app.modules.dhi1.`data`.model

import kotlin.String

data class Dhi1Model(
  /**
   * TODO Replace with dynamic value
   */
  var etPhoneNumberValue: String? = null
)
