package com.tikpikshortvideosocialnetworking.app.modules.postsaddeffectstabcontainer.ui

import androidx.activity.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.base.BaseActivity
import com.tikpikshortvideosocialnetworking.app.databinding.ActivityPostsAddEffectsTabContainerBinding
import com.tikpikshortvideosocialnetworking.app.modules.postsaddeffectstabcontainer.`data`.viewmodel.PostsAddEffectsTabContainerVM
import kotlin.String
import kotlin.Unit

class PostsAddEffectsTabContainerActivity :
    BaseActivity<ActivityPostsAddEffectsTabContainerBinding>(R.layout.activity_posts_add_effects_tab_container)
    {
  private val viewModel: PostsAddEffectsTabContainerVM by
      viewModels<PostsAddEffectsTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.postsAddEffectsTabContainerVM = viewModel
    val adapter =
    PostsAddEffectsTabContainerActivityPagerAdapter(supportFragmentManager,lifecycle)
    binding.viewPagerTabBarView.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTabview,binding.viewPagerTabBarView) { tab, position ->
      tab.text = PostsAddEffectsTabContainerActivityPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "POSTS_ADD_EFFECTS_TAB_CONTAINER_ACTIVITY"

    }
  }
