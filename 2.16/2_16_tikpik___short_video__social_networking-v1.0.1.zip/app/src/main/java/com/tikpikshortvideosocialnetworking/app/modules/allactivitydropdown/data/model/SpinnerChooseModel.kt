package com.tikpikshortvideosocialnetworking.app.modules.allactivitydropdown.`data`.model

import kotlin.String

data class SpinnerChooseModel(
  val itemName: String
)
