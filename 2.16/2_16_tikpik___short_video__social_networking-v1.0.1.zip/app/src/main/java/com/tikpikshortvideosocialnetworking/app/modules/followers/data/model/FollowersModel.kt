package com.tikpikshortvideosocialnetworking.app.modules.followers.`data`.model

class FollowersModel()
