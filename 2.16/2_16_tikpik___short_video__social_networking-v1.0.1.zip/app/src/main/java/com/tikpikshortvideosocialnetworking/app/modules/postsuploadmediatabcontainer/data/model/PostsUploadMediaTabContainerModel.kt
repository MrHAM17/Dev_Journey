package com.tikpikshortvideosocialnetworking.app.modules.postsuploadmediatabcontainer.`data`.model

import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.di.MyApp
import kotlin.String

data class PostsUploadMediaTabContainerModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAllSounds: String? = MyApp.getInstance().resources.getString(R.string.lbl_all_media)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtYouCanSelectBoth: String? =
      MyApp.getInstance().resources.getString(R.string.msg_you_can_select_both)

)
