package com.tikpikshortvideosocialnetworking.app.modules.postsaddeffects.`data`.model

class PostsaddeffectsRowModel()
