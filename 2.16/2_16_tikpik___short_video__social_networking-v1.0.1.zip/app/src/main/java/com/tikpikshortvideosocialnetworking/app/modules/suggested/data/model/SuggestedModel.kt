package com.tikpikshortvideosocialnetworking.app.modules.suggested.`data`.model

class SuggestedModel()
