package com.tikpikshortvideosocialnetworking.app.modules.postsuploadmedia.`data`.model

class Autolayoutvertical6RowModel()
