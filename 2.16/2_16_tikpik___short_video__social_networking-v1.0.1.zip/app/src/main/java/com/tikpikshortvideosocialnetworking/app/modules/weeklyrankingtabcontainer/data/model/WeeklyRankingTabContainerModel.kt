package com.tikpikshortvideosocialnetworking.app.modules.weeklyrankingtabcontainer.`data`.model

class WeeklyRankingTabContainerModel()
