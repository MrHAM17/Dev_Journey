package com.tikpikshortvideosocialnetworking.app.modules.postsaddeffectstabcontainer.`data`.model

import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.di.MyApp
import kotlin.String

data class PostsAddEffectsTabContainerModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtEffects: String? = MyApp.getInstance().resources.getString(R.string.lbl_effects)

)
