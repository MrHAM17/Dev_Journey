package com.tikpikshortvideosocialnetworking.app.modules.addoption.`data`.model

import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.di.MyApp
import kotlin.String

data class AddOptionModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtHorizontalTab: String? = MyApp.getInstance().resources.getString(R.string.lbl_for_you)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtName: String? = MyApp.getInstance().resources.getString(R.string.lbl_jenny_wilson)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInformation: String? = MyApp.getInstance().resources.getString(R.string.msg_actress_singer)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? = MyApp.getInstance().resources.getString(R.string.msg_hi_everyone_in)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFavoriteGirlBy: String? =
      MyApp.getInstance().resources.getString(R.string.msg_favorite_girl_by)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK: String? = MyApp.getInstance().resources.getString(R.string.lbl_225_9k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK1: String? = MyApp.getInstance().resources.getString(R.string.lbl_24_8k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK2: String? = MyApp.getInstance().resources.getString(R.string.lbl_15_6k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK3: String? = MyApp.getInstance().resources.getString(R.string.lbl_20_7k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHorizontalTab1: String? = MyApp.getInstance().resources.getString(R.string.lbl_following)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHorizontalTab2: String? = MyApp.getInstance().resources.getString(R.string.lbl_friends)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtForYou: String? = MyApp.getInstance().resources.getString(R.string.lbl_for_you)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtName1: String? = MyApp.getInstance().resources.getString(R.string.lbl_jenny_wilson)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInformation1: String? =
      MyApp.getInstance().resources.getString(R.string.msg_actress_singer)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription1: String? =
      MyApp.getInstance().resources.getString(R.string.msg_hi_everyone_in)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFavoriteGirlBy1: String? =
      MyApp.getInstance().resources.getString(R.string.msg_favorite_girl_by)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK4: String? = MyApp.getInstance().resources.getString(R.string.lbl_225_9k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK5: String? = MyApp.getInstance().resources.getString(R.string.lbl_24_8k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK6: String? = MyApp.getInstance().resources.getString(R.string.lbl_15_6k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtK7: String? = MyApp.getInstance().resources.getString(R.string.lbl_20_7k)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPosts: String? = MyApp.getInstance().resources.getString(R.string.lbl_posts)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLive: String? = MyApp.getInstance().resources.getString(R.string.lbl_live)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHome: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDiscover: String? = MyApp.getInstance().resources.getString(R.string.lbl_discover)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInbox: String? = MyApp.getInstance().resources.getString(R.string.lbl_inbox)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etStateInactiveValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etStateInactive1Value: String? = null
)
