package com.tikpikshortvideosocialnetworking.app.modules.risingstars.`data`.model

class RisingStarsModel()
