package com.tikpikshortvideosocialnetworking.app.modules.weeklyranking.`data`.model

class WeeklyRankingModel()
