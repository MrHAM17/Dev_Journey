package com.tikpikshortvideosocialnetworking.app.modules.postsaddsoundstabcontainer.ui

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.tikpikshortvideosocialnetworking.app.R
import com.tikpikshortvideosocialnetworking.app.appcomponents.di.MyApp
import com.tikpikshortvideosocialnetworking.app.modules.postsaddsounds.ui.PostsAddSoundsFragment
import kotlin.Int
import kotlin.String
import kotlin.collections.List

class PostsAddSoundsTabContainerActivityPagerAdapter(
    val fragmentManager: FragmentManager,
    val lifecycle: Lifecycle
) : FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int = viewPages.size

    override fun createFragment(position: Int): Fragment = viewPages[position]

    companion object AdapterConstant {
        val title: List<String> =
                listOf(MyApp.getInstance().resources.getString(R.string.lbl_discover),MyApp.getInstance().resources.getString(R.string.lbl_favorites))

        val viewPages: List<Fragment> = listOf(PostsAddSoundsFragment(),PostsAddSoundsFragment())

    }
}
