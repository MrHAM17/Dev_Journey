package com.tikpikshortvideosocialnetworking.app.modules.soundused.`data`.model

class SoundusedRowModel()
