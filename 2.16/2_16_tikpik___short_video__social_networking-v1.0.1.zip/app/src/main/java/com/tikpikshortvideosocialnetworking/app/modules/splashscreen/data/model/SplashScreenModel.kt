package com.tikpikshortvideosocialnetworking.app.modules.splashscreen.`data`.model

class SplashScreenModel()
