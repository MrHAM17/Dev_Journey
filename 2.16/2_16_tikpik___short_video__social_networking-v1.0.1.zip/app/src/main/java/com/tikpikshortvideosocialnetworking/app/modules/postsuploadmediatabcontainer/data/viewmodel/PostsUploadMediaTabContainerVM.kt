package com.tikpikshortvideosocialnetworking.app.modules.postsuploadmediatabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tikpikshortvideosocialnetworking.app.modules.postsuploadmediatabcontainer.`data`.model.PostsUploadMediaTabContainerModel
import org.koin.core.KoinComponent

class PostsUploadMediaTabContainerVM : ViewModel(), KoinComponent {
  val postsUploadMediaTabContainerModel: MutableLiveData<PostsUploadMediaTabContainerModel> =
      MutableLiveData(PostsUploadMediaTabContainerModel())

  var navArguments: Bundle? = null
}
