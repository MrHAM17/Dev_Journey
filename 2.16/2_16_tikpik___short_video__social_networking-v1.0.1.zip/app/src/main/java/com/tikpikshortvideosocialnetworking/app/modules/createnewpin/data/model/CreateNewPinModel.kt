package com.tikpikshortvideosocialnetworking.app.modules.createnewpin.`data`.model

class CreateNewPinModel()
