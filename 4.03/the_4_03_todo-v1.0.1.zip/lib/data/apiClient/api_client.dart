import 'package:the_4_03_todo/core/app_export.dart';

class ApiClient extends GetConnect {}
