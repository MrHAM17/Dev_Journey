import '../../../core/app_export.dart';
import 'songslist_item_model.dart';

class AlbumDetailsModel {
  List<SongslistItemModel> songslistItemList = [
    SongslistItemModel(
        count: "1", burning: "Burning", podvalCaplella: "Podval Caplella"),
    SongslistItemModel(burning: "Flashbacks", podvalCaplella: "Emika"),
    SongslistItemModel(
        burning: "Renaissance", podvalCaplella: "Podval Caplella"),
    SongslistItemModel(burning: "Ivar’s Revenge", podvalCaplella: "Danheim")
  ];
}
