import '../../../core/app_export.dart';
import 'list_item_model.dart';

class ListModel {
  List<ListItemModel> listItemList = [
    ListItemModel(
        songNumber: "1", burning: "Burning", podvalCaplella: "Podval Caplella"),
    ListItemModel(
        songNumber: "2", burning: "Flashbacks", podvalCaplella: "Emika"),
    ListItemModel(
        songNumber: "3",
        burning: "Renaissance",
        podvalCaplella: "Podval Caplella")
  ];
}
