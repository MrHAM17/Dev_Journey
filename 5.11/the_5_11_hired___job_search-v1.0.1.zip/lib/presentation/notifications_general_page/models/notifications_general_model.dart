import '../../../core/app_export.dart';
import 'notificationsgeneral_item_model.dart';

class NotificationsGeneralModel {
  List<NotificationsgeneralItemModel> notificationsgeneralItemList = [
    NotificationsgeneralItemModel(
        bag: ImageConstant.imgBag,
        juniorUIDesigner: "Junior UI Designer ",
        shopeeSg: "Shopee Sg",
        time: "32 Min ago",
        loremIpsumDolor:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit."),
    NotificationsgeneralItemModel(
        bag: ImageConstant.imgBag,
        juniorUIDesigner: "Senior UI Designer ",
        shopeeSg: "Shopee Sg",
        time: "32 Min ago",
        loremIpsumDolor:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit."),
    NotificationsgeneralItemModel(
        bag: ImageConstant.imgSettingsRed800,
        juniorUIDesigner: "UI UX Designer",
        shopeeSg: "Shell",
        time: "32 Min ago",
        loremIpsumDolor:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit."),
    NotificationsgeneralItemModel(
        bag: ImageConstant.imgClose,
        juniorUIDesigner: "UI Designer ",
        shopeeSg: "Cardano ",
        time: "32 Min ago",
        loremIpsumDolor:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit.")
  ];
}
