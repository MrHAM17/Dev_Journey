import '../../../core/app_export.dart';

/// This class is used in the [fulltime3_item_widget] screen.
class Fulltime3ItemModel {
  Fulltime3ItemModel({
    this.fulltime,
    this.isSelected,
  }) {
    fulltime = fulltime ?? "Fulltime";
    isSelected = isSelected ?? false;
  }

  String? fulltime;

  bool? isSelected;
}
