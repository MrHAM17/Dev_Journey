import '../../../core/app_export.dart';

/// This class is used in the [fulltime7_item_widget] screen.
class Fulltime7ItemModel {
  Fulltime7ItemModel({
    this.fulltime,
    this.isSelected,
  }) {
    fulltime = fulltime ?? "Fulltime";
    isSelected = isSelected ?? false;
  }

  String? fulltime;

  bool? isSelected;
}
