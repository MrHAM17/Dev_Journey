import '../../../core/app_export.dart';
import 'messageaction_item_model.dart';

class MessageActionModel {
  List<MessageactionItemModel> messageactionItemList = [
    MessageactionItemModel(
        estherHoward: ImageConstant.imgImage56x56,
        estherHoward1: "Esther Howard",
        loremIpsumDolor: "Lorem ipsum dolor sit amet...",
        time: "10:20",
        widget: "2"),
    MessageactionItemModel(
        estherHoward1: "Wade Warren",
        loremIpsumDolor: "Lorem ipsum dolor sit amet...",
        time: "10:20",
        widget: "2"),
    MessageactionItemModel(
        estherHoward1: "Robert Fox",
        loremIpsumDolor: "Lorem ipsum dolor sit amet...")
  ];
}
