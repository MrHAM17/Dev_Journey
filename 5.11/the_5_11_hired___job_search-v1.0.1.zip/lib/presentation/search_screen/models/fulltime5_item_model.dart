import '../../../core/app_export.dart';

/// This class is used in the [fulltime5_item_widget] screen.
class Fulltime5ItemModel {
  Fulltime5ItemModel({
    this.fulltime,
    this.isSelected,
  }) {
    fulltime = fulltime ?? "Fulltime";
    isSelected = isSelected ?? false;
  }

  String? fulltime;

  bool? isSelected;
}
