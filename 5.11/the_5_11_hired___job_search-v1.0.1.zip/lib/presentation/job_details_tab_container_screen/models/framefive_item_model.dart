import '../../../core/app_export.dart';

/// This class is used in the [framefive_item_widget] screen.
class FramefiveItemModel {
  FramefiveItemModel({
    this.fulltime,
    this.isSelected,
  }) {
    fulltime = fulltime ?? "Fulltime";
    isSelected = isSelected ?? false;
  }

  String? fulltime;

  bool? isSelected;
}
