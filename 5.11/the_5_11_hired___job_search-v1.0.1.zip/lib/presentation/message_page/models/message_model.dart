import '../../../core/app_export.dart';
import 'message_item_model.dart';

class MessageModel {
  List<MessageItemModel> messageItemList = [
    MessageItemModel(
        circleImage: ImageConstant.imgAvatar56x56,
        chanceSeptimus: "Chance Septimus",
        loremIpsumDolor: "Lorem ipsum dolor sit amet...",
        time: "10:20"),
    MessageItemModel(
        circleImage: ImageConstant.imgAvatar1,
        chanceSeptimus: "Robert Fox",
        loremIpsumDolor: "Lorem ipsum dolor sit amet...",
        time: "10:20")
  ];
}
