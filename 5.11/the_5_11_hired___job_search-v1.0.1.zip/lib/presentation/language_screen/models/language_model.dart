import '../../../core/app_export.dart';
import 'englishuk_item_model.dart';
import 'chineses_item_model.dart';

class LanguageModel {
  List<EnglishukItemModel> englishukItemList = [
    EnglishukItemModel(
        englishUK: "English (UK)",
        englishUK1: ImageConstant.imgCheckmarkGreenA700)
  ];

  List<ChinesesItemModel> chinesesItemList = [
    ChinesesItemModel(chineses: "Chineses"),
    ChinesesItemModel(chineses: "Croatian"),
    ChinesesItemModel(chineses: "Czech"),
    ChinesesItemModel(chineses: "Danish"),
    ChinesesItemModel(chineses: "Filipino"),
    ChinesesItemModel(chineses: "Finland")
  ];
}
