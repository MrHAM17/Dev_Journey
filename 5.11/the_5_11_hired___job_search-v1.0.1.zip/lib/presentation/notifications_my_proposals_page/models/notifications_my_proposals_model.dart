import '../../../core/app_export.dart';
import 'notificationsmyproposals_item_model.dart';

class NotificationsMyProposalsModel {
  List<NotificationsmyproposalsItemModel> notificationsmyproposalsItemList = [
    NotificationsmyproposalsItemModel(
        iconButton: ImageConstant.imgGroupRed800,
        seniorUIUXDesigner: "Senior UI/UX Designer",
        smallLabelRegular: "Shell"),
    NotificationsmyproposalsItemModel(
        iconButton: ImageConstant.imgGroup,
        seniorUIUXDesigner: "Senior UI/UX Designer",
        smallLabelRegular: "Cardano "),
    NotificationsmyproposalsItemModel(
        iconButton: ImageConstant.imgLogo,
        seniorUIUXDesigner: "Senior UI/UX Designer",
        smallLabelRegular: "Shopee Sg")
  ];
}
