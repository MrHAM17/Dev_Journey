import '../../../core/app_export.dart';
import 'jobtype_item_model.dart';

class JobTypeModel {
  List<JobtypeItemModel> jobtypeItemList = [
    JobtypeItemModel(
        work: ImageConstant.imgWork,
        findAJob: "Find a job",
        itSEasyToFind: "It’s easy to find your dream jobs here with us."),
    JobtypeItemModel(
        work: ImageConstant.imgProfileOrange500,
        findAJob: "Find a employee",
        itSEasyToFind: "It’s easy to find eployees here with us.")
  ];
}
