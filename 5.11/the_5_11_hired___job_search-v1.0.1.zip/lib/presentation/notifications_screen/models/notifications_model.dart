import '../../../core/app_export.dart';
import 'notifications_item_model.dart';

class NotificationsModel {
  List<NotificationsItemModel> notificationsItemList = [
    NotificationsItemModel(newPost: "New Post"),
    NotificationsItemModel(newPost: "Interview Invited"),
    NotificationsItemModel(newPost: "Message"),
    NotificationsItemModel(newPost: "New Post Job")
  ];
}
