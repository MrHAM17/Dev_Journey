import '../../../core/app_export.dart';

class SelectACountryModel {
  List<String> radioList = [
    "lbl_afghanistan",
    "lbl_albania",
    "lbl_algeria",
    "lbl_andorra",
    "lbl_angola",
    "msg_antigua_and_barbuda",
    "lbl_argentina",
    "lbl_argentina",
    "lbl_armenia",
    "lbl_australia",
    "lbl_austria",
    "lbl_azerbaijan",
    "lbl_azerbaijan"
  ];
}
