import '../../../core/app_export.dart';

/// This class is used in the [unsplashvfrcrteqkleight_item_widget] screen.
class UnsplashvfrcrteqkleightItemModel {
  UnsplashvfrcrteqkleightItemModel({this.id}) {
    id = id ?? "";
  }

  String? id;
}
