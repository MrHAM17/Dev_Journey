import '../../../core/app_export.dart';/// This class is used in the [layout26_item_widget] screen.
class Layout26ItemModel {Layout26ItemModel({this.kurtMullins, this.kurtMullins1, this.description, this.time, this.id, }) { kurtMullins = kurtMullins  ?? ImageConstant.imgShape56;kurtMullins1 = kurtMullins1  ?? "Kurt Mullins";description = description  ?? "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ";time = time  ?? "10 mins ago";id = id  ?? ""; }

String? kurtMullins;

String? kurtMullins1;

String? description;

String? time;

String? id;

 }
