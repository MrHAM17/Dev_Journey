import '../../../core/app_export.dart';/// This class is used in the [layout28_item_widget] screen.
class Layout28ItemModel {Layout28ItemModel({this.bali, this.bali1, this.id, }) { bali = bali  ?? ImageConstant.imgShape40x40;bali1 = bali1  ?? "Bali";id = id  ?? ""; }

String? bali;

String? bali1;

String? id;

 }
