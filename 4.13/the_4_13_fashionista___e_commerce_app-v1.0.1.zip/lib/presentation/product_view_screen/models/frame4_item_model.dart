import '../../../core/app_export.dart';

/// This class is used in the [frame4_item_widget] screen.
class Frame4ItemModel {
  Rx<String>? tabs = Rx("S");

  Rx<bool>? isSelected = Rx(false);
}
