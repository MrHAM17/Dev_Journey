import 'package:the_4_13_fashionista___e_commerce_app/core/app_export.dart';

class ApiClient extends GetConnect {}
