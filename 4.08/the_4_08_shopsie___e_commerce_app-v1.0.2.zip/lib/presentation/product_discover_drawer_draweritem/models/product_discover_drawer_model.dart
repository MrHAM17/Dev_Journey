/// This class defines the variables used in the [product_discover_drawer_draweritem],
/// and is typically used to hold data that is passed between different parts of the application.
class ProductDiscoverDrawerModel {}
