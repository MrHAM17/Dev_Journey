import 'package:the_4_08_shopsie___e_commerce_app/core/app_export.dart';

class ApiClient extends GetConnect {}
