package com.todo.app.constants

import kotlin.Int

public object role {
    public val USER: Int = 1
}
