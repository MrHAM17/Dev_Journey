package com.todo.app.modules.adacana.`data`.model

class AdacanaModel()
