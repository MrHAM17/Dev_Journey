import '../../../core/app_export.dart';import 'cardadded_item_model.dart';class CardAddedModel {List<CardaddedItemModel> cardaddedItemList = [CardaddedItemModel(paypal:ImageConstant.imgFrameLightBlue600,paypal1: "Paypal"),CardaddedItemModel(paypal:ImageConstant.imgFrame,paypal1: "Google Pay"),CardaddedItemModel(paypal:ImageConstant.imgFrameWhiteA70032x32,paypal1: "Apple Pay")];

 }
