import '../../../core/app_export.dart';import 'tickets1_item_model.dart';class BookingOngoingModel {List<Tickets1ItemModel> tickets1ItemList = [Tickets1ItemModel(royalePresident: "Royale President Hotel",image:ImageConstant.imgRectangle,parisFrance: "Paris, France")];

 }
