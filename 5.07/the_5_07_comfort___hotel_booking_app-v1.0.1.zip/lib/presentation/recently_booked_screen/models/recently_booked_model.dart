import '../../../core/app_export.dart';import 'recentlybooked_item_model.dart';class RecentlyBookedModel {List<RecentlybookedItemModel> recentlybookedItemList = [RecentlybookedItemModel(martinezCannes:ImageConstant.imgRectangle4,presidentHotel: "Martinez Cannes",parisFrance: "Paris, France",fortyEight: "4.8",reviews: "(4,378 reviews)",price: "32",night: "/ night")];

 }
