import '../../../core/app_export.dart';import 'tickets_item_model.dart';class BookingCompletedModel {List<TicketsItemModel> ticketsItemList = [TicketsItemModel(bulgariResort:ImageConstant.imgRectangle,bulgariResort1: "Bulgari Resort",parisFrance: "Paris, France",yeayyouhavecompletedit: "Yeay, you have completed it!"),TicketsItemModel(bulgariResort:ImageConstant.imgRectangle100x100,bulgariResort1: "Hotel Martinez Cannes",parisFrance: "Amsterdam, Netherlands",yeayyouhavecompletedit: "Yeay, you have completed it!")];

 }
