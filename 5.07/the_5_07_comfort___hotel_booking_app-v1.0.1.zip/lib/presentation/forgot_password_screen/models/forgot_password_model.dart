import '../../../core/app_export.dart';import 'forgotpassword_item_model.dart';class ForgotPasswordModel {List<ForgotpasswordItemModel> forgotpasswordItemList = [ForgotpasswordItemModel(viaSMS:ImageConstant.imgUser,viaSMS1: "via SMS:",oneHundredElevenThousandOneHun: "+1 111 ******99"),ForgotpasswordItemModel(viaSMS:ImageConstant.imgCheckmarkPrimary,viaSMS1: "via Email:",oneHundredElevenThousandOneHun: "user@domain.com")];

 }
