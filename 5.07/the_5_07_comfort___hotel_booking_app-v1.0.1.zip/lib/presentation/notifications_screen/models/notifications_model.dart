import '../../../core/app_export.dart';import 'notifications_item_model.dart';class NotificationsModel {List<NotificationsItemModel> notificationsItemList = [NotificationsItemModel(youHaveCanceled: "You have canceled your hotel booking",image:ImageConstant.imgGroupWhiteA700,hotelBookingCanceled: "Hotel Booking Canceled"),NotificationsItemModel(hotelBookingCanceled: "Laluna Hotel booking was successful!")];

 }
