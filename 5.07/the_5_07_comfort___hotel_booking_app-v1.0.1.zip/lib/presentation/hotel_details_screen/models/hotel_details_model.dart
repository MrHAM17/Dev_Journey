import '../../../core/app_export.dart';import 'photos_item_model.dart';import 'framenineteen_item_model.dart';import 'package:the_5_07_comfort___hotel_booking_app/data/models/selectionPopupModel/selection_popup_model.dart';class HotelDetailsModel {List<PhotosItemModel> photosItemList = [PhotosItemModel(rectangle:ImageConstant.imgRectangle7),PhotosItemModel(rectangle:ImageConstant.imgRectangle8),PhotosItemModel(rectangle:ImageConstant.imgRectangle9)];

List<FramenineteenItemModel> framenineteenItemList = [FramenineteenItemModel(jennyWilson:ImageConstant.imgEllipse1,jennyWilson1: "Jenny Wilson",dec: "Dec 10, 2024",veryniceandcomfortab: "Very nice and comfortable hotel, thank you for accompanying my vacation!"),FramenineteenItemModel(jennyWilson:ImageConstant.imgEllipse148x48,jennyWilson1: "Guy Hawkins",dec: "Dec 10, 2024",veryniceandcomfortab: "Very beautiful hotel, my family and I are very satisfied with the service!"),FramenineteenItemModel(jennyWilson:ImageConstant.imgEllipse11,jennyWilson1: "Kristin Watson",dec: "Dec 10, 2024",veryniceandcomfortab: "The rooms are very comfortable and the natural views are amazing, can't wait to come back again!")];

List<SelectionPopupModel> dropdownItemList = [SelectionPopupModel(id:1,title:"Item One",isSelected:true,),SelectionPopupModel(id:2,title:"Item Two",),SelectionPopupModel(id:3,title:"Item Three",)];

 }
