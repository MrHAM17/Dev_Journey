import '../../../core/app_export.dart';import 'tickets2_item_model.dart';class BookingCancelledModel {List<Tickets2ItemModel> tickets2ItemList = [Tickets2ItemModel(palmsCasinoResort:ImageConstant.imgRectangle,palmsCasinoResort1: "Palms Casino Resort",londonUnitedKingdom: "London, United Kingdom",youCanceledThis: "You canceled this hotel booking"),Tickets2ItemModel(palmsCasinoResort:ImageConstant.imgRectangle100x100,palmsCasinoResort1: "The Mark Hotel",londonUnitedKingdom: "Luxemburg, Germany",youCanceledThis: "You canceled this hotel booking")];

 }
