import '../../../core/app_export.dart';import 'choosepaymentmethod_item_model.dart';class ChoosePaymentMethodModel {List<ChoosepaymentmethodItemModel> choosepaymentmethodItemList = [ChoosepaymentmethodItemModel(paypal:ImageConstant.imgFrameLightBlue600,paypal1: "Paypal"),ChoosepaymentmethodItemModel(paypal:ImageConstant.imgFrame,paypal1: "Google Pay"),ChoosepaymentmethodItemModel(paypal:ImageConstant.imgFrameWhiteA70032x32,paypal1: "Apple Pay")];

 }
