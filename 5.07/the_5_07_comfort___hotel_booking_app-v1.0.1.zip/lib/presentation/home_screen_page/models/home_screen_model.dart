import '../../../core/app_export.dart';import 'hotels_item_model.dart';import 'sixty_item_model.dart';class HomeScreenModel {List<HotelsItemModel> hotelsItemList = [HotelsItemModel(image:ImageConstant.imgRectangle3,emeraldaDeHotel: "Emeralda De Hotel",parisFrance: "Paris, France",price: "29",perNight: "/ per night"),HotelsItemModel(image:ImageConstant.imgRectangle3400x300,emeraldaDeHotel: "Emeralda De Hotel",parisFrance: "Paris, France",price: "29",perNight: "/ per night")];

List<SixtyItemModel> sixtyItemList = [SixtyItemModel(martinezCannes:ImageConstant.imgRectangle4,presidentHotel: "Martinez Cannes",parisFrance: "Paris, France",fortyEight: "4.8",reviews: "(4,378 reviews)",price: "32",night: "/ night"),SixtyItemModel(martinezCannes:ImageConstant.imgRectangle41,presidentHotel: "Palazzo Versace",parisFrance: "Paris, France",fortyEight: "4.8",reviews: "(4,378 reviews)",price: "36",night: "/ night")];

 }
