import 'package:the_4_04_health_care/core/app_export.dart';

class ApiClient extends GetConnect {}
