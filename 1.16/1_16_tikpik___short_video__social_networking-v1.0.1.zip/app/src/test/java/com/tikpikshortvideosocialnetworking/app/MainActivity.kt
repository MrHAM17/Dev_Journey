package com.tikpikshortvideosocialnetworking.app

import com.tikpikshortvideosocialnetworking.app.appcomponents.base.BaseActivity
import com.tikpikshortvideosocialnetworking.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}