import '../../../core/app_export.dart';

/// This class is used in the [frametwentyfour_item_widget] screen.
class FrametwentyfourItemModel {
  Rx<String>? covidNineteen = Rx("Covid-19");

  Rx<bool>? isSelected = Rx(false);
}
