import 'package:the_4_06_helthio___telehealth/core/app_export.dart';

class ApiClient extends GetConnect {}
