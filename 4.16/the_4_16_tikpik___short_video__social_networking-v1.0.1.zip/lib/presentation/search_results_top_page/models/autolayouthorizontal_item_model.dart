import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal_item_widget] screen.
class AutolayouthorizontalItemModel {AutolayouthorizontalItemModel({this.k, this.k1, this.k2, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage5);k1 = k1  ?? Rx(ImageConstant.imgOverflowmenuPrimary);k2 = k2  ?? Rx("367.5K");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? k1;

Rx<String>? k2;

Rx<String>? id;

 }
