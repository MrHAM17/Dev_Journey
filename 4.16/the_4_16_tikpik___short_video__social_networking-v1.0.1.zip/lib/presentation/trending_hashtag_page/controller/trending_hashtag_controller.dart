import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/trending_hashtag_page/models/trending_hashtag_model.dart';/// A controller class for the TrendingHashtagPage.
///
/// This class manages the state of the TrendingHashtagPage, including the
/// current trendingHashtagModelObj
class TrendingHashtagController extends GetxController {TrendingHashtagController(this.trendingHashtagModelObj);

Rx<TrendingHashtagModel> trendingHashtagModelObj;

 }
