import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal3_item_widget] screen.
class Autolayouthorizontal3ItemModel {Autolayouthorizontal3ItemModel({this.k, this.overflowMenu, this.k1, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage31);overflowMenu = overflowMenu  ?? Rx(ImageConstant.imgOverflowMenuPrimary16x16);k1 = k1  ?? Rx("728.5K");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? overflowMenu;

Rx<String>? k1;

Rx<String>? id;

 }
