import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/posts_edit_page_screen/models/posts_edit_page_model.dart';/// A controller class for the PostsEditPageScreen.
///
/// This class manages the state of the PostsEditPageScreen, including the
/// current postsEditPageModelObj
class PostsEditPageController extends GetxController {Rx<PostsEditPageModel> postsEditPageModelObj = PostsEditPageModel().obs;

 }
