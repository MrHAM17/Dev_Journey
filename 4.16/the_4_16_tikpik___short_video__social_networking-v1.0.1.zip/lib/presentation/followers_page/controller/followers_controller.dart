import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/followers_page/models/followers_model.dart';/// A controller class for the FollowersPage.
///
/// This class manages the state of the FollowersPage, including the
/// current followersModelObj
class FollowersController extends GetxController {FollowersController(this.followersModelObj);

Rx<FollowersModel> followersModelObj;

 }
