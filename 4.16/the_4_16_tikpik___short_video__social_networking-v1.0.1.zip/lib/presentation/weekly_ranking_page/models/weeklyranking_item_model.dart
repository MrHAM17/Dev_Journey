import '../../../core/app_export.dart';/// This class is used in the [weeklyranking_item_widget] screen.
class WeeklyrankingItemModel {WeeklyrankingItemModel({this.tynishaObey, this.distance, this.id, }) { tynishaObey = tynishaObey  ?? Rx("Tynisha Obey");distance = distance  ?? Rx("26.37M");id = id  ?? Rx(""); }

Rx<String>? tynishaObey;

Rx<String>? distance;

Rx<String>? id;

 }
