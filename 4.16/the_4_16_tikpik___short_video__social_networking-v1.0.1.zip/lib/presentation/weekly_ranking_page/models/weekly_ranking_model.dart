import '../../../core/app_export.dart';import 'weeklyranking_item_model.dart';/// This class defines the variables used in the [weekly_ranking_page],
/// and is typically used to hold data that is passed between different parts of the application.
class WeeklyRankingModel {Rx<List<WeeklyrankingItemModel>> weeklyrankingItemList = Rx([WeeklyrankingItemModel(tynishaObey: "Tynisha Obey".obs,distance: "26.37M".obs)]);

 }
