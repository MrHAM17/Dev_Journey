import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical4_item_widget] screen.
class Autolayoutvertical4ItemModel {Autolayoutvertical4ItemModel({this.k, this.overflowMenu, this.k1, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage34);overflowMenu = overflowMenu  ?? Rx(ImageConstant.imgOverflowMenuPrimary16x16);k1 = k1  ?? Rx("837.5K");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? overflowMenu;

Rx<String>? k1;

Rx<String>? id;

 }
