import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/trending_hashtag_details_screen/models/trending_hashtag_details_model.dart';/// A controller class for the TrendingHashtagDetailsScreen.
///
/// This class manages the state of the TrendingHashtagDetailsScreen, including the
/// current trendingHashtagDetailsModelObj
class TrendingHashtagDetailsController extends GetxController {Rx<TrendingHashtagDetailsModel> trendingHashtagDetailsModelObj = TrendingHashtagDetailsModel().obs;

 }
