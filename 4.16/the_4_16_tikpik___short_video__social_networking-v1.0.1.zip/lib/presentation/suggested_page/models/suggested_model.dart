import '../../../core/app_export.dart';import 'suggested_item_model.dart';/// This class defines the variables used in the [suggested_page],
/// and is typically used to hold data that is passed between different parts of the application.
class SuggestedModel {Rx<List<SuggestedItemModel>> suggestedItemList = Rx([SuggestedItemModel(rayfordChenail:ImageConstant.imgEllipse3.obs,rayfordChenail1: "Rayford Chenail".obs,price: "rayfordchenail | 42.9K".obs)]);

 }
