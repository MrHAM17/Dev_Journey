import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/posts_quick_photo_screen/models/posts_quick_photo_model.dart';/// A controller class for the PostsQuickPhotoScreen.
///
/// This class manages the state of the PostsQuickPhotoScreen, including the
/// current postsQuickPhotoModelObj
class PostsQuickPhotoController extends GetxController {Rx<PostsQuickPhotoModel> postsQuickPhotoModelObj = PostsQuickPhotoModel().obs;

 }
