import '../../../core/app_export.dart';/// This class is used in the [seelive_item_widget] screen.
class SeeliveItemModel {SeeliveItemModel({this.darylNehls, this.woohoooo, this.id, }) { darylNehls = darylNehls  ?? Rx("Daryl Nehls");woohoooo = woohoooo  ?? Rx("woohoooo");id = id  ?? Rx(""); }

Rx<String>? darylNehls;

Rx<String>? woohoooo;

Rx<String>? id;

 }
