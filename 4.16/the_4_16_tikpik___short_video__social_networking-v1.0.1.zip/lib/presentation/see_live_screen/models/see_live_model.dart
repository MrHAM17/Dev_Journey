import '../../../core/app_export.dart';import 'seelive_item_model.dart';/// This class defines the variables used in the [see_live_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SeeLiveModel {Rx<List<SeeliveItemModel>> seeliveItemList = Rx([SeeliveItemModel(darylNehls: "Daryl Nehls".obs,woohoooo: "woohoooo".obs),SeeliveItemModel(darylNehls: "Alfonzo Schuessler".obs,woohoooo: "How are you?".obs),SeeliveItemModel(darylNehls: "Tynisha Obey".obs,woohoooo: "I'd like if we could elaborate more on this.".obs),SeeliveItemModel(darylNehls: "Kylee Danford".obs,woohoooo: "Wow, this is really epic".obs),SeeliveItemModel(darylNehls: "Benny Spanbauer".obs,woohoooo: "Haha that's terrifying 😂".obs),SeeliveItemModel(woohoooo: "Augustina Midgett".obs)]);

 }
