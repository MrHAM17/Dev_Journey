import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/see_live_screen/models/see_live_model.dart';/// A controller class for the SeeLiveScreen.
///
/// This class manages the state of the SeeLiveScreen, including the
/// current seeLiveModelObj
class SeeLiveController extends GetxController {Rx<SeeLiveModel> seeLiveModelObj = SeeLiveModel().obs;

 }
