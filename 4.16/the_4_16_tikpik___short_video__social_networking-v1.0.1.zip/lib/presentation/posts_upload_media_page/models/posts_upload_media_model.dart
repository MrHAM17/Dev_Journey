import '../../../core/app_export.dart';import 'autolayoutvertical5_item_model.dart';/// This class defines the variables used in the [posts_upload_media_page],
/// and is typically used to hold data that is passed between different parts of the application.
class PostsUploadMediaModel {Rx<List<Autolayoutvertical5ItemModel>> autolayoutvertical5ItemList = Rx([Autolayoutvertical5ItemModel(image:ImageConstant.imgImage121x121.obs,checkmark:ImageConstant.imgCheckmarkPrimary.obs),Autolayoutvertical5ItemModel(image:ImageConstant.imgImage121x120.obs,checkmark:ImageConstant.imgContrastPrimary20x20.obs),Autolayoutvertical5ItemModel(image:ImageConstant.imgImage57.obs)]);

 }
