import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/call_screen/models/call_model.dart';/// A controller class for the CallScreen.
///
/// This class manages the state of the CallScreen, including the
/// current callModelObj
class CallController extends GetxController {Rx<CallModel> callModelObj = CallModel().obs;

 }
