import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical6_item_widget] screen.
class Autolayoutvertical6ItemModel {Autolayoutvertical6ItemModel({this.k, this.k1, this.k2, this.k3, this.overflowMenu, this.k4, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage72);k1 = k1  ?? Rx(ImageConstant.imgOverflowmenuPrimary);k2 = k2  ?? Rx("367.5K");k3 = k3  ?? Rx(ImageConstant.imgImage73);overflowMenu = overflowMenu  ?? Rx(ImageConstant.imgOverflowMenuPrimary16x16);k4 = k4  ?? Rx("837.9K");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? k1;

Rx<String>? k2;

Rx<String>? k3;

Rx<String>? overflowMenu;

Rx<String>? k4;

Rx<String>? id;

 }
