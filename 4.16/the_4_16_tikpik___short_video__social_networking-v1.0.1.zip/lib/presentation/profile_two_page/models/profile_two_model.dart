import '../../../core/app_export.dart';import 'autolayoutvertical6_item_model.dart';/// This class defines the variables used in the [profile_two_page],
/// and is typically used to hold data that is passed between different parts of the application.
class ProfileTwoModel {Rx<List<Autolayoutvertical6ItemModel>> autolayoutvertical6ItemList = Rx([Autolayoutvertical6ItemModel(k:ImageConstant.imgImage72.obs,k1:ImageConstant.imgOverflowmenuPrimary.obs,k2: "367.5K".obs,k3:ImageConstant.imgImage73.obs,overflowMenu:ImageConstant.imgOverflowMenuPrimary16x16.obs,k4: "837.9K".obs)]);

 }
