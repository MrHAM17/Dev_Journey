import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/set_your_fingerprint_screen/models/set_your_fingerprint_model.dart';/// A controller class for the SetYourFingerprintScreen.
///
/// This class manages the state of the SetYourFingerprintScreen, including the
/// current setYourFingerprintModelObj
class SetYourFingerprintController extends GetxController {Rx<SetYourFingerprintModel> setYourFingerprintModelObj = SetYourFingerprintModel().obs;

 }
