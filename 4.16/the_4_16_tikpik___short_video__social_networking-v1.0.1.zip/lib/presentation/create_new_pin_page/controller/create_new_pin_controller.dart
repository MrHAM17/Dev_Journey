import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/create_new_pin_page/models/create_new_pin_model.dart';/// A controller class for the CreateNewPinPage.
///
/// This class manages the state of the CreateNewPinPage, including the
/// current createNewPinModelObj
class CreateNewPinController extends GetxController {CreateNewPinController(this.createNewPinModelObj);

Rx<CreateNewPinModel> createNewPinModelObj;

 }
