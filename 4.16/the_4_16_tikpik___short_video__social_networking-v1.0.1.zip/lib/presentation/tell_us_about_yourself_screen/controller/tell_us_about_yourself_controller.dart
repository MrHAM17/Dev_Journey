import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/tell_us_about_yourself_screen/models/tell_us_about_yourself_model.dart';/// A controller class for the TellUsAboutYourselfScreen.
///
/// This class manages the state of the TellUsAboutYourselfScreen, including the
/// current tellUsAboutYourselfModelObj
class TellUsAboutYourselfController extends GetxController {Rx<TellUsAboutYourselfModel> tellUsAboutYourselfModelObj = TellUsAboutYourselfModel().obs;

 }
