import '../../../core/app_export.dart';import 'viewers_item_model.dart';/// This class defines the variables used in the [viewers_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class ViewersModel {Rx<List<ViewersItemModel>> viewersItemList = Rx([ViewersItemModel(darylNehls: "Daryl Nehls".obs),ViewersItemModel(darylNehls: "Daryl Nehls".obs)]);

 }
