import '../../../core/app_export.dart';import 'golivetogether_item_model.dart';/// This class defines the variables used in the [go_live_together_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class GoLiveTogetherModel {Rx<List<GolivetogetherItemModel>> golivetogetherItemList = Rx([GolivetogetherItemModel(chantalShelburne:ImageConstant.imgEllipse12.obs,chantalShelburne1: "Chantal Shelburne".obs,time: "9 min ago".obs),GolivetogetherItemModel(chantalShelburne:ImageConstant.imgEllipse14.obs,chantalShelburne1: "Krishna Barbe".obs,time: "12 min ago".obs),GolivetogetherItemModel(chantalShelburne:ImageConstant.imgEllipse7.obs,chantalShelburne1: "Sanjuanita Ordonez".obs,time: "14 min ago".obs)]);

 }
