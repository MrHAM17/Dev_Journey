import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/go_live_together_bottomsheet/models/go_live_together_model.dart';/// A controller class for the GoLiveTogetherBottomsheet.
///
/// This class manages the state of the GoLiveTogetherBottomsheet, including the
/// current goLiveTogetherModelObj
class GoLiveTogetherController extends GetxController {Rx<GoLiveTogetherModel> goLiveTogetherModelObj = GoLiveTogetherModel().obs;

 }
