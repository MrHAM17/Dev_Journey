import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/rising_stars_page/models/rising_stars_model.dart';/// A controller class for the RisingStarsPage.
///
/// This class manages the state of the RisingStarsPage, including the
/// current risingStarsModelObj
class RisingStarsController extends GetxController {RisingStarsController(this.risingStarsModelObj);

Rx<RisingStarsModel> risingStarsModelObj;

 }
