import '../../../core/app_export.dart';/// This class is used in the [switchaccount_item_widget] screen.
class SwitchaccountItemModel {SwitchaccountItemModel({this.andrewAinsley, this.name, this.information, this.andrewAinsley1, this.id, }) { andrewAinsley = andrewAinsley  ?? Rx(ImageConstant.imgEllipse30);name = name  ?? Rx("Andrew Ainsley");information = information  ?? Rx("andrew_aisnley");andrewAinsley1 = andrewAinsley1  ?? Rx(ImageConstant.imgCategoriesCheck);id = id  ?? Rx(""); }

Rx<String>? andrewAinsley;

Rx<String>? name;

Rx<String>? information;

Rx<String>? andrewAinsley1;

Rx<String>? id;

 }
