import '../../../core/app_export.dart';import 'switchaccount_item_model.dart';/// This class defines the variables used in the [switch_account_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class SwitchAccountModel {Rx<List<SwitchaccountItemModel>> switchaccountItemList = Rx([SwitchaccountItemModel(andrewAinsley:ImageConstant.imgEllipse30.obs,name: "Andrew Ainsley".obs,information: "andrew_aisnley".obs,andrewAinsley1:ImageConstant.imgCategoriesCheck.obs)]);

 }
