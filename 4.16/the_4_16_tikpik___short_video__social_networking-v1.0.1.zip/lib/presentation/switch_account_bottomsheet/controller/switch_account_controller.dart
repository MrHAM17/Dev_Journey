import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/switch_account_bottomsheet/models/switch_account_model.dart';/// A controller class for the SwitchAccountBottomsheet.
///
/// This class manages the state of the SwitchAccountBottomsheet, including the
/// current switchAccountModelObj
class SwitchAccountController extends GetxController {Rx<SwitchAccountModel> switchAccountModelObj = SwitchAccountModel().obs;

 }
