import '../../../core/app_export.dart';import 'autolayoutvertical_item_model.dart';/// This class defines the variables used in the [profile_page],
/// and is typically used to hold data that is passed between different parts of the application.
class ProfileModel {Rx<List<AutolayoutverticalItemModel>> autolayoutverticalItemList = Rx([AutolayoutverticalItemModel(k:ImageConstant.imgImage5.obs,k1:ImageConstant.imgOverflowmenuPrimary.obs,k2: "367.5K".obs,k3:ImageConstant.imgImage6.obs,overflowMenu:ImageConstant.imgOverflowMenuPrimary16x16.obs,k4: "837.9K".obs)]);

 }
