import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal7_item_widget] screen.
class Autolayouthorizontal7ItemModel {Autolayouthorizontal7ItemModel({this.aubrey, this.name, this.id, }) { aubrey = aubrey  ?? Rx(ImageConstant.imgEllipse80x80);name = name  ?? Rx("Aubrey");id = id  ?? Rx(""); }

Rx<String>? aubrey;

Rx<String>? name;

Rx<String>? id;

 }
