import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/search_results_users_page/models/search_results_users_model.dart';/// A controller class for the SearchResultsUsersPage.
///
/// This class manages the state of the SearchResultsUsersPage, including the
/// current searchResultsUsersModelObj
class SearchResultsUsersController extends GetxController {SearchResultsUsersController(this.searchResultsUsersModelObj);

Rx<SearchResultsUsersModel> searchResultsUsersModelObj;

 }
