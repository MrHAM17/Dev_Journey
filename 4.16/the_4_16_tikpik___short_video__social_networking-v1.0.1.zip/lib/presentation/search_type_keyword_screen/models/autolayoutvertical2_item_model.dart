import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical2_item_widget] screen.
class Autolayoutvertical2ItemModel {Autolayoutvertical2ItemModel({this.arianaGrande, this.id, }) { arianaGrande = arianaGrande  ?? Rx("Ariana Grande");id = id  ?? Rx(""); }

Rx<String>? arianaGrande;

Rx<String>? id;

 }
