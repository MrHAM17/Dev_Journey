import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical1_item_widget] screen.
class Autolayoutvertical1ItemModel {Autolayoutvertical1ItemModel({this.theresaWebb, this.id, }) { theresaWebb = theresaWebb  ?? Rx("Theresa Webb");id = id  ?? Rx(""); }

Rx<String>? theresaWebb;

Rx<String>? id;

 }
