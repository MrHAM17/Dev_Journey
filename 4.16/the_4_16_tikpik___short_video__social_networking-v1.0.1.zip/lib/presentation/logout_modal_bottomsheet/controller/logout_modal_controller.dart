import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/logout_modal_bottomsheet/models/logout_modal_model.dart';/// A controller class for the LogoutModalBottomsheet.
///
/// This class manages the state of the LogoutModalBottomsheet, including the
/// current logoutModalModelObj
class LogoutModalController extends GetxController {Rx<LogoutModalModel> logoutModalModelObj = LogoutModalModel().obs;

 }
