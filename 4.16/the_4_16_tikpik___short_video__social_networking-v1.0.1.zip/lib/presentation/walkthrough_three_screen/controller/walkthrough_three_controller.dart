import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/walkthrough_three_screen/models/walkthrough_three_model.dart';/// A controller class for the WalkthroughThreeScreen.
///
/// This class manages the state of the WalkthroughThreeScreen, including the
/// current walkthroughThreeModelObj
class WalkthroughThreeController extends GetxController {Rx<WalkthroughThreeModel> walkthroughThreeModelObj = WalkthroughThreeModel().obs;

 }
