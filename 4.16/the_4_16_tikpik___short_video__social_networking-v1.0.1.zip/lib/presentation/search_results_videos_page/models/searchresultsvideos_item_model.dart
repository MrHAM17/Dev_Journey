import '../../../core/app_export.dart';/// This class is used in the [searchresultsvideos_item_widget] screen.
class SearchresultsvideosItemModel {SearchresultsvideosItemModel({this.k, this.k1, this.k2, this.radioGroup, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage300x186);k1 = k1  ?? Rx(ImageConstant.imgOverflowmenuPrimary);k2 = k2  ?? Rx("837.5K");radioGroup = radioGroup  ?? Rx("");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? k1;

Rx<String>? k2;

Rx<String>? radioGroup;

Rx<String>? id;

 }
