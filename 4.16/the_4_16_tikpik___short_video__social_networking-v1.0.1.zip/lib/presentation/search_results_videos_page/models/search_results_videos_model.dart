import '../../../core/app_export.dart';import 'searchresultsvideos_item_model.dart';/// This class defines the variables used in the [search_results_videos_page],
/// and is typically used to hold data that is passed between different parts of the application.
class SearchResultsVideosModel {Rx<List<SearchresultsvideosItemModel>> searchresultsvideosItemList = Rx([SearchresultsvideosItemModel(k:ImageConstant.imgImage300x186.obs,k1:ImageConstant.imgOverflowmenuPrimary.obs,k2: "837.5K".obs),SearchresultsvideosItemModel(k:ImageConstant.imgImage11.obs,k2: "736.3K".obs),SearchresultsvideosItemModel(k:ImageConstant.imgImage12.obs,k1:ImageConstant.imgOverflowmenuPrimary.obs,k2: "639.8K".obs),SearchresultsvideosItemModel(k:ImageConstant.imgImage13.obs,k1:ImageConstant.imgOverflowmenuPrimary.obs,k2: "528.5K".obs)]);

 }
