import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/search_results_videos_page/models/search_results_videos_model.dart';/// A controller class for the SearchResultsVideosPage.
///
/// This class manages the state of the SearchResultsVideosPage, including the
/// current searchResultsVideosModelObj
class SearchResultsVideosController extends GetxController {SearchResultsVideosController(this.searchResultsVideosModelObj);

Rx<SearchResultsVideosModel> searchResultsVideosModelObj;

 }
