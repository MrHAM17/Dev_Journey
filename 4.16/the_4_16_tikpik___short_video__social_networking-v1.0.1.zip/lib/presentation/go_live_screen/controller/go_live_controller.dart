import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/go_live_screen/models/go_live_model.dart';/// A controller class for the GoLiveScreen.
///
/// This class manages the state of the GoLiveScreen, including the
/// current goLiveModelObj
class GoLiveController extends GetxController {Rx<GoLiveModel> goLiveModelObj = GoLiveModel().obs;

 }
