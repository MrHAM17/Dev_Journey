import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal5_item_widget] screen.
class Autolayouthorizontal5ItemModel {Rx<String>? m = Rx("3m");

Rx<bool>? isSelected = Rx(false);

 }
