import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal1_item_widget] screen.
class Autolayouthorizontal1ItemModel {Autolayouthorizontal1ItemModel({this.k, this.k1, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage19);k1 = k1  ?? Rx("728.5K");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? k1;

Rx<String>? id;

 }
