import '../../../core/app_export.dart';/// This class is used in the [autolayouthorizontal2_item_widget] screen.
class Autolayouthorizontal2ItemModel {Autolayouthorizontal2ItemModel({this.k, this.k1, this.k2, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage22);k1 = k1  ?? Rx(ImageConstant.imgOverflowmenuPrimary);k2 = k2  ?? Rx("728.5K");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? k1;

Rx<String>? k2;

Rx<String>? id;

 }
