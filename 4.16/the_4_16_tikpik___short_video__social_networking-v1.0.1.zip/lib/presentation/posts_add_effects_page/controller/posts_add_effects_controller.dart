import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/posts_add_effects_page/models/posts_add_effects_model.dart';/// A controller class for the PostsAddEffectsPage.
///
/// This class manages the state of the PostsAddEffectsPage, including the
/// current postsAddEffectsModelObj
class PostsAddEffectsController extends GetxController {PostsAddEffectsController(this.postsAddEffectsModelObj);

Rx<PostsAddEffectsModel> postsAddEffectsModelObj;

 }
