import '../../../core/app_export.dart';/// This class is used in the [postsaddeffects_item_widget] screen.
class PostsaddeffectsItemModel {PostsaddeffectsItemModel({this.image, this.image1, this.image2, this.image3, this.image4, this.image5, this.id, }) { image = image  ?? Rx(ImageConstant.imgImage45);image1 = image1  ?? Rx(ImageConstant.imgImage46);image2 = image2  ?? Rx(ImageConstant.imgImage47);image3 = image3  ?? Rx(ImageConstant.imgImage48);image4 = image4  ?? Rx(ImageConstant.imgImage49);image5 = image5  ?? Rx(ImageConstant.imgImage50);id = id  ?? Rx(""); }

Rx<String>? image;

Rx<String>? image1;

Rx<String>? image2;

Rx<String>? image3;

Rx<String>? image4;

Rx<String>? image5;

Rx<String>? id;

 }
