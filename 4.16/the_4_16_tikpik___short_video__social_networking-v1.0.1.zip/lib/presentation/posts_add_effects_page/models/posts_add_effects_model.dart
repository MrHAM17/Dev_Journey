import '../../../core/app_export.dart';import 'postsaddeffects_item_model.dart';/// This class defines the variables used in the [posts_add_effects_page],
/// and is typically used to hold data that is passed between different parts of the application.
class PostsAddEffectsModel {Rx<List<PostsaddeffectsItemModel>> postsaddeffectsItemList = Rx([PostsaddeffectsItemModel(image:ImageConstant.imgImage45.obs,image1:ImageConstant.imgImage46.obs,image2:ImageConstant.imgImage47.obs,image3:ImageConstant.imgImage48.obs,image4:ImageConstant.imgImage49.obs,image5:ImageConstant.imgImage50.obs)]);

 }
