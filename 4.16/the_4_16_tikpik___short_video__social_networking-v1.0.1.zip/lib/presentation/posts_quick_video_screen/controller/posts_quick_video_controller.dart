import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/posts_quick_video_screen/models/posts_quick_video_model.dart';/// A controller class for the PostsQuickVideoScreen.
///
/// This class manages the state of the PostsQuickVideoScreen, including the
/// current postsQuickVideoModelObj
class PostsQuickVideoController extends GetxController {Rx<PostsQuickVideoModel> postsQuickVideoModelObj = PostsQuickVideoModel().obs;

 }
