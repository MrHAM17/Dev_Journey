import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/trending_sounds_details_screen/models/trending_sounds_details_model.dart';/// A controller class for the TrendingSoundsDetailsScreen.
///
/// This class manages the state of the TrendingSoundsDetailsScreen, including the
/// current trendingSoundsDetailsModelObj
class TrendingSoundsDetailsController extends GetxController {Rx<TrendingSoundsDetailsModel> trendingSoundsDetailsModelObj = TrendingSoundsDetailsModel().obs;

 }
