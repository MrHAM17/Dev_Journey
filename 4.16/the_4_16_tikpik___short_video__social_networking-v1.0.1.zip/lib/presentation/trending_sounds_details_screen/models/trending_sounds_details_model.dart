import '../../../core/app_export.dart';import 'autolayoutvertical3_item_model.dart';/// This class defines the variables used in the [trending_sounds_details_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class TrendingSoundsDetailsModel {Rx<List<Autolayoutvertical3ItemModel>> autolayoutvertical3ItemList = Rx([Autolayoutvertical3ItemModel(k:ImageConstant.imgImage25.obs,k1:ImageConstant.imgOverflowmenuPrimary.obs,k2: "837.5K".obs,k3:ImageConstant.imgImage26.obs,k4: "837.5K".obs,k5:ImageConstant.imgImage27.obs,k6: "837.5K".obs,k7:ImageConstant.imgImage28.obs,k8: "837.5K".obs)]);

 }
