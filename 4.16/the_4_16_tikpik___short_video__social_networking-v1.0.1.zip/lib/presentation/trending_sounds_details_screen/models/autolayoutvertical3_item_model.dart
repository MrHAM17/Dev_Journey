import '../../../core/app_export.dart';/// This class is used in the [autolayoutvertical3_item_widget] screen.
class Autolayoutvertical3ItemModel {Autolayoutvertical3ItemModel({this.k, this.k1, this.k2, this.k3, this.k4, this.k5, this.k6, this.k7, this.k8, this.id, }) { k = k  ?? Rx(ImageConstant.imgImage25);k1 = k1  ?? Rx(ImageConstant.imgOverflowmenuPrimary);k2 = k2  ?? Rx("837.5K");k3 = k3  ?? Rx(ImageConstant.imgImage26);k4 = k4  ?? Rx("837.5K");k5 = k5  ?? Rx(ImageConstant.imgImage27);k6 = k6  ?? Rx("837.5K");k7 = k7  ?? Rx(ImageConstant.imgImage28);k8 = k8  ?? Rx("837.5K");id = id  ?? Rx(""); }

Rx<String>? k;

Rx<String>? k1;

Rx<String>? k2;

Rx<String>? k3;

Rx<String>? k4;

Rx<String>? k5;

Rx<String>? k6;

Rx<String>? k7;

Rx<String>? k8;

Rx<String>? id;

 }
