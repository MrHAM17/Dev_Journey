import '../../../core/app_export.dart';import 'postsaddsounds_item_model.dart';/// This class defines the variables used in the [posts_add_sounds_page],
/// and is typically used to hold data that is passed between different parts of the application.
class PostsAddSoundsModel {Rx<List<PostsaddsoundsItemModel>> postsaddsoundsItemList = Rx([PostsaddsoundsItemModel(asItWas:ImageConstant.imgImage15.obs,overflowMenu:ImageConstant.imgOverflowMenuOnerrorcontainer.obs,asItWas1: "As It Was".obs,harryStyles: "Harry Styles".obs,time: "01:00".obs,distance: "65.1M".obs,m:ImageConstant.imgBookmarkPrimary24x24.obs)]);

 }
