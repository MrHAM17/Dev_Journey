import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/posts_add_sounds_page/models/posts_add_sounds_model.dart';/// A controller class for the PostsAddSoundsPage.
///
/// This class manages the state of the PostsAddSoundsPage, including the
/// current postsAddSoundsModelObj
class PostsAddSoundsController extends GetxController {PostsAddSoundsController(this.postsAddSoundsModelObj);

Rx<PostsAddSoundsModel> postsAddSoundsModelObj;

 }
