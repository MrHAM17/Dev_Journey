import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/walkthrough_one_screen/models/walkthrough_one_model.dart';/// A controller class for the WalkthroughOneScreen.
///
/// This class manages the state of the WalkthroughOneScreen, including the
/// current walkthroughOneModelObj
class WalkthroughOneController extends GetxController {Rx<WalkthroughOneModel> walkthroughOneModelObj = WalkthroughOneModel().obs;

 }
