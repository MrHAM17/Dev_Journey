import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';import 'package:the_4_16_tikpik___short_video__social_networking/presentation/choose_your_interest_screen/models/choose_your_interest_model.dart';/// A controller class for the ChooseYourInterestScreen.
///
/// This class manages the state of the ChooseYourInterestScreen, including the
/// current chooseYourInterestModelObj
class ChooseYourInterestController extends GetxController {Rx<ChooseYourInterestModel> chooseYourInterestModelObj = ChooseYourInterestModel().obs;

 }
