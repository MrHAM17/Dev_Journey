import '../../../core/app_export.dart';/// This class is used in the [sizelargetypeborder_item_widget] screen.
class SizelargetypeborderItemModel {Rx<String>? sizeLargeTypeBorder = Rx("Gaming");

Rx<bool>? isSelected = Rx(false);

 }
