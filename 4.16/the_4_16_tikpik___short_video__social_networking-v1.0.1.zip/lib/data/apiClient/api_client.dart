import 'package:the_4_16_tikpik___short_video__social_networking/core/app_export.dart';

class ApiClient extends GetConnect {}
