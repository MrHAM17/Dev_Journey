import '../../../core/app_export.dart';
import 'profiles1_item_model.dart';
import 'forty_item_model.dart';

class DailyNewModel {
  List<Profiles1ItemModel> profiles1ItemList = [
    Profiles1ItemModel(
        nineteen: ImageConstant.img19, agnessMonica: "Agness Monica"),
    Profiles1ItemModel(nineteen: ImageConstant.img19179x147),
    Profiles1ItemModel(
        nineteen: ImageConstant.img191, agnessMonica: "Windy Wandah")
  ];

  List<FortyItemModel> fortyItemList = [
    FortyItemModel(forty: ImageConstant.img40),
    FortyItemModel(forty: ImageConstant.img34)
  ];
}
