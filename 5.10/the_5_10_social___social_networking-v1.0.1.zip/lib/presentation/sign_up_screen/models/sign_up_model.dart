import '../../../core/app_export.dart';

class SignUpModel {
  List<String> radioList = ["lbl_female", "lbl_male"];
}
