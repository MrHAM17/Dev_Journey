import '../../../core/app_export.dart';
import 'commentlist_item_model.dart';

class CommentsModel {
  List<CommentlistItemModel> commentlistItemList = [
    CommentlistItemModel(
        rizalReynaldhi: "Rizal Reynaldhi",
        duration: "35 minutes ago",
        mostPeopleNever:
            "Most people never appreciate what he does but instead they see the point of his fault for their own pleasure. ",
        reply: "Reply"),
    CommentlistItemModel(
        rizalReynaldhi: "Rizal Reynaldhi",
        duration: "35 minutes ago",
        mostPeopleNever:
            "Most people never appreciate what he does but instead they see the point of his fault for their own pleasure. ",
        reply: "Reply"),
    CommentlistItemModel(
        rizalReynaldhi: "Rizal Reynaldhi",
        duration: "35 minutes ago",
        mostPeopleNever:
            "Most people never appreciate what he does but instead they see the point of his fault for their own pleasure. ",
        reply: "Reply")
  ];
}
