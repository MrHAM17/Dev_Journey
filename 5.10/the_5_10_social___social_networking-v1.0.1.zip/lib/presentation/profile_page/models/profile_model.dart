import '../../../core/app_export.dart';
import 'profile_item_model.dart';

class ProfileModel {
  List<ProfileItemModel> profileItemList = [
    ProfileItemModel(
        rosalia: "Rosalia",
        duration: "35 minutes ago",
        mostPeopleNever:
            "Most people never appreciate what he does but instead they see the point of his fault for their own pleasure. ",
        zipcode: "2200",
        eightHundred: "800")
  ];
}
