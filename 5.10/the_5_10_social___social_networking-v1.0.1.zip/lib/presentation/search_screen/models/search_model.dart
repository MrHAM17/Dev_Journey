import '../../../core/app_export.dart';
import 'recentsearches_item_model.dart';

class SearchModel {
  List<RecentsearchesItemModel> recentsearchesItemList = [
    RecentsearchesItemModel(
        kevinAllsrub: ImageConstant.imgEllipse5,
        kevinAllsrub1: "Kevin Allsrub",
        yourEFriendsOn: "Your’e friends on twitter"),
    RecentsearchesItemModel(
        kevinAllsrub: ImageConstant.imgEllipse6,
        kevinAllsrub1: "Sarah Owen",
        yourEFriendsOn: "Your’e friends on twitter"),
    RecentsearchesItemModel(
        kevinAllsrub: ImageConstant.imgEllipse7,
        kevinAllsrub1: "Rick Onad",
        yourEFriendsOn: "Your’e friends on twitter"),
    RecentsearchesItemModel(
        kevinAllsrub: ImageConstant.imgEllipse8,
        kevinAllsrub1: "Steven Ford",
        yourEFriendsOn: "Your’e friends on twitter"),
    RecentsearchesItemModel(
        kevinAllsrub: ImageConstant.imgEllipse9,
        kevinAllsrub1: "Lucas Anna ",
        yourEFriendsOn: "Your’e friends on twitter"),
    RecentsearchesItemModel(
        kevinAllsrub: ImageConstant.imgEllipse10,
        kevinAllsrub1: "Nabila Remaar",
        yourEFriendsOn: "Your’e friends on twitter"),
    RecentsearchesItemModel(
        kevinAllsrub: ImageConstant.imgEllipse11,
        kevinAllsrub1: "Rosalia",
        yourEFriendsOn: "Your’e friends on twitter")
  ];
}
