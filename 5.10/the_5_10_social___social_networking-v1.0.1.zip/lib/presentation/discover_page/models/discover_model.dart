import '../../../core/app_export.dart';
import 'profiles_item_model.dart';

class DiscoverModel {
  List<ProfilesItemModel> profilesItemList = [
    ProfilesItemModel(
        nineteen: ImageConstant.img19, agnessMonica: "Agness Monica"),
    ProfilesItemModel(nineteen: ImageConstant.img19179x147),
    ProfilesItemModel(
        nineteen: ImageConstant.img191, agnessMonica: "Windy Wandah")
  ];
}
