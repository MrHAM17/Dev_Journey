import '../../../core/app_export.dart';
import 'trending_item_model.dart';

class TrendingModel {
  List<TrendingItemModel> trendingItemList = [
    TrendingItemModel(
        image: ImageConstant.img40221x382,
        rickOnad: "Rick Onad",
        time: "40 min ago",
        thisIsTheMoment:
            "This is the moment where i take a photo of a couple hugging in a beautiful rice field.",
        huge: "#huge",
        fotography: "#fotography",
        nature: "#nature"),
    TrendingItemModel(
        image: ImageConstant.img401,
        rickOnad: "Rick Onad",
        time: "40 min ago",
        thisIsTheMoment:
            "This is the moment where i take a photo of a couple hugging in a beautiful rice field.",
        huge: "#huge",
        fotography: "#fotography",
        nature: "#nature")
  ];
}
