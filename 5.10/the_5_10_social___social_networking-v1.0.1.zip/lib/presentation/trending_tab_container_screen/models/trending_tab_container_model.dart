import '../../../core/app_export.dart';
import 'stories_item_model.dart';

class TrendingTabContainerModel {
  List<StoriesItemModel> storiesItemList = [
    StoriesItemModel(roy: ImageConstant.imgEllipse15, roy1: "Roy"),
    StoriesItemModel(roy: ImageConstant.imgEllipse22, roy1: "Jordan"),
    StoriesItemModel(roy: ImageConstant.imgEllipse26, roy1: "Chrystin"),
    StoriesItemModel(roy: ImageConstant.imgEllipse28, roy1: "Vrindha"),
    StoriesItemModel(roy1: "Angeline")
  ];
}
