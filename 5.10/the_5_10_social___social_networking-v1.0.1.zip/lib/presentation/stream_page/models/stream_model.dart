import '../../../core/app_export.dart';
import 'stream_item_model.dart';

class StreamModel {
  List<StreamItemModel> streamItemList = [
    StreamItemModel(eighteen: ImageConstant.img18)
  ];
}
