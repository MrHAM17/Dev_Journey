import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';

class ApiClient extends GetConnect {}
