import '../../../core/app_export.dart';/// This class is used in the [searchtypekeyword_item_widget] screen.
class SearchtypekeywordItemModel {SearchtypekeywordItemModel({this.arianaGrande, this.id, }) { arianaGrande = arianaGrande  ?? Rx("Ariana Grande");id = id  ?? Rx(""); }

Rx<String>? arianaGrande;

Rx<String>? id;

 }
