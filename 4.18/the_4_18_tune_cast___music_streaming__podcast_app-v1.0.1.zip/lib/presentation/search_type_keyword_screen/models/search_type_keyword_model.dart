import '../../../core/app_export.dart';import 'searchtypekeyword_item_model.dart';/// This class defines the variables used in the [search_type_keyword_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SearchTypeKeywordModel {Rx<List<SearchtypekeywordItemModel>> searchtypekeywordItemList = Rx([SearchtypekeywordItemModel(arianaGrande: "Ariana Grande".obs),SearchtypekeywordItemModel(arianaGrande: "Morgan Wallen".obs),SearchtypekeywordItemModel(arianaGrande: "Justin Bieber".obs),SearchtypekeywordItemModel(arianaGrande: "Drake".obs),SearchtypekeywordItemModel(arianaGrande: "Olivia Rodrigo".obs),SearchtypekeywordItemModel(arianaGrande: "The Weeknd".obs),SearchtypekeywordItemModel(arianaGrande: "Taylor Swift".obs),SearchtypekeywordItemModel(arianaGrande: "Juice Wrld".obs)]);

 }
