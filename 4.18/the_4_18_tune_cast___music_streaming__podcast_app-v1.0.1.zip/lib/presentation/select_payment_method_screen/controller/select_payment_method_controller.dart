import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/select_payment_method_screen/models/select_payment_method_model.dart';/// A controller class for the SelectPaymentMethodScreen.
///
/// This class manages the state of the SelectPaymentMethodScreen, including the
/// current selectPaymentMethodModelObj
class SelectPaymentMethodController extends GetxController {Rx<SelectPaymentMethodModel> selectPaymentMethodModelObj = SelectPaymentMethodModel().obs;

 }
