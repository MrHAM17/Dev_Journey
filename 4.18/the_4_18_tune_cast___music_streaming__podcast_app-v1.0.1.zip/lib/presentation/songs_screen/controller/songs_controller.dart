import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/songs_screen/models/songs_model.dart';/// A controller class for the SongsScreen.
///
/// This class manages the state of the SongsScreen, including the
/// current songsModelObj
class SongsController extends GetxController {Rx<SongsModel> songsModelObj = SongsModel().obs;

 }
