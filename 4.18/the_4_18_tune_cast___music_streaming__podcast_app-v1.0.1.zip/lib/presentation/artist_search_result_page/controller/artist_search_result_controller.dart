import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/artist_search_result_page/models/artist_search_result_model.dart';/// A controller class for the ArtistSearchResultPage.
///
/// This class manages the state of the ArtistSearchResultPage, including the
/// current artistSearchResultModelObj
class ArtistSearchResultController extends GetxController {ArtistSearchResultController(this.artistSearchResultModelObj);

Rx<ArtistSearchResultModel> artistSearchResultModelObj;

 }
