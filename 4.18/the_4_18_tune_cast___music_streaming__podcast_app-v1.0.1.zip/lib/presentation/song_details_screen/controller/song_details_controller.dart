import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/song_details_screen/models/song_details_model.dart';/// A controller class for the SongDetailsScreen.
///
/// This class manages the state of the SongDetailsScreen, including the
/// current songDetailsModelObj
class SongDetailsController extends GetxController {Rx<SongDetailsModel> songDetailsModelObj = SongDetailsModel().obs;

 }
