import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/playlist_details_one_screen/models/playlist_details_one_model.dart';/// A controller class for the PlaylistDetailsOneScreen.
///
/// This class manages the state of the PlaylistDetailsOneScreen, including the
/// current playlistDetailsOneModelObj
class PlaylistDetailsOneController extends GetxController {Rx<PlaylistDetailsOneModel> playlistDetailsOneModelObj = PlaylistDetailsOneModel().obs;

 }
