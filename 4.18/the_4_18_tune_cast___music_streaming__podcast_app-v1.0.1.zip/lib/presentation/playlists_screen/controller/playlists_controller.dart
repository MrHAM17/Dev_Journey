import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/playlists_screen/models/playlists_model.dart';/// A controller class for the PlaylistsScreen.
///
/// This class manages the state of the PlaylistsScreen, including the
/// current playlistsModelObj
class PlaylistsController extends GetxController {Rx<PlaylistsModel> playlistsModelObj = PlaylistsModel().obs;

 }
