import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/charts_screen/models/charts_model.dart';/// A controller class for the ChartsScreen.
///
/// This class manages the state of the ChartsScreen, including the
/// current chartsModelObj
class ChartsController extends GetxController {Rx<ChartsModel> chartsModelObj = ChartsModel().obs;

 }
