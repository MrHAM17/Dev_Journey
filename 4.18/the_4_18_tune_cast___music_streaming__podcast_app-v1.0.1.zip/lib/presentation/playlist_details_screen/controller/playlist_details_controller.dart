import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/playlist_details_screen/models/playlist_details_model.dart';/// A controller class for the PlaylistDetailsScreen.
///
/// This class manages the state of the PlaylistDetailsScreen, including the
/// current playlistDetailsModelObj
class PlaylistDetailsController extends GetxController {Rx<PlaylistDetailsModel> playlistDetailsModelObj = PlaylistDetailsModel().obs;

 }
