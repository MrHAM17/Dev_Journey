import '../../../core/app_export.dart';import 'frame2_item_model.dart';/// This class defines the variables used in the [my_library_page],
/// and is typically used to hold data that is passed between different parts of the application.
class MyLibraryModel {Rx<List<Frame2ItemModel>> frame2ItemList = Rx([Frame2ItemModel(theJordanHarb:ImageConstant.imgImage31.obs,billSullivan: "The Jordan Harb...".obs),Frame2ItemModel(theJordanHarb:ImageConstant.imgImage32.obs,billSullivan: "Apple Talk".obs),Frame2ItemModel(theJordanHarb:ImageConstant.imgImage33.obs,billSullivan: "Dr. Death".obs)]);

 }
