import '../../../core/app_export.dart';/// This class defines the variables used in the [language_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class LanguageModel {Rx<List<String>> radioList = Rx(["lbl_english_us","lbl_english_uk"]);

Rx<List<String>> radioList1 = Rx(["lbl_mandarin","lbl_hindi","lbl_spanish","lbl_french","lbl_arabic","lbl_bengali"]);

 }
