import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/song_play_over_screen_page/models/song_play_over_screen_model.dart';/// A controller class for the SongPlayOverScreenPage.
///
/// This class manages the state of the SongPlayOverScreenPage, including the
/// current songPlayOverScreenModelObj
class SongPlayOverScreenController extends GetxController {SongPlayOverScreenController(this.songPlayOverScreenModelObj);

Rx<SongPlayOverScreenModel> songPlayOverScreenModelObj;

 }
