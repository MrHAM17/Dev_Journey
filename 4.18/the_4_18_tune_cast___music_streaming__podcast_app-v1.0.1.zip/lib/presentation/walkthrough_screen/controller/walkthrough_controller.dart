import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/walkthrough_screen/models/walkthrough_model.dart';/// A controller class for the WalkthroughScreen.
///
/// This class manages the state of the WalkthroughScreen, including the
/// current walkthroughModelObj
class WalkthroughController extends GetxController {Rx<WalkthroughModel> walkthroughModelObj = WalkthroughModel().obs;

 }
