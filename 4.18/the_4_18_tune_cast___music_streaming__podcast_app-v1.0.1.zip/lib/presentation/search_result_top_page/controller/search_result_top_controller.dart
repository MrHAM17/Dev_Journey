import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/search_result_top_page/models/search_result_top_model.dart';/// A controller class for the SearchResultTopPage.
///
/// This class manages the state of the SearchResultTopPage, including the
/// current searchResultTopModelObj
class SearchResultTopController extends GetxController {SearchResultTopController(this.searchResultTopModelObj);

Rx<SearchResultTopModel> searchResultTopModelObj;

 }
