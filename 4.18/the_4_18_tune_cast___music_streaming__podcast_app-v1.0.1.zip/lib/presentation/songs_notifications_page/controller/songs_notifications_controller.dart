import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/songs_notifications_page/models/songs_notifications_model.dart';/// A controller class for the SongsNotificationsPage.
///
/// This class manages the state of the SongsNotificationsPage, including the
/// current songsNotificationsModelObj
class SongsNotificationsController extends GetxController {SongsNotificationsController(this.songsNotificationsModelObj);

Rx<SongsNotificationsModel> songsNotificationsModelObj;

 }
