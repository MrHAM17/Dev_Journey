import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/payment_summary_screen/models/payment_summary_model.dart';/// A controller class for the PaymentSummaryScreen.
///
/// This class manages the state of the PaymentSummaryScreen, including the
/// current paymentSummaryModelObj
class PaymentSummaryController extends GetxController {Rx<PaymentSummaryModel> paymentSummaryModelObj = PaymentSummaryModel().obs;

 }
