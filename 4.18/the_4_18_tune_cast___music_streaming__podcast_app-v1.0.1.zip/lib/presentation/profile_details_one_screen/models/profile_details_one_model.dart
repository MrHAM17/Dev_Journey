import '../../../core/app_export.dart';import 'profiledetailsone_item_model.dart';/// This class defines the variables used in the [profile_details_one_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class ProfileDetailsOneModel {Rx<List<ProfiledetailsoneItemModel>> profiledetailsoneItemList = Rx([ProfiledetailsoneItemModel(image:ImageConstant.imgImage74.obs,positions: "Ariana Grande - All \nSongs ".obs),ProfiledetailsoneItemModel(image:ImageConstant.imgImage75.obs,positions: "Ariana Grande - Top \nGreatest Hits".obs)]);

 }
