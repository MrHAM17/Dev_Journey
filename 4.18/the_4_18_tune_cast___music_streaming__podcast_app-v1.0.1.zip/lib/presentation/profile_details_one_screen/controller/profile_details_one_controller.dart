import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/profile_details_one_screen/models/profile_details_one_model.dart';/// A controller class for the ProfileDetailsOneScreen.
///
/// This class manages the state of the ProfileDetailsOneScreen, including the
/// current profileDetailsOneModelObj
class ProfileDetailsOneController extends GetxController {Rx<ProfileDetailsOneModel> profileDetailsOneModelObj = ProfileDetailsOneModel().obs;

 }
