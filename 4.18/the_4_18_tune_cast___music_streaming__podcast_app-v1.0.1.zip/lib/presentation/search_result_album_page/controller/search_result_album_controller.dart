import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/search_result_album_page/models/search_result_album_model.dart';/// A controller class for the SearchResultAlbumPage.
///
/// This class manages the state of the SearchResultAlbumPage, including the
/// current searchResultAlbumModelObj
class SearchResultAlbumController extends GetxController {SearchResultAlbumController(this.searchResultAlbumModelObj);

Rx<SearchResultAlbumModel> searchResultAlbumModelObj;

 }
