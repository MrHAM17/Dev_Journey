import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/search_result_profile_page/models/search_result_profile_model.dart';/// A controller class for the SearchResultProfilePage.
///
/// This class manages the state of the SearchResultProfilePage, including the
/// current searchResultProfileModelObj
class SearchResultProfileController extends GetxController {SearchResultProfileController(this.searchResultProfileModelObj);

Rx<SearchResultProfileModel> searchResultProfileModelObj;

 }
