import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/search_result_podcast_page/models/search_result_podcast_model.dart';/// A controller class for the SearchResultPodcastPage.
///
/// This class manages the state of the SearchResultPodcastPage, including the
/// current searchResultPodcastModelObj
class SearchResultPodcastController extends GetxController {SearchResultPodcastController(this.searchResultPodcastModelObj);

Rx<SearchResultPodcastModel> searchResultPodcastModelObj;

 }
