import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/queue_page/models/queue_model.dart';/// A controller class for the QueuePage.
///
/// This class manages the state of the QueuePage, including the
/// current queueModelObj
class QueueController extends GetxController {QueueController(this.queueModelObj);

Rx<QueueModel> queueModelObj;

 }
