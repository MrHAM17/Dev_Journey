import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/trending_now_screen/models/trending_now_model.dart';/// A controller class for the TrendingNowScreen.
///
/// This class manages the state of the TrendingNowScreen, including the
/// current trendingNowModelObj
class TrendingNowController extends GetxController {Rx<TrendingNowModel> trendingNowModelObj = TrendingNowModel().obs;

 }
