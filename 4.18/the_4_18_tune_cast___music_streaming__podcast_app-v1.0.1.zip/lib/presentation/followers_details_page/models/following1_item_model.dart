import '../../../core/app_export.dart';/// This class is used in the [following1_item_widget] screen.
class Following1ItemModel {Following1ItemModel({this.id}) { id = id  ?? Rx(""); }

Rx<String>? id;

 }
