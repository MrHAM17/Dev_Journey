import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/followers_details_page/models/followers_details_model.dart';/// A controller class for the FollowersDetailsPage.
///
/// This class manages the state of the FollowersDetailsPage, including the
/// current followersDetailsModelObj
class FollowersDetailsController extends GetxController {FollowersDetailsController(this.followersDetailsModelObj);

Rx<FollowersDetailsModel> followersDetailsModelObj;

 }
