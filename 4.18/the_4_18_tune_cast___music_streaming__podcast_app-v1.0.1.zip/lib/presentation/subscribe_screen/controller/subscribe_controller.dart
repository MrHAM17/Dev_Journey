import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/subscribe_screen/models/subscribe_model.dart';/// A controller class for the SubscribeScreen.
///
/// This class manages the state of the SubscribeScreen, including the
/// current subscribeModelObj
class SubscribeController extends GetxController {Rx<SubscribeModel> subscribeModelObj = SubscribeModel().obs;

 }
