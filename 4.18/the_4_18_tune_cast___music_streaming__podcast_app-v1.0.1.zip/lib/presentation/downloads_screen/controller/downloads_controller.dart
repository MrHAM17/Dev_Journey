import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/downloads_screen/models/downloads_model.dart';/// A controller class for the DownloadsScreen.
///
/// This class manages the state of the DownloadsScreen, including the
/// current downloadsModelObj
class DownloadsController extends GetxController {Rx<DownloadsModel> downloadsModelObj = DownloadsModel().obs;

 }
