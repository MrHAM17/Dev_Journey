import 'package:the_4_18_tune_cast___music_streaming__podcast_app/core/app_export.dart';import 'package:the_4_18_tune_cast___music_streaming__podcast_app/presentation/search_results_songs_page/models/search_results_songs_model.dart';/// A controller class for the SearchResultsSongsPage.
///
/// This class manages the state of the SearchResultsSongsPage, including the
/// current searchResultsSongsModelObj
class SearchResultsSongsController extends GetxController {SearchResultsSongsController(this.searchResultsSongsModelObj);

Rx<SearchResultsSongsModel> searchResultsSongsModelObj;

 }
