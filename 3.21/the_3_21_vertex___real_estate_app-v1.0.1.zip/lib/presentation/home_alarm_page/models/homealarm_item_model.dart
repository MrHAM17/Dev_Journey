import '../../../core/app_export.dart';/// This class is used in the [homealarm_item_widget] screen.
class HomealarmItemModel {HomealarmItemModel({this.mightyCincoFamily, this.stCelinaDelaware, this.jan, this.jan1, this.pm, this.time, this.mightyCincoFamily1, this.buyerSAgent, this.leslieAlexander, this.id, }) { mightyCincoFamily = mightyCincoFamily  ?? "Mighty Cinco Family";stCelinaDelaware = stCelinaDelaware  ?? "St. Celina, Delaware 10299";jan = jan  ?? ImageConstant.imgCalendar;jan1 = jan1  ?? "Jan 1, 2021";pm = pm  ?? ImageConstant.imgClock;time = time  ?? "4:00 PM";mightyCincoFamily1 = mightyCincoFamily1  ?? ImageConstant.imgAvatar;buyerSAgent = buyerSAgent  ?? "Buyer’s Agent";leslieAlexander = leslieAlexander  ?? "Leslie Alexander";id = id  ?? ""; }

String? mightyCincoFamily;

String? stCelinaDelaware;

String? jan;

String? jan1;

String? pm;

String? time;

String? mightyCincoFamily1;

String? buyerSAgent;

String? leslieAlexander;

String? id;

 }
