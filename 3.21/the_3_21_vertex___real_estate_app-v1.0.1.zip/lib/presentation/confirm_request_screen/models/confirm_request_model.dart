// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [confirm_request_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class ConfirmRequestModel extends Equatable {ConfirmRequestModel() {  }

ConfirmRequestModel copyWith() { return ConfirmRequestModel(
); } 
@override List<Object?> get props => [];
 }
