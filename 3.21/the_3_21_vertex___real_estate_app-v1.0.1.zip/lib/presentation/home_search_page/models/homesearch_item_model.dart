import '../../../core/app_export.dart';/// This class is used in the [homesearch_item_widget] screen.
class HomesearchItemModel {HomesearchItemModel({this.mightyCincoFamily, this.mightyCincoFamily1, this.id, }) { mightyCincoFamily = mightyCincoFamily  ?? ImageConstant.imgImg40x40;mightyCincoFamily1 = mightyCincoFamily1  ?? "Mighty Cinco Family";id = id  ?? ""; }

String? mightyCincoFamily;

String? mightyCincoFamily1;

String? id;

 }
