import '../../../core/app_export.dart';/// This class is used in the [messages_item_widget] screen.
class MessagesItemModel {MessagesItemModel({this.wadeWarren, this.wadeWarren1, this.message, this.time, this.id, }) { wadeWarren = wadeWarren  ?? ImageConstant.imgImg48x48;wadeWarren1 = wadeWarren1  ?? "Wade Warren";message = message  ?? "Oh hello Willam...";time = time  ?? "23:15";id = id  ?? ""; }

String? wadeWarren;

String? wadeWarren1;

String? message;

String? time;

String? id;

 }
