class User {
  static String email = "Priscilla_Mohr@yahoo.com";
}
