import '../../../core/app_export.dart';

/// This class is used in the [messageaction_item_widget] screen.
class MessageactionItemModel {
  MessageactionItemModel({
    this.estherHoward,
    this.estherHoward1,
    this.loremIpsumDolor,
    this.time,
    this.widget,
    this.id,
  }) {
    estherHoward = estherHoward ?? ImageConstant.imgImage56x56;
    estherHoward1 = estherHoward1 ?? "Esther Howard";
    loremIpsumDolor = loremIpsumDolor ?? "Lorem ipsum dolor sit amet...";
    time = time ?? "10:20";
    widget = widget ?? "2";
    id = id ?? "";
  }

  String? estherHoward;

  String? estherHoward1;

  String? loremIpsumDolor;

  String? time;

  String? widget;

  String? id;
}
