// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [enter_otp_page],
/// and is typically used to hold data that is passed between different parts of the application.
class EnterOtpModel extends Equatable {
  EnterOtpModel() {}

  EnterOtpModel copyWith() {
    return EnterOtpModel();
  }

  @override
  List<Object?> get props => [];
}
