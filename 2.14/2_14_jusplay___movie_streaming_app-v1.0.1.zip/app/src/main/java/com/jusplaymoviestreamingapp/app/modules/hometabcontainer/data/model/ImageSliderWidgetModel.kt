package com.jusplaymoviestreamingapp.app.modules.hometabcontainer.`data`.model

import kotlin.String

data class ImageSliderWidgetModel(
  /**
   * TODO Replace with dynamic value
   */
  var imageImage: String? = ""

)
