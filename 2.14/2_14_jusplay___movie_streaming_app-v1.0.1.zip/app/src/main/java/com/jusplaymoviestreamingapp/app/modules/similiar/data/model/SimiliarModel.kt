package com.jusplaymoviestreamingapp.app.modules.similiar.`data`.model

class SimiliarModel()
