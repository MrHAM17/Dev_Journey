package com.jusplaymoviestreamingapp.app.modules.homerecentlywatched.`data`.model

import kotlin.String

data class ImageSliderWidgetModel(
  /**
   * TODO Replace with dynamic value
   */
  var imageImage: String? = ""

)
