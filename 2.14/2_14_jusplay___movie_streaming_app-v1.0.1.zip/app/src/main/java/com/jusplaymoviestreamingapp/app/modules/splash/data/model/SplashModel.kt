package com.jusplaymoviestreamingapp.app.modules.splash.`data`.model

class SplashModel()
