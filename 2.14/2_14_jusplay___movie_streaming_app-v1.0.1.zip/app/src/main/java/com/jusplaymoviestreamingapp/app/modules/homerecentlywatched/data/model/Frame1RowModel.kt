package com.jusplaymoviestreamingapp.app.modules.homerecentlywatched.`data`.model

class Frame1RowModel()
