package com.jusplaymoviestreamingapp.app.modules.search.`data`.model

class Frame3RowModel()
