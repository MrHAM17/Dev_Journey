package com.jusplaymoviestreamingapp.app.modules.home.`data`.model

class AladdinRowModel()
