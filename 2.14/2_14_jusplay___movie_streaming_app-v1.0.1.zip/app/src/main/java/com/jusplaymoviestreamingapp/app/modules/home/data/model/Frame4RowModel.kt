package com.jusplaymoviestreamingapp.app.modules.home.`data`.model

class Frame4RowModel()
