package com.jusplaymoviestreamingapp.app.modules.categorycomedy.`data`.model

class CategorycomedyRowModel()
