package com.jusplaymoviestreamingapp.app.modules.editprofile.`data`.model

import kotlin.String

data class SpinnerArrowdownModel(
  val itemName: String
)
