package com.jusplaymoviestreamingapp.app.modules.searchresult.`data`.model

class SearchresultRowModel()
