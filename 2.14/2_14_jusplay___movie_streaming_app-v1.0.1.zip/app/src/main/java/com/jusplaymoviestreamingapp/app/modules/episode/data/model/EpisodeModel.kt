package com.jusplaymoviestreamingapp.app.modules.episode.`data`.model

class EpisodeModel()
