package com.jusplaymoviestreamingapp.app.constants

import kotlin.Int

public object user {
    public val ROLE: Int = 1
}
