import 'package:the_3_08_shopsie___e_commerce_app/core/app_export.dart';

class ApiClient {}
