import 'filter_item_model.dart';import '../../../core/app_export.dart';import 'layout14_item_model.dart';class ResultFilterModel {List<FilterItemModel> filterItemList = List.generate(2,(index) =>FilterItemModel());

List<Layout14ItemModel> layout14ItemList = [Layout14ItemModel(image:ImageConstant.imgShape41,favorite:ImageConstant.imgFavoriteRedA200,bridgelandModernHouse: "Bridgeland Modern House",text: "4.9",semarangIndonesia: "Semarang, Indonesia",price: " 260",month: "/month"),Layout14ItemModel(image:ImageConstant.imgShape31,favorite:ImageConstant.imgFavorite,bridgelandModernHouse: "Wayside Modern House",text: "4.4",semarangIndonesia: "Semarang, Indonesia",price: " 220",month: "/month"),Layout14ItemModel(image:ImageConstant.imgShape42,favorite:ImageConstant.imgFavoriteRedA200,bridgelandModernHouse: "Shoolview House",text: "4.6",semarangIndonesia: "Semarang, Indonesia",price: " 245",month: "/month")];

 }
