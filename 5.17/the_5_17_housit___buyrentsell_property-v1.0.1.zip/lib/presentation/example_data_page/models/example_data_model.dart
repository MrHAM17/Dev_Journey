import '../../../core/app_export.dart';import 'layout13_item_model.dart';class ExampleDataModel {List<Layout13ItemModel> layout13ItemList = [Layout13ItemModel(image:ImageConstant.imgShape104x126,skyDandelionsApartment: "Sky Dandelions\nApartment",text: "4.2 ",jakartaIndonesia: "Jakarta, Indonesia"),Layout13ItemModel(skyDandelionsApartment: "Sky Dandelions\nApartment",text: "4.2 ",jakartaIndonesia: "Jakarta, Indonesia")];

 }
