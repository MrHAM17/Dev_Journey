import '../../../core/app_export.dart';/// This class is used in the [transactiontype_item_widget] screen.
class TransactiontypeItemModel {TransactiontypeItemModel({this.layout, this.isSelected, }) { layout = layout  ?? "Rent";isSelected = isSelected  ?? false; }

String? layout;

bool? isSelected;

 }
