import '../../../core/app_export.dart';/// This class is used in the [widget2_item_widget] screen.
class Widget2ItemModel {Widget2ItemModel({this.buttonCategory, this.isSelected, }) { buttonCategory = buttonCategory  ?? "Home theatre";isSelected = isSelected  ?? false; }

String? buttonCategory;

bool? isSelected;

 }
