import 'widget_item_model.dart';import 'widget2_item_model.dart';import '../../../core/app_export.dart';class FilterFullModel {List<WidgetItemModel> widgetItemList = List.generate(2,(index) =>WidgetItemModel());

List<Widget2ItemModel> widget2ItemList = List.generate(7,(index) =>Widget2ItemModel());

 }
