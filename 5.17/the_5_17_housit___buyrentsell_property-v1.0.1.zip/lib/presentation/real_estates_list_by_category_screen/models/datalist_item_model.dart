import '../../../core/app_export.dart';/// This class is used in the [datalist_item_widget] screen.
class DatalistItemModel {DatalistItemModel({this.villa, this.theLaurelsVilla, this.text, this.baliIndonesia, this.price, this.month, this.id, }) { villa = villa  ?? "Villa";theLaurelsVilla = theLaurelsVilla  ?? "The Laurels Villa";text = text  ?? "4.9 ";baliIndonesia = baliIndonesia  ?? "Bali, Indonesia";price = price  ?? " 320";month = month  ?? "/night";id = id  ?? ""; }

String? villa;

String? theLaurelsVilla;

String? text;

String? baliIndonesia;

String? price;

String? month;

String? id;

 }
