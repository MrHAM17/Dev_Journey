import '../../../core/app_export.dart';import 'transaction_item_model.dart';class TransactionModel {List<TransactionItemModel> transactionItemList = [TransactionItemModel(wingsTower:ImageConstant.imgShape17,wingsTower1: "Wings Tower",date: "November 21,2021"),TransactionItemModel(wingsTower:ImageConstant.imgShape33,wingsTower1: "Bridgeland Modern ",date: "December")];

 }
