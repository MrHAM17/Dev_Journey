import '../../../core/app_export.dart';/// This class is used in the [samuelella_item_widget] screen.
class SamuelellaItemModel {SamuelellaItemModel({this.id}) { id = id  ?? ""; }

String? id;

 }
