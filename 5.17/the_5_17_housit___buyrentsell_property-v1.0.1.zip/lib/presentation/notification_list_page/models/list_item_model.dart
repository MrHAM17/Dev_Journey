import '../../../core/app_export.dart';/// This class is used in the [list_item_widget] screen.
class ListItemModel {ListItemModel({this.emmettPerry, this.emmettPerry1, this.time, this.id, }) { emmettPerry = emmettPerry  ?? ImageConstant.imgShape50x50;emmettPerry1 = emmettPerry1  ?? "Emmett Perry";time = time  ?? "10 mins ago";id = id  ?? ""; }

String? emmettPerry;

String? emmettPerry1;

String? time;

String? id;

 }
