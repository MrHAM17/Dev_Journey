import '../../../core/app_export.dart';/// This class is used in the [layout9_item_widget] screen.
class Layout9ItemModel {Layout9ItemModel({this.buttonCategory, this.isSelected, }) { buttonCategory = buttonCategory  ?? "< 4";isSelected = isSelected  ?? false; }

String? buttonCategory;

bool? isSelected;

 }
