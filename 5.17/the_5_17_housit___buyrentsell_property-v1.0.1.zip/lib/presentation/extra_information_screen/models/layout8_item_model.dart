import '../../../core/app_export.dart';/// This class is used in the [layout8_item_widget] screen.
class Layout8ItemModel {Layout8ItemModel({this.bedroom, this.text, this.id, }) { bedroom = bedroom  ?? "Bedroom";text = text  ?? "3";id = id  ?? ""; }

String? bedroom;

String? text;

String? id;

 }
