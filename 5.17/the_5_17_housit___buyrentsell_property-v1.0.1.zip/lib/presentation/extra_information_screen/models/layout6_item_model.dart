import '../../../core/app_export.dart';/// This class is used in the [layout6_item_widget] screen.
class Layout6ItemModel {Layout6ItemModel({this.buttonCategory, this.isSelected, }) { buttonCategory = buttonCategory  ?? "Monthly";isSelected = isSelected  ?? false; }

String? buttonCategory;

bool? isSelected;

 }
