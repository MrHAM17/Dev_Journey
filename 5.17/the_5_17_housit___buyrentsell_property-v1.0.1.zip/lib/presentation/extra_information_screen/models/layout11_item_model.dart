import '../../../core/app_export.dart';/// This class is used in the [layout11_item_widget] screen.
class Layout11ItemModel {Layout11ItemModel({this.buttonCategory, this.isSelected, }) { buttonCategory = buttonCategory  ?? "Parking Lot";isSelected = isSelected  ?? false; }

String? buttonCategory;

bool? isSelected;

 }
