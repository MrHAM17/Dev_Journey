import '../../../core/app_export.dart';/// This class is used in the [vertical_item_widget] screen.
class VerticalItemModel {VerticalItemModel({this.theLaurelsVilla, this.price, this.month, this.theLaurelsVilla1, this.image, this.text, this.baliIndonesia, this.id, }) { theLaurelsVilla = theLaurelsVilla  ?? ImageConstant.imgShape30;price = price  ?? " 320";month = month  ?? "/night";theLaurelsVilla1 = theLaurelsVilla1  ?? "The Laurels Villa";image = image  ?? ImageConstant.imgSignalOrange3009x9;text = text  ?? "4.9";baliIndonesia = baliIndonesia  ?? "Bali, Indonesia";id = id  ?? ""; }

String? theLaurelsVilla;

String? price;

String? month;

String? theLaurelsVilla1;

String? image;

String? text;

String? baliIndonesia;

String? id;

 }
