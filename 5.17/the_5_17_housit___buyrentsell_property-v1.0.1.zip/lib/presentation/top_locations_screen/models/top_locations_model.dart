import '../../../core/app_export.dart';import 'data_item_model.dart';class TopLocationsModel {List<DataItemModel> dataItemList = [DataItemModel(bali:ImageConstant.imgShape174x144,bali1: "Bali"),DataItemModel(bali:ImageConstant.imgShape5,bali1: "Jakarta"),DataItemModel(bali:ImageConstant.imgShape6,bali1: "Yogyakarta"),DataItemModel(bali:ImageConstant.imgShape7,bali1: "Semarang"),DataItemModel(bali:ImageConstant.imgShape8,bali1: "Jakarta"),DataItemModel(bali:ImageConstant.imgShape9,bali1: "Jakarta")];

 }
