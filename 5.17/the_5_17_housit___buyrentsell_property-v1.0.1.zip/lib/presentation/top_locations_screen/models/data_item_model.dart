import '../../../core/app_export.dart';/// This class is used in the [data_item_widget] screen.
class DataItemModel {DataItemModel({this.bali, this.bali1, this.id, }) { bali = bali  ?? ImageConstant.imgShape174x144;bali1 = bali1  ?? "Bali";id = id  ?? ""; }

String? bali;

String? bali1;

String? id;

 }
