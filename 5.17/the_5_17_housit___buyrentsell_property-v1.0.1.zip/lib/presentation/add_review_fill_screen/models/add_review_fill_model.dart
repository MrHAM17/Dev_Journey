import '../../../core/app_export.dart';import 'addreviewfill_item_model.dart';class AddReviewFillModel {List<AddreviewfillItemModel> addreviewfillItemList = [AddreviewfillItemModel(shape:ImageConstant.imgShape50,iconClose:ImageConstant.imgIconCloseWhiteA700),AddreviewfillItemModel(shape:ImageConstant.imgShape51,iconClose:ImageConstant.imgIconCloseWhiteA700)];

 }
