import '../../../core/app_export.dart';import 'cardlist_item_model.dart';class ReviewEmptyModel {List<CardlistItemModel> cardlistItemList = [CardlistItemModel(text: "•••••••• 1222",balance: "Balance",price: " 31,250",balance1:ImageConstant.imgUser),CardlistItemModel(text: "•••••••• 1542",balance: "Balance",price: " 54,200",balance1:ImageConstant.imgSettings)];

 }
