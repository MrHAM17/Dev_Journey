import '../../../core/app_export.dart';/// This class is used in the [preferable_item_widget] screen.
class PreferableItemModel {PreferableItemModel({this.house, this.house1, this.id, }) { house = house  ?? ImageConstant.imgShape43;house1 = house1  ?? "House";id = id  ?? ""; }

String? house;

String? house1;

String? id;

 }
