import '../../../core/app_export.dart';import 'preferable_item_model.dart';class PreferableModel {List<PreferableItemModel> preferableItemList = [PreferableItemModel(house:ImageConstant.imgShape43,house1: "House"),PreferableItemModel(house:ImageConstant.imgShape44,house1: "Apartment"),PreferableItemModel(house:ImageConstant.imgShape45,house1: "Villa"),PreferableItemModel(house:ImageConstant.imgShape46,house1: "Cottage"),PreferableItemModel(house:ImageConstant.imgShape47,house1: "House"),PreferableItemModel(house:ImageConstant.imgShape48,house1: "House")];

 }
