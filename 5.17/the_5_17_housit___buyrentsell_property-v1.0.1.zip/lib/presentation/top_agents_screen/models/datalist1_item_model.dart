import '../../../core/app_export.dart';/// This class is used in the [datalist1_item_widget] screen.
class Datalist1ItemModel {Datalist1ItemModel({this.amanda, this.amanda1, this.text, this.text1, this.sold, this.id, }) { amanda = amanda  ?? ImageConstant.imgShape100x100;amanda1 = amanda1  ?? "Amanda";text = text  ?? "5.0";text1 = text1  ?? "112";sold = sold  ?? "Sold";id = id  ?? ""; }

String? amanda;

String? amanda1;

String? text;

String? text1;

String? sold;

String? id;

 }
