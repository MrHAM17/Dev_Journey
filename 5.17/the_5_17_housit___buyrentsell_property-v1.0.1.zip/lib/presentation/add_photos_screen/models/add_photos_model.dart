import '../../../core/app_export.dart';import 'gallery_item_model.dart';class AddPhotosModel {List<GalleryItemModel> galleryItemList = [GalleryItemModel(shape:ImageConstant.imgShape161x159,iconClose:ImageConstant.imgIconCloseWhiteA700),GalleryItemModel(shape:ImageConstant.imgShape21,iconClose:ImageConstant.imgIconCloseWhiteA700),GalleryItemModel(shape:ImageConstant.imgShape22,iconClose:ImageConstant.imgIconCloseWhiteA700)];

 }
