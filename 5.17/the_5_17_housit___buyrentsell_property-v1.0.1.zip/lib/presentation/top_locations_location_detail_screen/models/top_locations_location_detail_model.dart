import 'frameeightyone_item_model.dart';import '../../../core/app_export.dart';import 'toplocationslocationdetail_item_model.dart';class TopLocationsLocationDetailModel {List<FrameeightyoneItemModel> frameeightyoneItemList = List.generate(2,(index) =>FrameeightyoneItemModel());

List<ToplocationslocationdetailItemModel> toplocationslocationdetailItemList = [ToplocationslocationdetailItemModel(flowerHeavenHouse: "Flower Heaven House",text: "4.7 ",baliIndonesia: "Bali, Indonesia",price: " 370",month: "/month"),ToplocationslocationdetailItemModel(flowerHeavenHouse: "Flower Heaven House",text: "4.7 ",baliIndonesia: "Bali, Indonesia",price: " 370",month: "/month")];

 }
