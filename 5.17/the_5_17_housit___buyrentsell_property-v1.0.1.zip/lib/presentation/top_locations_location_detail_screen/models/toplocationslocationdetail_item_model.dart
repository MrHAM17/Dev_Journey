import '../../../core/app_export.dart';/// This class is used in the [toplocationslocationdetail_item_widget] screen.
class ToplocationslocationdetailItemModel {ToplocationslocationdetailItemModel({this.flowerHeavenHouse, this.text, this.baliIndonesia, this.price, this.month, this.id, }) { flowerHeavenHouse = flowerHeavenHouse  ?? "Flower Heaven House";text = text  ?? "4.7 ";baliIndonesia = baliIndonesia  ?? "Bali, Indonesia";price = price  ?? " 370";month = month  ?? "/month";id = id  ?? ""; }

String? flowerHeavenHouse;

String? text;

String? baliIndonesia;

String? price;

String? month;

String? id;

 }
