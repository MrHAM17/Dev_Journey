import 'layout2_item_model.dart';import 'layout4_item_model.dart';import '../../../core/app_export.dart';class FormDetailModel {List<Layout2ItemModel> layout2ItemList = List.generate(2,(index) =>Layout2ItemModel());

List<Layout4ItemModel> layout4ItemList = List.generate(5,(index) =>Layout4ItemModel());

 }
