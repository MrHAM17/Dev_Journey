import '../../../core/app_export.dart';/// This class is used in the [layout4_item_widget] screen.
class Layout4ItemModel {Layout4ItemModel({this.buttonCategory, this.isSelected, }) { buttonCategory = buttonCategory  ?? "House";isSelected = isSelected  ?? false; }

String? buttonCategory;

bool? isSelected;

 }
