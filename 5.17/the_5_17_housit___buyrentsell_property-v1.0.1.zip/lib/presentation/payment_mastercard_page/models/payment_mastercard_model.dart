import '../../../core/app_export.dart';class PaymentMastercardModel {DateTime? selectedDate;

String date = "11/05/2023";

 }
