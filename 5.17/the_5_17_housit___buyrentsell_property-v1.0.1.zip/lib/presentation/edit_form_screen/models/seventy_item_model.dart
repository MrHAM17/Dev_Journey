import '../../../core/app_export.dart';/// This class is used in the [seventy_item_widget] screen.
class SeventyItemModel {SeventyItemModel({this.buttonCategory, this.isSelected, }) { buttonCategory = buttonCategory  ?? "Parking Lot";isSelected = isSelected  ?? false; }

String? buttonCategory;

bool? isSelected;

 }
