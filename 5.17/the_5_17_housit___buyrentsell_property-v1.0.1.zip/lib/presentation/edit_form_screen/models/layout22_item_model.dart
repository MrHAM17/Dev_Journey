import '../../../core/app_export.dart';/// This class is used in the [layout22_item_widget] screen.
class Layout22ItemModel {Layout22ItemModel({this.buttonCategory, this.isSelected, }) { buttonCategory = buttonCategory  ?? "< 4";isSelected = isSelected  ?? false; }

String? buttonCategory;

bool? isSelected;

 }
