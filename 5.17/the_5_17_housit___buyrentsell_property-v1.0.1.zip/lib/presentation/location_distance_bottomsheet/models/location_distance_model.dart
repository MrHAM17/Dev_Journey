import 'locationlist_item_model.dart';import '../../../core/app_export.dart';class LocationDistanceModel {List<LocationlistItemModel> locationlistItemList = List.generate(2,(index) => LocationlistItemModel());

 }
