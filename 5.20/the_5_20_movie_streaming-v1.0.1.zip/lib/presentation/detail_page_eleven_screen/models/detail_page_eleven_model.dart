import '../../../core/app_export.dart';
import 'movies3_item_model.dart';

class DetailPageElevenModel {
  List<Movies3ItemModel> movies3ItemList = [
    Movies3ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage180x120,
        title: "IO: Netflix",
        title1: "In near future we must save earth"),
    Movies3ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage7,
        title: "I Kill Giants",
        title1: "No more Surrender this time"),
    Movies3ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage9,
        title: "Angel has Fallen",
        title1: "Loyalty under everything")
  ];
}
