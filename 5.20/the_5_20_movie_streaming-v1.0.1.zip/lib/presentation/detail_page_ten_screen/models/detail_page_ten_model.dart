import '../../../core/app_export.dart';
import 'movies2_item_model.dart';

class DetailPageTenModel {
  List<Movies2ItemModel> movies2ItemList = [
    Movies2ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage180x120,
        title: "IO: Netflix",
        title1: "In near future we must save earth"),
    Movies2ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage7,
        title: "I Kill Giants",
        title1: "No more Surrender this time"),
    Movies2ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage9,
        title: "Angel has Fallen",
        title1: "Loyalty under everything")
  ];
}
