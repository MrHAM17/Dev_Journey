import '../../../core/app_export.dart';
import 'movies4_item_model.dart';

class DetailPageTwelveModel {
  List<Movies4ItemModel> movies4ItemList = [
    Movies4ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage180x120,
        title: "IO: Netflix",
        title1: "In near future we must save earth"),
    Movies4ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage7,
        title: "I Kill Giants",
        title1: "No more Surrender this time"),
    Movies4ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage9,
        title: "Angel has Fallen",
        title1: "Loyalty under everything")
  ];
}
