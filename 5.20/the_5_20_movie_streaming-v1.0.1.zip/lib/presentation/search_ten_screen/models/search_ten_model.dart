import '../../../core/app_export.dart';
import 'searchten_item_model.dart';

class SearchTenModel {
  List<SearchtenItemModel> searchtenItemList = [
    SearchtenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage20, title: "Jallikatta"),
    SearchtenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage25, title: "The Brave"),
    SearchtenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage26, title: "Helen")
  ];
}
