import '../../../core/app_export.dart';
import 'searchnine_item_model.dart';

class SearchNineModel {
  List<SearchnineItemModel> searchnineItemList = [
    SearchnineItemModel(
        jallikatta: ImageConstant.imgThumbnailImage20, title: "Jallikatta"),
    SearchnineItemModel(
        jallikatta: ImageConstant.imgThumbnailImage25, title: "The Brave"),
    SearchnineItemModel(
        jallikatta: ImageConstant.imgThumbnailImage26, title: "Helen"),
    SearchnineItemModel(
        jallikatta: ImageConstant.imgThumbnailImage27, title: "A1"),
    SearchnineItemModel(
        jallikatta: ImageConstant.imgThumbnailImage28, title: "Captain Marvel"),
    SearchnineItemModel(
        jallikatta: ImageConstant.imgThumbnailImage24, title: "Child’s Play")
  ];
}
