import '../../../core/app_export.dart';
import 'seemoreseven_item_model.dart';

class SeeMoreSevenModel {
  List<SeemoresevenItemModel> seemoresevenItemList = [
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage20, title: "Jallikatta"),
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage25, title: "The Brave"),
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage26, title: "Helen"),
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage27, title: "A1"),
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage28, title: "Captain Marvel"),
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage24, title: "Child’s Play"),
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage12, title: "Dark Phoenix"),
    SeemoresevenItemModel(
        jallikatta: ImageConstant.imgThumbnailImage30, title: "Arana")
  ];
}
