import '../../../core/app_export.dart';
import 'channelsix_item_model.dart';

class ChannelSixModel {
  List<ChannelsixItemModel> channelsixItemList = [
    ChannelsixItemModel(header: "Last time we meet", time: "02:00 AM (EST)"),
    ChannelsixItemModel(header: "Pain", time: "05:00 AM (EST)"),
    ChannelsixItemModel(header: "I Don't Think So", time: "06:00 AM (EST)"),
    ChannelsixItemModel(header: "Love You More", time: "04:00 AM (EST)"),
    ChannelsixItemModel(header: "War", time: "08:00 AM (EST)")
  ];
}
