import '../../../core/app_export.dart';
import 'seemoresix_item_model.dart';

class SeeMoreSixModel {
  List<SeemoresixItemModel> seemoresixItemList = [
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage140x90, title: "Rodioflash"),
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage, title: "The Perfection"),
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage1, title: "Turner & Hooch"),
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage20, title: "Jallikatta"),
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage21, title: "The Hobbit"),
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage12, title: "Dark Phoenix"),
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage22, title: "Ghost Writer"),
    SeemoresixItemModel(
        rodioflash: ImageConstant.imgThumbnailImage24, title: "Child’s Play")
  ];
}
