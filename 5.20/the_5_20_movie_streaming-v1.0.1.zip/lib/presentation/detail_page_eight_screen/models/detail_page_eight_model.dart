import '../../../core/app_export.dart';
import 'movies5_item_model.dart';

class DetailPageEightModel {
  List<Movies5ItemModel> movies5ItemList = [
    Movies5ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage180x120,
        title: "IO: Netflix",
        title1: "In near future we must save earth"),
    Movies5ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage7,
        title: "I Kill Giants",
        title1: "No more Surrender this time"),
    Movies5ItemModel(
        iONetflix: ImageConstant.imgThumbnailImage9,
        title: "Angel has Fallen",
        title1: "Loyalty under everything")
  ];
}
