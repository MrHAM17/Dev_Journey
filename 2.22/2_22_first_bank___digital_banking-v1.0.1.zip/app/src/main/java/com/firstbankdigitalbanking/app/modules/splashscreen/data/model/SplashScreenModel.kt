package com.firstbankdigitalbanking.app.modules.splashscreen.`data`.model

class SplashScreenModel()
