package com.firstbankdigitalbanking.app.network.models.fetchme

import com.google.gson.annotations.SerializedName

data class FetchMeRequest(
	val any: Any? = null
)
