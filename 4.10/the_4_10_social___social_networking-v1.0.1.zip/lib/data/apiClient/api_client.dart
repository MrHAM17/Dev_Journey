import 'package:the_4_10_social___social_networking/core/app_export.dart';

class ApiClient extends GetConnect {}
