import 'package:the_4_01_e_commerce/core/app_export.dart';import 'package:the_4_01_e_commerce/presentation/dashboard_container_screen/models/dashboard_container_model.dart';/// A controller class for the DashboardContainerScreen.
///
/// This class manages the state of the DashboardContainerScreen, including the
/// current dashboardContainerModelObj
class DashboardContainerController extends GetxController {Rx<DashboardContainerModel> dashboardContainerModelObj = DashboardContainerModel().obs;

 }
