import '../../../core/app_export.dart';/// This class is used in the [showonly_item_widget] screen.
class ShowonlyItemModel {Rx<String>? freeReturns = Rx("Free Returns");

Rx<bool>? isSelected = Rx(false);

 }
