import '../../../core/app_export.dart';/// This class is used in the [buyingformate_item_widget] screen.
class BuyingformateItemModel {Rx<String>? allListings = Rx("All Listings");

Rx<bool>? isSelected = Rx(false);

 }
