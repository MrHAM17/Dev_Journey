import '../../../core/app_export.dart';/// This class is used in the [itemlocation_item_widget] screen.
class ItemlocationItemModel {Rx<String>? uSOnly = Rx("US Only");

Rx<bool>? isSelected = Rx(false);

 }
