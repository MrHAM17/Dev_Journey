import '../../../core/app_export.dart';/// This class is used in the [blue_item_widget] screen.
class BlueItemModel {BlueItemModel({this.id}) { id = id  ?? Rx(""); }

Rx<String>? id;

 }
