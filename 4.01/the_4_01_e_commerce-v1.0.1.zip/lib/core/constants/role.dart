class Role {
  static int user = 1;
}
