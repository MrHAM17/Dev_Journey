class NavigationArgs {
  static String id = "id";

  static String token = "token";
}
