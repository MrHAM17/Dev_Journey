import 'package:the_4_01_e_commerce/core/app_export.dart';

class ApiClient extends GetConnect {}
