import 'package:the_3_04_health_care/core/app_export.dart';

class ApiClient {}
