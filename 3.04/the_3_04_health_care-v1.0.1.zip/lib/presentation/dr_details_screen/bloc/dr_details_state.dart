// ignore_for_file: must_be_immutable

part of 'dr_details_bloc.dart';

/// Represents the state of DrDetails in the application.
class DrDetailsState extends Equatable {
  DrDetailsState({
    this.rangeStart,
    this.rangeEnd,
    this.selectedDay,
    this.focusedDay,
    this.rangeSelectionMode = RangeSelectionMode.toggledOn,
    this.drDetailsModelObj,
  });

  DrDetailsModel? drDetailsModelObj;

  DateTime? rangeStart;

  DateTime? rangeEnd;

  DateTime? selectedDay;

  DateTime? focusedDay;

  RangeSelectionMode rangeSelectionMode;

  @override
  List<Object?> get props => [
        rangeStart,
        rangeEnd,
        selectedDay,
        focusedDay,
        rangeSelectionMode,
        drDetailsModelObj,
      ];
  DrDetailsState copyWith({
    DateTime? rangeStart,
    DateTime? rangeEnd,
    DateTime? selectedDay,
    DateTime? focusedDay,
    RangeSelectionMode? rangeSelectionMode,
    DrDetailsModel? drDetailsModelObj,
  }) {
    return DrDetailsState(
      rangeStart: rangeStart ?? this.rangeStart,
      rangeEnd: rangeEnd ?? this.rangeEnd,
      selectedDay: selectedDay ?? this.selectedDay,
      focusedDay: focusedDay ?? this.focusedDay,
      rangeSelectionMode: rangeSelectionMode ?? this.rangeSelectionMode,
      drDetailsModelObj: drDetailsModelObj ?? this.drDetailsModelObj,
    );
  }
}
