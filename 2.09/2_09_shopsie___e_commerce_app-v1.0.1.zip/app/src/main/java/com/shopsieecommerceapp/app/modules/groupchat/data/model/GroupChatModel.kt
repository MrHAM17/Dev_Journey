package com.shopsieecommerceapp.app.modules.groupchat.`data`.model

class GroupChatModel()
