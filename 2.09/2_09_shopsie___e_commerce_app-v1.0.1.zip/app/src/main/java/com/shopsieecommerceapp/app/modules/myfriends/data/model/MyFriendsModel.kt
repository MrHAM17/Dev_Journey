package com.shopsieecommerceapp.app.modules.myfriends.`data`.model

class MyFriendsModel()
