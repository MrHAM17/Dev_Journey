package com.shopsieecommerceapp.app.modules.messages.`data`.model

class MessagesModel()
