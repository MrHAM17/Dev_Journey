package com.shopsieecommerceapp.app.modules.singlestory.`data`.model

import kotlin.String

data class SingleStoryModel(
  /**
   * TODO Replace with dynamic value
   */
  var etCommentValue: String? = null
)
