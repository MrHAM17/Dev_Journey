package com.shopsieecommerceapp.app.modules.videochat.`data`.model

class VideoChatModel()
