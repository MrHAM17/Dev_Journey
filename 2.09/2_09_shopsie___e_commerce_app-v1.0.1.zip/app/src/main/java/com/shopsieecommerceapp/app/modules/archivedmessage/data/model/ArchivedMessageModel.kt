package com.shopsieecommerceapp.app.modules.archivedmessage.`data`.model

class ArchivedMessageModel()
