package com.shopsieecommerceapp.app.modules.home.`data`.model

class SixtysevenRowModel()
