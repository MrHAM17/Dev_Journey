package com.shopsieecommerceapp.app.modules.gallery.`data`.model

class GalleryModel()
