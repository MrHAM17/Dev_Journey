package com.shopsieecommerceapp.app.modules.events.`data`.model

class EventsModel()
