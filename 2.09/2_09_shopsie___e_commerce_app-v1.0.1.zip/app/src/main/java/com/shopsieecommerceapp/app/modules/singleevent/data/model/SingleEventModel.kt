package com.shopsieecommerceapp.app.modules.singleevent.`data`.model

class SingleEventModel()
