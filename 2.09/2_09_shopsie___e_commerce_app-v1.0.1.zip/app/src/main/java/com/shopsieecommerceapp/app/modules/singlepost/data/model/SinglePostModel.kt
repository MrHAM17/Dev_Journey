package com.shopsieecommerceapp.app.modules.singlepost.`data`.model

class SinglePostModel()
