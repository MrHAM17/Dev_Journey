package com.shopsieecommerceapp.app.modules.chat.`data`.model

class ChatModel()
