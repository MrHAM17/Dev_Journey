package com.shopsieecommerceapp.app.modules.search.`data`.model

class SearchModel()
