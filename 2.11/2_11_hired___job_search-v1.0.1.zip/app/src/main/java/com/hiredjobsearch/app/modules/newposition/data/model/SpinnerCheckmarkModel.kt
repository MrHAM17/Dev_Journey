package com.hiredjobsearch.app.modules.newposition.`data`.model

import kotlin.String

data class SpinnerCheckmarkModel(
  val itemName: String
)
