package com.hiredjobsearch.app.constants

import kotlin.String

public object user {
    public val EMAIL: String = "Priscilla_Mohr@yahoo.com"
}
