package com.hiredjobsearch.app.modules.addneweducation.`data`.model

import kotlin.String

data class SpinnerFrameOneModel(
  val itemName: String
)
