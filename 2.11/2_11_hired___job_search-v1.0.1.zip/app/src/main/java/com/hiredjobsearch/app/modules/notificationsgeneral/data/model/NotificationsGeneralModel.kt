package com.hiredjobsearch.app.modules.notificationsgeneral.`data`.model

class NotificationsGeneralModel()
