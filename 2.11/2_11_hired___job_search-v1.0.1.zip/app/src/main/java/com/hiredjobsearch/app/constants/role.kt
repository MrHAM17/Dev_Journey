package com.hiredjobsearch.app.constants

import kotlin.Int

public object role {
    public val USER: Int = 1
}
